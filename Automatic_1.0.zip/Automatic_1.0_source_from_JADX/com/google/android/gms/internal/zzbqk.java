package com.google.android.gms.internal;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

public class zzbqk implements zzbql {
    private boolean zzcaI = false;

    private void zzWU() {
        zzbte.zzb(this.zzcaI, "Transaction expected to already be in progress.");
    }

    public List<zzbpv> zzWQ() {
        return Collections.emptyList();
    }

    public void zzWT() {
        zzWU();
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, long j) {
        zzWU();
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, long j) {
        zzWU();
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbsc com_google_android_gms_internal_zzbsc) {
        zzWU();
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, Set<zzbrq> set) {
        zzWU();
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, Set<zzbrq> set, Set<zzbrq> set2) {
        zzWU();
    }

    public void zzaE(long j) {
        zzWU();
    }

    public void zzc(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        zzWU();
    }

    public void zzd(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        zzWU();
    }

    public zzbqu zzf(zzbrc com_google_android_gms_internal_zzbrc) {
        return new zzbqu(zzbrx.zza(zzbrv.zzabb(), com_google_android_gms_internal_zzbrc.zzaal()), false, false);
    }

    public <T> T zzf(Callable<T> callable) {
        zzbte.zzb(!this.zzcaI, "runInTransaction called when an existing transaction is already in progress.");
        this.zzcaI = true;
        try {
            T call = callable.call();
            this.zzcaI = false;
            return call;
        } catch (Throwable th) {
            this.zzcaI = false;
        }
    }

    public void zzg(zzbrc com_google_android_gms_internal_zzbrc) {
        zzWU();
    }

    public void zzh(zzbrc com_google_android_gms_internal_zzbrc) {
        zzWU();
    }

    public void zzi(zzbrc com_google_android_gms_internal_zzbrc) {
        zzWU();
    }

    public void zzk(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
        zzWU();
    }
}
