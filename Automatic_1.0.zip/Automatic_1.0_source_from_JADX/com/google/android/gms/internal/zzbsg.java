package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseException;

public class zzbsg {
    public static zzbsc zzabn() {
        return zzbrv.zzabb();
    }

    public static zzbsc zzav(Object obj) {
        zzbsc zzau = zzbsd.zzau(obj);
        if (zzau instanceof zzbsa) {
            zzau = new zzbru(Double.valueOf((double) ((Long) zzau.getValue()).longValue()), zzabn());
        }
        if (zzq(zzau)) {
            return zzau;
        }
        throw new DatabaseException("Invalid Firebase Database priority (must be a string, double, ServerValue, or null)");
    }

    public static boolean zzq(zzbsc com_google_android_gms_internal_zzbsc) {
        return com_google_android_gms_internal_zzbsc.zzaaQ().isEmpty() && (com_google_android_gms_internal_zzbsc.isEmpty() || (com_google_android_gms_internal_zzbsc instanceof zzbru) || (com_google_android_gms_internal_zzbsc instanceof zzbsi) || (com_google_android_gms_internal_zzbsc instanceof zzbrt));
    }
}
