package com.google.android.gms.internal;

import java.io.IOException;

public interface zzaqn {

    public static final class zza extends zzbyd<zza> {
        public zza[] zzbhg;

        public static final class zza extends zzbyd<zza> {
            private static volatile zza[] zzbhh;
            public int viewId;
            public String zzbhi;
            public String zzbhj;

            public zza() {
                zzGZ();
            }

            public static zza[] zzGY() {
                if (zzbhh == null) {
                    synchronized (zzbyh.zzcwK) {
                        if (zzbhh == null) {
                            zzbhh = new zza[0];
                        }
                    }
                }
                return zzbhh;
            }

            public boolean equals(Object obj) {
                if (obj == this) {
                    return true;
                }
                if (!(obj instanceof zza)) {
                    return false;
                }
                zza com_google_android_gms_internal_zzaqn_zza_zza = (zza) obj;
                if (this.zzbhi == null) {
                    if (com_google_android_gms_internal_zzaqn_zza_zza.zzbhi != null) {
                        return false;
                    }
                } else if (!this.zzbhi.equals(com_google_android_gms_internal_zzaqn_zza_zza.zzbhi)) {
                    return false;
                }
                if (this.zzbhj == null) {
                    if (com_google_android_gms_internal_zzaqn_zza_zza.zzbhj != null) {
                        return false;
                    }
                } else if (!this.zzbhj.equals(com_google_android_gms_internal_zzaqn_zza_zza.zzbhj)) {
                    return false;
                }
                return this.viewId == com_google_android_gms_internal_zzaqn_zza_zza.viewId ? (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzaqn_zza_zza.zzcwC == null || com_google_android_gms_internal_zzaqn_zza_zza.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzaqn_zza_zza.zzcwC) : false;
            }

            public int hashCode() {
                int i = 0;
                int hashCode = ((((this.zzbhj == null ? 0 : this.zzbhj.hashCode()) + (((this.zzbhi == null ? 0 : this.zzbhi.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31) + this.viewId) * 31;
                if (!(this.zzcwC == null || this.zzcwC.isEmpty())) {
                    i = this.zzcwC.hashCode();
                }
                return hashCode + i;
            }

            public zza zzC(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
                while (true) {
                    int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                    switch (zzaeW) {
                        case 0:
                            break;
                        case 10:
                            this.zzbhi = com_google_android_gms_internal_zzbyb.readString();
                            continue;
                        case 18:
                            this.zzbhj = com_google_android_gms_internal_zzbyb.readString();
                            continue;
                        case 24:
                            this.viewId = com_google_android_gms_internal_zzbyb.zzafa();
                            continue;
                        default:
                            if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                                break;
                            }
                            continue;
                    }
                    return this;
                }
            }

            public zza zzGZ() {
                this.zzbhi = "";
                this.zzbhj = "";
                this.viewId = 0;
                this.zzcwC = null;
                this.zzcwL = -1;
                return this;
            }

            public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
                if (!(this.zzbhi == null || this.zzbhi.equals(""))) {
                    com_google_android_gms_internal_zzbyc.zzq(1, this.zzbhi);
                }
                if (!(this.zzbhj == null || this.zzbhj.equals(""))) {
                    com_google_android_gms_internal_zzbyc.zzq(2, this.zzbhj);
                }
                if (this.viewId != 0) {
                    com_google_android_gms_internal_zzbyc.zzJ(3, this.viewId);
                }
                super.zza(com_google_android_gms_internal_zzbyc);
            }

            public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
                return zzC(com_google_android_gms_internal_zzbyb);
            }

            protected int zzu() {
                int zzu = super.zzu();
                if (!(this.zzbhi == null || this.zzbhi.equals(""))) {
                    zzu += zzbyc.zzr(1, this.zzbhi);
                }
                if (!(this.zzbhj == null || this.zzbhj.equals(""))) {
                    zzu += zzbyc.zzr(2, this.zzbhj);
                }
                return this.viewId != 0 ? zzu + zzbyc.zzL(3, this.viewId) : zzu;
            }
        }

        public zza() {
            zzGX();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzaqn_zza = (zza) obj;
            return zzbyh.equals(this.zzbhg, com_google_android_gms_internal_zzaqn_zza.zzbhg) ? (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzaqn_zza.zzcwC == null || com_google_android_gms_internal_zzaqn_zza.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzaqn_zza.zzcwC) : false;
        }

        public int hashCode() {
            int hashCode = (((getClass().getName().hashCode() + 527) * 31) + zzbyh.hashCode(this.zzbhg)) * 31;
            int hashCode2 = (this.zzcwC == null || this.zzcwC.isEmpty()) ? 0 : this.zzcwC.hashCode();
            return hashCode2 + hashCode;
        }

        public zza zzB(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            while (true) {
                int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                switch (zzaeW) {
                    case 0:
                        break;
                    case 10:
                        int zzb = zzbym.zzb(com_google_android_gms_internal_zzbyb, 10);
                        zzaeW = this.zzbhg == null ? 0 : this.zzbhg.length;
                        Object obj = new zza[(zzb + zzaeW)];
                        if (zzaeW != 0) {
                            System.arraycopy(this.zzbhg, 0, obj, 0, zzaeW);
                        }
                        while (zzaeW < obj.length - 1) {
                            obj[zzaeW] = new zza();
                            com_google_android_gms_internal_zzbyb.zza(obj[zzaeW]);
                            com_google_android_gms_internal_zzbyb.zzaeW();
                            zzaeW++;
                        }
                        obj[zzaeW] = new zza();
                        com_google_android_gms_internal_zzbyb.zza(obj[zzaeW]);
                        this.zzbhg = obj;
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public zza zzGX() {
            this.zzbhg = zza.zzGY();
            this.zzcwC = null;
            this.zzcwL = -1;
            return this;
        }

        public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
            if (this.zzbhg != null && this.zzbhg.length > 0) {
                for (zzbyj com_google_android_gms_internal_zzbyj : this.zzbhg) {
                    if (com_google_android_gms_internal_zzbyj != null) {
                        com_google_android_gms_internal_zzbyc.zza(1, com_google_android_gms_internal_zzbyj);
                    }
                }
            }
            super.zza(com_google_android_gms_internal_zzbyc);
        }

        public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            return zzB(com_google_android_gms_internal_zzbyb);
        }

        protected int zzu() {
            int zzu = super.zzu();
            if (this.zzbhg != null && this.zzbhg.length > 0) {
                for (zzbyj com_google_android_gms_internal_zzbyj : this.zzbhg) {
                    if (com_google_android_gms_internal_zzbyj != null) {
                        zzu += zzbyc.zzc(1, com_google_android_gms_internal_zzbyj);
                    }
                }
            }
            return zzu;
        }
    }

    public static final class zzb extends zzbyd<zzb> {
        private static volatile zzb[] zzbhk;
        public String name;
        public zzd zzbhl;

        public zzb() {
            zzHb();
        }

        public static zzb[] zzHa() {
            if (zzbhk == null) {
                synchronized (zzbyh.zzcwK) {
                    if (zzbhk == null) {
                        zzbhk = new zzb[0];
                    }
                }
            }
            return zzbhk;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzb)) {
                return false;
            }
            zzb com_google_android_gms_internal_zzaqn_zzb = (zzb) obj;
            if (this.name == null) {
                if (com_google_android_gms_internal_zzaqn_zzb.name != null) {
                    return false;
                }
            } else if (!this.name.equals(com_google_android_gms_internal_zzaqn_zzb.name)) {
                return false;
            }
            if (this.zzbhl == null) {
                if (com_google_android_gms_internal_zzaqn_zzb.zzbhl != null) {
                    return false;
                }
            } else if (!this.zzbhl.equals(com_google_android_gms_internal_zzaqn_zzb.zzbhl)) {
                return false;
            }
            return (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzaqn_zzb.zzcwC == null || com_google_android_gms_internal_zzaqn_zzb.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzaqn_zzb.zzcwC);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.zzbhl == null ? 0 : this.zzbhl.hashCode()) + (((this.name == null ? 0 : this.name.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31;
            if (!(this.zzcwC == null || this.zzcwC.isEmpty())) {
                i = this.zzcwC.hashCode();
            }
            return hashCode + i;
        }

        public zzb zzD(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            while (true) {
                int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                switch (zzaeW) {
                    case 0:
                        break;
                    case 10:
                        this.name = com_google_android_gms_internal_zzbyb.readString();
                        continue;
                    case 18:
                        if (this.zzbhl == null) {
                            this.zzbhl = new zzd();
                        }
                        com_google_android_gms_internal_zzbyb.zza(this.zzbhl);
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public zzb zzHb() {
            this.name = "";
            this.zzbhl = null;
            this.zzcwC = null;
            this.zzcwL = -1;
            return this;
        }

        public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
            if (!(this.name == null || this.name.equals(""))) {
                com_google_android_gms_internal_zzbyc.zzq(1, this.name);
            }
            if (this.zzbhl != null) {
                com_google_android_gms_internal_zzbyc.zza(2, this.zzbhl);
            }
            super.zza(com_google_android_gms_internal_zzbyc);
        }

        public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            return zzD(com_google_android_gms_internal_zzbyb);
        }

        protected int zzu() {
            int zzu = super.zzu();
            if (!(this.name == null || this.name.equals(""))) {
                zzu += zzbyc.zzr(1, this.name);
            }
            return this.zzbhl != null ? zzu + zzbyc.zzc(2, this.zzbhl) : zzu;
        }
    }

    public static final class zzc extends zzbyd<zzc> {
        public String type;
        public zzb[] zzbhm;

        public zzc() {
            zzHc();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzc)) {
                return false;
            }
            zzc com_google_android_gms_internal_zzaqn_zzc = (zzc) obj;
            if (this.type == null) {
                if (com_google_android_gms_internal_zzaqn_zzc.type != null) {
                    return false;
                }
            } else if (!this.type.equals(com_google_android_gms_internal_zzaqn_zzc.type)) {
                return false;
            }
            return zzbyh.equals(this.zzbhm, com_google_android_gms_internal_zzaqn_zzc.zzbhm) ? (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzaqn_zzc.zzcwC == null || com_google_android_gms_internal_zzaqn_zzc.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzaqn_zzc.zzcwC) : false;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((((this.type == null ? 0 : this.type.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31) + zzbyh.hashCode(this.zzbhm)) * 31;
            if (!(this.zzcwC == null || this.zzcwC.isEmpty())) {
                i = this.zzcwC.hashCode();
            }
            return hashCode + i;
        }

        public zzc zzE(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            while (true) {
                int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                switch (zzaeW) {
                    case 0:
                        break;
                    case 10:
                        this.type = com_google_android_gms_internal_zzbyb.readString();
                        continue;
                    case 18:
                        int zzb = zzbym.zzb(com_google_android_gms_internal_zzbyb, 18);
                        zzaeW = this.zzbhm == null ? 0 : this.zzbhm.length;
                        Object obj = new zzb[(zzb + zzaeW)];
                        if (zzaeW != 0) {
                            System.arraycopy(this.zzbhm, 0, obj, 0, zzaeW);
                        }
                        while (zzaeW < obj.length - 1) {
                            obj[zzaeW] = new zzb();
                            com_google_android_gms_internal_zzbyb.zza(obj[zzaeW]);
                            com_google_android_gms_internal_zzbyb.zzaeW();
                            zzaeW++;
                        }
                        obj[zzaeW] = new zzb();
                        com_google_android_gms_internal_zzbyb.zza(obj[zzaeW]);
                        this.zzbhm = obj;
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public zzc zzHc() {
            this.type = "";
            this.zzbhm = zzb.zzHa();
            this.zzcwC = null;
            this.zzcwL = -1;
            return this;
        }

        public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
            if (!(this.type == null || this.type.equals(""))) {
                com_google_android_gms_internal_zzbyc.zzq(1, this.type);
            }
            if (this.zzbhm != null && this.zzbhm.length > 0) {
                for (zzbyj com_google_android_gms_internal_zzbyj : this.zzbhm) {
                    if (com_google_android_gms_internal_zzbyj != null) {
                        com_google_android_gms_internal_zzbyc.zza(2, com_google_android_gms_internal_zzbyj);
                    }
                }
            }
            super.zza(com_google_android_gms_internal_zzbyc);
        }

        public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            return zzE(com_google_android_gms_internal_zzbyb);
        }

        protected int zzu() {
            int zzu = super.zzu();
            if (!(this.type == null || this.type.equals(""))) {
                zzu += zzbyc.zzr(1, this.type);
            }
            if (this.zzbhm == null || this.zzbhm.length <= 0) {
                return zzu;
            }
            int i = zzu;
            for (zzbyj com_google_android_gms_internal_zzbyj : this.zzbhm) {
                if (com_google_android_gms_internal_zzbyj != null) {
                    i += zzbyc.zzc(2, com_google_android_gms_internal_zzbyj);
                }
            }
            return i;
        }
    }

    public static final class zzd extends zzbyd<zzd> {
        public String zzaGV;
        public boolean zzbhn;
        public long zzbho;
        public double zzbhp;
        public zzc zzbhq;

        public zzd() {
            zzHd();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zzd)) {
                return false;
            }
            zzd com_google_android_gms_internal_zzaqn_zzd = (zzd) obj;
            if (this.zzbhn != com_google_android_gms_internal_zzaqn_zzd.zzbhn) {
                return false;
            }
            if (this.zzaGV == null) {
                if (com_google_android_gms_internal_zzaqn_zzd.zzaGV != null) {
                    return false;
                }
            } else if (!this.zzaGV.equals(com_google_android_gms_internal_zzaqn_zzd.zzaGV)) {
                return false;
            }
            if (this.zzbho != com_google_android_gms_internal_zzaqn_zzd.zzbho || Double.doubleToLongBits(this.zzbhp) != Double.doubleToLongBits(com_google_android_gms_internal_zzaqn_zzd.zzbhp)) {
                return false;
            }
            if (this.zzbhq == null) {
                if (com_google_android_gms_internal_zzaqn_zzd.zzbhq != null) {
                    return false;
                }
            } else if (!this.zzbhq.equals(com_google_android_gms_internal_zzaqn_zzd.zzbhq)) {
                return false;
            }
            return (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzaqn_zzd.zzcwC == null || com_google_android_gms_internal_zzaqn_zzd.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzaqn_zzd.zzcwC);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = (((this.zzaGV == null ? 0 : this.zzaGV.hashCode()) + (((this.zzbhn ? 1231 : 1237) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31) + ((int) (this.zzbho ^ (this.zzbho >>> 32)));
            long doubleToLongBits = Double.doubleToLongBits(this.zzbhp);
            hashCode = ((this.zzbhq == null ? 0 : this.zzbhq.hashCode()) + (((hashCode * 31) + ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32)))) * 31)) * 31;
            if (!(this.zzcwC == null || this.zzcwC.isEmpty())) {
                i = this.zzcwC.hashCode();
            }
            return hashCode + i;
        }

        public zzd zzF(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            while (true) {
                int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                switch (zzaeW) {
                    case 0:
                        break;
                    case 8:
                        this.zzbhn = com_google_android_gms_internal_zzbyb.zzafc();
                        continue;
                    case 18:
                        this.zzaGV = com_google_android_gms_internal_zzbyb.readString();
                        continue;
                    case 24:
                        this.zzbho = com_google_android_gms_internal_zzbyb.zzaeZ();
                        continue;
                    case 33:
                        this.zzbhp = com_google_android_gms_internal_zzbyb.readDouble();
                        continue;
                    case 42:
                        if (this.zzbhq == null) {
                            this.zzbhq = new zzc();
                        }
                        com_google_android_gms_internal_zzbyb.zza(this.zzbhq);
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public zzd zzHd() {
            this.zzbhn = false;
            this.zzaGV = "";
            this.zzbho = 0;
            this.zzbhp = 0.0d;
            this.zzbhq = null;
            this.zzcwC = null;
            this.zzcwL = -1;
            return this;
        }

        public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
            if (this.zzbhn) {
                com_google_android_gms_internal_zzbyc.zzg(1, this.zzbhn);
            }
            if (!(this.zzaGV == null || this.zzaGV.equals(""))) {
                com_google_android_gms_internal_zzbyc.zzq(2, this.zzaGV);
            }
            if (this.zzbho != 0) {
                com_google_android_gms_internal_zzbyc.zzb(3, this.zzbho);
            }
            if (Double.doubleToLongBits(this.zzbhp) != Double.doubleToLongBits(0.0d)) {
                com_google_android_gms_internal_zzbyc.zza(4, this.zzbhp);
            }
            if (this.zzbhq != null) {
                com_google_android_gms_internal_zzbyc.zza(5, this.zzbhq);
            }
            super.zza(com_google_android_gms_internal_zzbyc);
        }

        public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            return zzF(com_google_android_gms_internal_zzbyb);
        }

        protected int zzu() {
            int zzu = super.zzu();
            if (this.zzbhn) {
                zzu += zzbyc.zzh(1, this.zzbhn);
            }
            if (!(this.zzaGV == null || this.zzaGV.equals(""))) {
                zzu += zzbyc.zzr(2, this.zzaGV);
            }
            if (this.zzbho != 0) {
                zzu += zzbyc.zzf(3, this.zzbho);
            }
            if (Double.doubleToLongBits(this.zzbhp) != Double.doubleToLongBits(0.0d)) {
                zzu += zzbyc.zzb(4, this.zzbhp);
            }
            return this.zzbhq != null ? zzu + zzbyc.zzc(5, this.zzbhq) : zzu;
        }
    }
}
