package com.google.android.gms.internal;

public class zzbsf extends zzbrw {
    private static final zzbsf zzcjG = new zzbsf();

    private zzbsf() {
    }

    public static zzbsf zzabm() {
        return zzcjG;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return zza((zzbsb) obj, (zzbsb) obj2);
    }

    public boolean equals(Object obj) {
        return obj instanceof zzbsf;
    }

    public int hashCode() {
        return 3155577;
    }

    public String toString() {
        return "PriorityIndex";
    }

    public int zza(zzbsb com_google_android_gms_internal_zzbsb, zzbsb com_google_android_gms_internal_zzbsb2) {
        return zzbsd.zza(com_google_android_gms_internal_zzbsb.zzabl(), com_google_android_gms_internal_zzbsb.zzWK().zzaaQ(), com_google_android_gms_internal_zzbsb2.zzabl(), com_google_android_gms_internal_zzbsb2.zzWK().zzaaQ());
    }

    public zzbsb zzabd() {
        return zzg(zzbrq.zzaaJ(), zzbsc.zzcjB);
    }

    public String zzabe() {
        throw new IllegalArgumentException("Can't get query definition on priority index!");
    }

    public zzbsb zzg(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
        return new zzbsb(com_google_android_gms_internal_zzbrq, new zzbsi("[PRIORITY-POST]", com_google_android_gms_internal_zzbsc));
    }

    public boolean zzm(zzbsc com_google_android_gms_internal_zzbsc) {
        return !com_google_android_gms_internal_zzbsc.zzaaQ().isEmpty();
    }
}
