package com.google.android.gms.internal;

public interface zzbun {
    void zzqX(int i) throws InterruptedException;
}
