package com.google.android.gms.internal;

public class zzbqf {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbqf.class.desiredAssertionStatus());
    public static final zzbqf zzcgR = new zzbqf(zza.User, null, false);
    public static final zzbqf zzcgS = new zzbqf(zza.Server, null, false);
    private final zza zzcgT;
    private final zzbrb zzcgU;
    private final boolean zzcgV;

    private enum zza {
        User,
        Server
    }

    public zzbqf(zza com_google_android_gms_internal_zzbqf_zza, zzbrb com_google_android_gms_internal_zzbrb, boolean z) {
        this.zzcgT = com_google_android_gms_internal_zzbqf_zza;
        this.zzcgU = com_google_android_gms_internal_zzbrb;
        this.zzcgV = z;
        if (!$assertionsDisabled && z && !zzZD()) {
            throw new AssertionError();
        }
    }

    public static zzbqf zzc(zzbrb com_google_android_gms_internal_zzbrb) {
        return new zzbqf(zza.Server, com_google_android_gms_internal_zzbrb, true);
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzcgT);
        String valueOf2 = String.valueOf(this.zzcgU);
        return new StringBuilder((String.valueOf(valueOf).length() + 52) + String.valueOf(valueOf2).length()).append("OperationSource{source=").append(valueOf).append(", queryParams=").append(valueOf2).append(", tagged=").append(this.zzcgV).append("}").toString();
    }

    public boolean zzZC() {
        return this.zzcgT == zza.User;
    }

    public boolean zzZD() {
        return this.zzcgT == zza.Server;
    }

    public boolean zzZE() {
        return this.zzcgV;
    }

    public zzbrb zzZF() {
        return this.zzcgU;
    }
}
