package com.google.android.gms.internal;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import org.apache.commons.net.ftp.FTPReply;

public class zzbwx implements Closeable {
    private static final char[] zzcuh = ")]}'\n".toCharArray();
    private final Reader in;
    private int limit = 0;
    private int pos = 0;
    private boolean zzcui = false;
    private final char[] zzcuj = new char[1024];
    private int zzcuk = 0;
    private int zzcul = 0;
    private int zzcum = 0;
    private long zzcun;
    private int zzcuo;
    private String zzcup;
    private int[] zzcuq = new int[32];
    private int zzcur = 0;
    private String[] zzcus;
    private int[] zzcut;

    static class C05831 extends zzbwc {
        C05831() {
        }

        public void zzi(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx instanceof zzbwn) {
                ((zzbwn) com_google_android_gms_internal_zzbwx).zzaeq();
                return;
            }
            int zzG = com_google_android_gms_internal_zzbwx.zzcum;
            if (zzG == 0) {
                zzG = com_google_android_gms_internal_zzbwx.zzaeA();
            }
            if (zzG == 13) {
                com_google_android_gms_internal_zzbwx.zzcum = 9;
            } else if (zzG == 12) {
                com_google_android_gms_internal_zzbwx.zzcum = 8;
            } else if (zzG == 14) {
                com_google_android_gms_internal_zzbwx.zzcum = 10;
            } else {
                String valueOf = String.valueOf(com_google_android_gms_internal_zzbwx.zzaen());
                int zzI = com_google_android_gms_internal_zzbwx.getLineNumber();
                int zzJ = com_google_android_gms_internal_zzbwx.getColumnNumber();
                String path = com_google_android_gms_internal_zzbwx.getPath();
                throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(path).length()).append("Expected a name but was ").append(valueOf).append(" ").append(" at line ").append(zzI).append(" column ").append(zzJ).append(" path ").append(path).toString());
            }
        }
    }

    static {
        zzbwc.zzcsa = new C05831();
    }

    public zzbwx(Reader reader) {
        int[] iArr = this.zzcuq;
        int i = this.zzcur;
        this.zzcur = i + 1;
        iArr[i] = 6;
        this.zzcus = new String[32];
        this.zzcut = new int[32];
        if (reader == null) {
            throw new NullPointerException("in == null");
        }
        this.in = reader;
    }

    private int getColumnNumber() {
        return (this.pos - this.zzcul) + 1;
    }

    private int getLineNumber() {
        return this.zzcuk + 1;
    }

    private int zzaeA() throws IOException {
        int zzbn;
        int i = this.zzcuq[this.zzcur - 1];
        if (i == 1) {
            this.zzcuq[this.zzcur - 1] = 2;
        } else if (i == 2) {
            switch (zzbn(true)) {
                case 44:
                    break;
                case 59:
                    zzaeF();
                    break;
                case 93:
                    this.zzcum = 4;
                    return 4;
                default:
                    throw zzkr("Unterminated array");
            }
        } else if (i == 3 || i == 5) {
            this.zzcuq[this.zzcur - 1] = 4;
            if (i == 5) {
                switch (zzbn(true)) {
                    case 44:
                        break;
                    case 59:
                        zzaeF();
                        break;
                    case FTPReply.DATA_CONNECTION_ALREADY_OPEN /*125*/:
                        this.zzcum = 2;
                        return 2;
                    default:
                        throw zzkr("Unterminated object");
                }
            }
            zzbn = zzbn(true);
            switch (zzbn) {
                case 34:
                    this.zzcum = 13;
                    return 13;
                case 39:
                    zzaeF();
                    this.zzcum = 12;
                    return 12;
                case FTPReply.DATA_CONNECTION_ALREADY_OPEN /*125*/:
                    if (i != 5) {
                        this.zzcum = 2;
                        return 2;
                    }
                    throw zzkr("Expected name");
                default:
                    zzaeF();
                    this.pos--;
                    if (zzc((char) zzbn)) {
                        this.zzcum = 14;
                        return 14;
                    }
                    throw zzkr("Expected name");
            }
        } else if (i == 4) {
            this.zzcuq[this.zzcur - 1] = 5;
            switch (zzbn(true)) {
                case 58:
                    break;
                case 61:
                    zzaeF();
                    if ((this.pos < this.limit || zzra(1)) && this.zzcuj[this.pos] == '>') {
                        this.pos++;
                        break;
                    }
                default:
                    throw zzkr("Expected ':'");
            }
        } else if (i == 6) {
            if (this.zzcui) {
                zzaeI();
            }
            this.zzcuq[this.zzcur - 1] = 7;
        } else if (i == 7) {
            if (zzbn(false) == -1) {
                this.zzcum = 17;
                return 17;
            }
            zzaeF();
            this.pos--;
        } else if (i == 8) {
            throw new IllegalStateException("JsonReader is closed");
        }
        switch (zzbn(true)) {
            case 34:
                if (this.zzcur == 1) {
                    zzaeF();
                }
                this.zzcum = 9;
                return 9;
            case 39:
                zzaeF();
                this.zzcum = 8;
                return 8;
            case 44:
            case 59:
                break;
            case 91:
                this.zzcum = 3;
                return 3;
            case 93:
                if (i == 1) {
                    this.zzcum = 4;
                    return 4;
                }
                break;
            case 123:
                this.zzcum = 1;
                return 1;
            default:
                this.pos--;
                if (this.zzcur == 1) {
                    zzaeF();
                }
                zzbn = zzaeB();
                if (zzbn != 0) {
                    return zzbn;
                }
                zzbn = zzaeC();
                if (zzbn != 0) {
                    return zzbn;
                }
                if (zzc(this.zzcuj[this.pos])) {
                    zzaeF();
                    this.zzcum = 10;
                    return 10;
                }
                throw zzkr("Expected value");
        }
        if (i == 1 || i == 2) {
            zzaeF();
            this.pos--;
            this.zzcum = 7;
            return 7;
        }
        throw zzkr("Unexpected value");
    }

    private int zzaeB() throws IOException {
        String str;
        int i;
        char c = this.zzcuj[this.pos];
        String str2;
        if (c == 't' || c == 'T') {
            str = "true";
            str2 = "TRUE";
            i = 5;
        } else if (c == 'f' || c == 'F') {
            str = "false";
            str2 = "FALSE";
            i = 6;
        } else if (c != 'n' && c != 'N') {
            return 0;
        } else {
            str = "null";
            str2 = "NULL";
            i = 7;
        }
        int length = str.length();
        int i2 = 1;
        while (i2 < length) {
            if (this.pos + i2 >= this.limit && !zzra(i2 + 1)) {
                return 0;
            }
            char c2 = this.zzcuj[this.pos + i2];
            if (c2 != str.charAt(i2) && c2 != r1.charAt(i2)) {
                return 0;
            }
            i2++;
        }
        if ((this.pos + length < this.limit || zzra(length + 1)) && zzc(this.zzcuj[this.pos + length])) {
            return 0;
        }
        this.pos += length;
        this.zzcum = i;
        return i;
    }

    private int zzaeC() throws IOException {
        char[] cArr = this.zzcuj;
        int i = this.pos;
        long j = 0;
        Object obj = null;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        int i5 = this.limit;
        int i6 = i;
        while (true) {
            Object obj2;
            if (i6 + i4 == i5) {
                if (i4 == cArr.length) {
                    return 0;
                }
                if (zzra(i4 + 1)) {
                    i6 = this.pos;
                    i5 = this.limit;
                } else if (i3 != 2 && i2 != 0 && (j != Long.MIN_VALUE || obj != null)) {
                    if (obj == null) {
                        j = -j;
                    }
                    this.zzcun = j;
                    this.pos += i4;
                    this.zzcum = 15;
                    return 15;
                } else if (i3 == 2 && i3 != 4 && i3 != 7) {
                    return 0;
                } else {
                    this.zzcuo = i4;
                    this.zzcum = 16;
                    return 16;
                }
            }
            char c = cArr[i6 + i4];
            int i7;
            switch (c) {
                case '+':
                    if (i3 != 5) {
                        return 0;
                    }
                    i = 6;
                    i3 = i2;
                    obj2 = obj;
                    continue;
                case '-':
                    if (i3 == 0) {
                        i = 1;
                        i7 = i2;
                        obj2 = 1;
                        i3 = i7;
                        continue;
                    } else if (i3 == 5) {
                        i = 6;
                        i3 = i2;
                        obj2 = obj;
                        break;
                    } else {
                        return 0;
                    }
                case '.':
                    if (i3 != 2) {
                        return 0;
                    }
                    i = 3;
                    i3 = i2;
                    obj2 = obj;
                    continue;
                case 'E':
                case 'e':
                    if (i3 != 2 && i3 != 4) {
                        return 0;
                    }
                    i = 5;
                    i3 = i2;
                    obj2 = obj;
                    continue;
                default:
                    if (c >= '0' && c <= '9') {
                        if (i3 != 1 && i3 != 0) {
                            if (i3 != 2) {
                                if (i3 != 3) {
                                    if (i3 != 5 && i3 != 6) {
                                        i = i3;
                                        i3 = i2;
                                        obj2 = obj;
                                        break;
                                    }
                                    i = 7;
                                    i3 = i2;
                                    obj2 = obj;
                                    break;
                                }
                                i = 4;
                                i3 = i2;
                                obj2 = obj;
                                break;
                            } else if (j != 0) {
                                long j2 = (10 * j) - ((long) (c - 48));
                                i = (j > -922337203685477580L || (j == -922337203685477580L && j2 < j)) ? 1 : 0;
                                i &= i2;
                                obj2 = obj;
                                j = j2;
                                i7 = i3;
                                i3 = i;
                                i = i7;
                                break;
                            } else {
                                return 0;
                            }
                        }
                        j = (long) (-(c - 48));
                        i = 2;
                        i3 = i2;
                        obj2 = obj;
                        continue;
                    } else if (zzc(c)) {
                        return 0;
                    }
                    break;
            }
            if (i3 != 2) {
            }
            if (i3 == 2) {
            }
            this.zzcuo = i4;
            this.zzcum = 16;
            return 16;
            i4++;
            obj = obj2;
            i2 = i3;
            i3 = i;
        }
    }

    private String zzaeD() throws IOException {
        StringBuilder stringBuilder = null;
        int i = 0;
        while (true) {
            String str;
            if (this.pos + i < this.limit) {
                switch (this.zzcuj[this.pos + i]) {
                    case '\t':
                    case '\n':
                    case '\f':
                    case '\r':
                    case ' ':
                    case ',':
                    case ':':
                    case '[':
                    case ']':
                    case '{':
                    case FTPReply.DATA_CONNECTION_ALREADY_OPEN /*125*/:
                        break;
                    case '#':
                    case '/':
                    case ';':
                    case '=':
                    case '\\':
                        zzaeF();
                        break;
                    default:
                        i++;
                        continue;
                }
            } else if (i >= this.zzcuj.length) {
                if (stringBuilder == null) {
                    stringBuilder = new StringBuilder();
                }
                stringBuilder.append(this.zzcuj, this.pos, i);
                this.pos = i + this.pos;
                i = !zzra(1) ? 0 : 0;
            } else if (zzra(i + 1)) {
            }
            if (stringBuilder == null) {
                str = new String(this.zzcuj, this.pos, i);
            } else {
                stringBuilder.append(this.zzcuj, this.pos, i);
                str = stringBuilder.toString();
            }
            this.pos = i + this.pos;
            return str;
        }
    }

    private void zzaeE() throws IOException {
        do {
            int i = 0;
            while (this.pos + i < this.limit) {
                switch (this.zzcuj[this.pos + i]) {
                    case '\t':
                    case '\n':
                    case '\f':
                    case '\r':
                    case ' ':
                    case ',':
                    case ':':
                    case '[':
                    case ']':
                    case '{':
                    case FTPReply.DATA_CONNECTION_ALREADY_OPEN /*125*/:
                        break;
                    case '#':
                    case '/':
                    case ';':
                    case '=':
                    case '\\':
                        zzaeF();
                        break;
                    default:
                        i++;
                }
                this.pos = i + this.pos;
                return;
            }
            this.pos = i + this.pos;
        } while (zzra(1));
    }

    private void zzaeF() throws IOException {
        if (!this.zzcui) {
            throw zzkr("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    private void zzaeG() throws IOException {
        char c;
        do {
            if (this.pos < this.limit || zzra(1)) {
                char[] cArr = this.zzcuj;
                int i = this.pos;
                this.pos = i + 1;
                c = cArr[i];
                if (c == '\n') {
                    this.zzcuk++;
                    this.zzcul = this.pos;
                    return;
                }
            } else {
                return;
            }
        } while (c != '\r');
    }

    private char zzaeH() throws IOException {
        if (this.pos != this.limit || zzra(1)) {
            char[] cArr = this.zzcuj;
            int i = this.pos;
            this.pos = i + 1;
            char c = cArr[i];
            switch (c) {
                case '\n':
                    this.zzcuk++;
                    this.zzcul = this.pos;
                    return c;
                case 'b':
                    return '\b';
                case 'f':
                    return '\f';
                case 'n':
                    return '\n';
                case 'r':
                    return '\r';
                case 't':
                    return '\t';
                case 'u':
                    if (this.pos + 4 <= this.limit || zzra(4)) {
                        int i2 = this.pos;
                        int i3 = i2 + 4;
                        int i4 = i2;
                        c = '\u0000';
                        for (i = i4; i < i3; i++) {
                            char c2 = this.zzcuj[i];
                            c = (char) (c << 4);
                            if (c2 >= '0' && c2 <= '9') {
                                c = (char) (c + (c2 - 48));
                            } else if (c2 >= 'a' && c2 <= 'f') {
                                c = (char) (c + ((c2 - 97) + 10));
                            } else if (c2 < 'A' || c2 > 'F') {
                                String str = "\\u";
                                String valueOf = String.valueOf(new String(this.zzcuj, this.pos, 4));
                                throw new NumberFormatException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                            } else {
                                c = (char) (c + ((c2 - 65) + 10));
                            }
                        }
                        this.pos += 4;
                        return c;
                    }
                    throw zzkr("Unterminated escape sequence");
                default:
                    return c;
            }
        }
        throw zzkr("Unterminated escape sequence");
    }

    private void zzaeI() throws IOException {
        zzbn(true);
        this.pos--;
        if (this.pos + zzcuh.length <= this.limit || zzra(zzcuh.length)) {
            int i = 0;
            while (i < zzcuh.length) {
                if (this.zzcuj[this.pos + i] == zzcuh[i]) {
                    i++;
                } else {
                    return;
                }
            }
            this.pos += zzcuh.length;
        }
    }

    private int zzbn(boolean z) throws IOException {
        char[] cArr = this.zzcuj;
        int i = this.pos;
        int i2 = this.limit;
        while (true) {
            int lineNumber;
            if (i == i2) {
                this.pos = i;
                if (zzra(1)) {
                    i = this.pos;
                    i2 = this.limit;
                } else if (!z) {
                    return -1;
                } else {
                    String valueOf = String.valueOf("End of input at line ");
                    lineNumber = getLineNumber();
                    throw new EOFException(new StringBuilder(String.valueOf(valueOf).length() + 30).append(valueOf).append(lineNumber).append(" column ").append(getColumnNumber()).toString());
                }
            }
            lineNumber = i + 1;
            char c = cArr[i];
            if (c == '\n') {
                this.zzcuk++;
                this.zzcul = lineNumber;
                i = lineNumber;
            } else if (c == ' ' || c == '\r') {
                i = lineNumber;
            } else if (c == '\t') {
                i = lineNumber;
            } else if (c == '/') {
                this.pos = lineNumber;
                if (lineNumber == i2) {
                    this.pos--;
                    boolean zzra = zzra(2);
                    this.pos++;
                    if (!zzra) {
                        return c;
                    }
                }
                zzaeF();
                switch (cArr[this.pos]) {
                    case '*':
                        this.pos++;
                        if (zzkq("*/")) {
                            i = this.pos + 2;
                            i2 = this.limit;
                            break;
                        }
                        throw zzkr("Unterminated comment");
                    case '/':
                        this.pos++;
                        zzaeG();
                        i = this.pos;
                        i2 = this.limit;
                        break;
                    default:
                        return c;
                }
            } else if (c == '#') {
                this.pos = lineNumber;
                zzaeF();
                zzaeG();
                i = this.pos;
                i2 = this.limit;
            } else {
                this.pos = lineNumber;
                return c;
            }
        }
    }

    private boolean zzc(char c) throws IOException {
        switch (c) {
            case '\t':
            case '\n':
            case '\f':
            case '\r':
            case ' ':
            case ',':
            case ':':
            case '[':
            case ']':
            case '{':
            case FTPReply.DATA_CONNECTION_ALREADY_OPEN /*125*/:
                break;
            case '#':
            case '/':
            case ';':
            case '=':
            case '\\':
                zzaeF();
                break;
            default:
                return true;
        }
        return false;
    }

    private String zzd(char c) throws IOException {
        char[] cArr = this.zzcuj;
        StringBuilder stringBuilder = new StringBuilder();
        do {
            int i = this.pos;
            int i2 = this.limit;
            int i3 = i;
            while (i3 < i2) {
                int i4 = i3 + 1;
                char c2 = cArr[i3];
                if (c2 == c) {
                    this.pos = i4;
                    stringBuilder.append(cArr, i, (i4 - i) - 1);
                    return stringBuilder.toString();
                }
                if (c2 == '\\') {
                    this.pos = i4;
                    stringBuilder.append(cArr, i, (i4 - i) - 1);
                    stringBuilder.append(zzaeH());
                    i = this.pos;
                    i2 = this.limit;
                    i4 = i;
                } else if (c2 == '\n') {
                    this.zzcuk++;
                    this.zzcul = i4;
                }
                i3 = i4;
            }
            stringBuilder.append(cArr, i, i3 - i);
            this.pos = i3;
        } while (zzra(1));
        throw zzkr("Unterminated string");
    }

    private void zze(char c) throws IOException {
        char[] cArr = this.zzcuj;
        do {
            int i = this.pos;
            int i2 = this.limit;
            int i3 = i;
            while (i3 < i2) {
                i = i3 + 1;
                char c2 = cArr[i3];
                if (c2 == c) {
                    this.pos = i;
                    return;
                }
                if (c2 == '\\') {
                    this.pos = i;
                    zzaeH();
                    i = this.pos;
                    i2 = this.limit;
                } else if (c2 == '\n') {
                    this.zzcuk++;
                    this.zzcul = i;
                }
                i3 = i;
            }
            this.pos = i3;
        } while (zzra(1));
        throw zzkr("Unterminated string");
    }

    private boolean zzkq(String str) throws IOException {
        while (true) {
            if (this.pos + str.length() > this.limit && !zzra(str.length())) {
                return false;
            }
            if (this.zzcuj[this.pos] == '\n') {
                this.zzcuk++;
                this.zzcul = this.pos + 1;
            } else {
                int i = 0;
                while (i < str.length()) {
                    if (this.zzcuj[this.pos + i] == str.charAt(i)) {
                        i++;
                    }
                }
                return true;
            }
            this.pos++;
        }
    }

    private IOException zzkr(String str) throws IOException {
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new zzbxa(new StringBuilder((String.valueOf(str).length() + 45) + String.valueOf(path).length()).append(str).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    private void zzqZ(int i) {
        if (this.zzcur == this.zzcuq.length) {
            Object obj = new int[(this.zzcur * 2)];
            Object obj2 = new int[(this.zzcur * 2)];
            Object obj3 = new String[(this.zzcur * 2)];
            System.arraycopy(this.zzcuq, 0, obj, 0, this.zzcur);
            System.arraycopy(this.zzcut, 0, obj2, 0, this.zzcur);
            System.arraycopy(this.zzcus, 0, obj3, 0, this.zzcur);
            this.zzcuq = obj;
            this.zzcut = obj2;
            this.zzcus = obj3;
        }
        int[] iArr = this.zzcuq;
        int i2 = this.zzcur;
        this.zzcur = i2 + 1;
        iArr[i2] = i;
    }

    private boolean zzra(int i) throws IOException {
        Object obj = this.zzcuj;
        this.zzcul -= this.pos;
        if (this.limit != this.pos) {
            this.limit -= this.pos;
            System.arraycopy(obj, this.pos, obj, 0, this.limit);
        } else {
            this.limit = 0;
        }
        this.pos = 0;
        do {
            int read = this.in.read(obj, this.limit, obj.length - this.limit);
            if (read == -1) {
                return false;
            }
            this.limit = read + this.limit;
            if (this.zzcuk == 0 && this.zzcul == 0 && this.limit > 0 && obj[0] == '﻿') {
                this.pos++;
                this.zzcul++;
                i++;
            }
        } while (this.limit < i);
        return true;
    }

    public void beginArray() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 3) {
            zzqZ(1);
            this.zzcut[this.zzcur - 1] = 0;
            this.zzcum = 0;
            return;
        }
        String valueOf = String.valueOf(zzaen());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 74) + String.valueOf(path).length()).append("Expected BEGIN_ARRAY but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    public void beginObject() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 1) {
            zzqZ(3);
            this.zzcum = 0;
            return;
        }
        String valueOf = String.valueOf(zzaen());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 75) + String.valueOf(path).length()).append("Expected BEGIN_OBJECT but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    public void close() throws IOException {
        this.zzcum = 0;
        this.zzcuq[0] = 8;
        this.zzcur = 1;
        this.in.close();
    }

    public void endArray() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 4) {
            this.zzcur--;
            int[] iArr = this.zzcut;
            int i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
            this.zzcum = 0;
            return;
        }
        String valueOf = String.valueOf(zzaen());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 72) + String.valueOf(path).length()).append("Expected END_ARRAY but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    public void endObject() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 2) {
            this.zzcur--;
            this.zzcus[this.zzcur] = null;
            int[] iArr = this.zzcut;
            int i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
            this.zzcum = 0;
            return;
        }
        String valueOf = String.valueOf(zzaen());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 73) + String.valueOf(path).length()).append("Expected END_OBJECT but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    public String getPath() {
        StringBuilder append = new StringBuilder().append('$');
        int i = this.zzcur;
        for (int i2 = 0; i2 < i; i2++) {
            switch (this.zzcuq[i2]) {
                case 1:
                case 2:
                    append.append('[').append(this.zzcut[i2]).append(']');
                    break;
                case 3:
                case 4:
                case 5:
                    append.append('.');
                    if (this.zzcus[i2] == null) {
                        break;
                    }
                    append.append(this.zzcus[i2]);
                    break;
                default:
                    break;
            }
        }
        return append.toString();
    }

    public boolean hasNext() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        return (i == 2 || i == 4) ? false : true;
    }

    public final boolean isLenient() {
        return this.zzcui;
    }

    public boolean nextBoolean() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 5) {
            this.zzcum = 0;
            int[] iArr = this.zzcut;
            i = this.zzcur - 1;
            iArr[i] = iArr[i] + 1;
            return true;
        } else if (i == 6) {
            this.zzcum = 0;
            int[] iArr2 = this.zzcut;
            r2 = this.zzcur - 1;
            iArr2[r2] = iArr2[r2] + 1;
            return false;
        } else {
            String valueOf = String.valueOf(zzaen());
            r2 = getLineNumber();
            int columnNumber = getColumnNumber();
            String path = getPath();
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 72) + String.valueOf(path).length()).append("Expected a boolean but was ").append(valueOf).append(" at line ").append(r2).append(" column ").append(columnNumber).append(" path ").append(path).toString());
        }
    }

    public double nextDouble() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 15) {
            this.zzcum = 0;
            int[] iArr = this.zzcut;
            int i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
            return (double) this.zzcun;
        }
        if (i == 16) {
            this.zzcup = new String(this.zzcuj, this.pos, this.zzcuo);
            this.pos += this.zzcuo;
        } else if (i == 8 || i == 9) {
            this.zzcup = zzd(i == 8 ? '\'' : '\"');
        } else if (i == 10) {
            this.zzcup = zzaeD();
        } else if (i != 11) {
            String valueOf = String.valueOf(zzaen());
            int lineNumber = getLineNumber();
            int columnNumber = getColumnNumber();
            String path = getPath();
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 71) + String.valueOf(path).length()).append("Expected a double but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
        }
        this.zzcum = 11;
        double parseDouble = Double.parseDouble(this.zzcup);
        if (this.zzcui || !(Double.isNaN(parseDouble) || Double.isInfinite(parseDouble))) {
            this.zzcup = null;
            this.zzcum = 0;
            int[] iArr2 = this.zzcut;
            columnNumber = this.zzcur - 1;
            iArr2[columnNumber] = iArr2[columnNumber] + 1;
            return parseDouble;
        }
        columnNumber = getLineNumber();
        int columnNumber2 = getColumnNumber();
        String path2 = getPath();
        throw new zzbxa(new StringBuilder(String.valueOf(path2).length() + 102).append("JSON forbids NaN and infinities: ").append(parseDouble).append(" at line ").append(columnNumber).append(" column ").append(columnNumber2).append(" path ").append(path2).toString());
    }

    public int nextInt() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        int[] iArr;
        int i2;
        if (i == 15) {
            i = (int) this.zzcun;
            if (this.zzcun != ((long) i)) {
                long j = this.zzcun;
                int lineNumber = getLineNumber();
                int columnNumber = getColumnNumber();
                String path = getPath();
                throw new NumberFormatException(new StringBuilder(String.valueOf(path).length() + 89).append("Expected an int but was ").append(j).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
            }
            this.zzcum = 0;
            iArr = this.zzcut;
            i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
        } else {
            String valueOf;
            int columnNumber2;
            String path2;
            if (i == 16) {
                this.zzcup = new String(this.zzcuj, this.pos, this.zzcuo);
                this.pos += this.zzcuo;
            } else if (i == 8 || i == 9) {
                this.zzcup = zzd(i == 8 ? '\'' : '\"');
                try {
                    i = Integer.parseInt(this.zzcup);
                    this.zzcum = 0;
                    iArr = this.zzcut;
                    i2 = this.zzcur - 1;
                    iArr[i2] = iArr[i2] + 1;
                } catch (NumberFormatException e) {
                }
            } else {
                valueOf = String.valueOf(zzaen());
                i2 = getLineNumber();
                columnNumber2 = getColumnNumber();
                path2 = getPath();
                throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(path2).length()).append("Expected an int but was ").append(valueOf).append(" at line ").append(i2).append(" column ").append(columnNumber2).append(" path ").append(path2).toString());
            }
            this.zzcum = 11;
            double parseDouble = Double.parseDouble(this.zzcup);
            i = (int) parseDouble;
            if (((double) i) != parseDouble) {
                valueOf = this.zzcup;
                i2 = getLineNumber();
                columnNumber2 = getColumnNumber();
                path2 = getPath();
                throw new NumberFormatException(new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(path2).length()).append("Expected an int but was ").append(valueOf).append(" at line ").append(i2).append(" column ").append(columnNumber2).append(" path ").append(path2).toString());
            }
            this.zzcup = null;
            this.zzcum = 0;
            iArr = this.zzcut;
            i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return i;
    }

    public long nextLong() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 15) {
            this.zzcum = 0;
            int[] iArr = this.zzcut;
            int i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
            return this.zzcun;
        }
        long parseLong;
        int i3;
        if (i == 16) {
            this.zzcup = new String(this.zzcuj, this.pos, this.zzcuo);
            this.pos += this.zzcuo;
        } else if (i == 8 || i == 9) {
            this.zzcup = zzd(i == 8 ? '\'' : '\"');
            try {
                parseLong = Long.parseLong(this.zzcup);
                this.zzcum = 0;
                int[] iArr2 = this.zzcut;
                i3 = this.zzcur - 1;
                iArr2[i3] = iArr2[i3] + 1;
                return parseLong;
            } catch (NumberFormatException e) {
            }
        } else {
            String valueOf = String.valueOf(zzaen());
            int lineNumber = getLineNumber();
            i3 = getColumnNumber();
            String path = getPath();
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(path).length()).append("Expected a long but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(i3).append(" path ").append(path).toString());
        }
        this.zzcum = 11;
        double parseDouble = Double.parseDouble(this.zzcup);
        parseLong = (long) parseDouble;
        if (((double) parseLong) != parseDouble) {
            valueOf = this.zzcup;
            lineNumber = getLineNumber();
            i3 = getColumnNumber();
            path = getPath();
            throw new NumberFormatException(new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(path).length()).append("Expected a long but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(i3).append(" path ").append(path).toString());
        }
        this.zzcup = null;
        this.zzcum = 0;
        iArr2 = this.zzcut;
        i3 = this.zzcur - 1;
        iArr2[i3] = iArr2[i3] + 1;
        return parseLong;
    }

    public String nextName() throws IOException {
        String zzaeD;
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 14) {
            zzaeD = zzaeD();
        } else if (i == 12) {
            zzaeD = zzd('\'');
        } else if (i == 13) {
            zzaeD = zzd('\"');
        } else {
            String valueOf = String.valueOf(zzaen());
            int lineNumber = getLineNumber();
            int columnNumber = getColumnNumber();
            String path = getPath();
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(path).length()).append("Expected a name but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
        }
        this.zzcum = 0;
        this.zzcus[this.zzcur - 1] = zzaeD;
        return zzaeD;
    }

    public void nextNull() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 7) {
            this.zzcum = 0;
            int[] iArr = this.zzcut;
            int i2 = this.zzcur - 1;
            iArr[i2] = iArr[i2] + 1;
            return;
        }
        String valueOf = String.valueOf(zzaen());
        int lineNumber = getLineNumber();
        int columnNumber = getColumnNumber();
        String path = getPath();
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 67) + String.valueOf(path).length()).append("Expected null but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
    }

    public String nextString() throws IOException {
        String zzaeD;
        int lineNumber;
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        if (i == 10) {
            zzaeD = zzaeD();
        } else if (i == 8) {
            zzaeD = zzd('\'');
        } else if (i == 9) {
            zzaeD = zzd('\"');
        } else if (i == 11) {
            zzaeD = this.zzcup;
            this.zzcup = null;
        } else if (i == 15) {
            zzaeD = Long.toString(this.zzcun);
        } else if (i == 16) {
            zzaeD = new String(this.zzcuj, this.pos, this.zzcuo);
            this.pos += this.zzcuo;
        } else {
            String valueOf = String.valueOf(zzaen());
            lineNumber = getLineNumber();
            int columnNumber = getColumnNumber();
            String path = getPath();
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 71) + String.valueOf(path).length()).append("Expected a string but was ").append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(columnNumber).append(" path ").append(path).toString());
        }
        this.zzcum = 0;
        int[] iArr = this.zzcut;
        lineNumber = this.zzcur - 1;
        iArr[lineNumber] = iArr[lineNumber] + 1;
        return zzaeD;
    }

    public final void setLenient(boolean z) {
        this.zzcui = z;
    }

    public void skipValue() throws IOException {
        int i = 0;
        do {
            int i2 = this.zzcum;
            if (i2 == 0) {
                i2 = zzaeA();
            }
            if (i2 == 3) {
                zzqZ(1);
                i++;
            } else if (i2 == 1) {
                zzqZ(3);
                i++;
            } else if (i2 == 4) {
                this.zzcur--;
                i--;
            } else if (i2 == 2) {
                this.zzcur--;
                i--;
            } else if (i2 == 14 || i2 == 10) {
                zzaeE();
            } else if (i2 == 8 || i2 == 12) {
                zze('\'');
            } else if (i2 == 9 || i2 == 13) {
                zze('\"');
            } else if (i2 == 16) {
                this.pos += this.zzcuo;
            }
            this.zzcum = 0;
        } while (i != 0);
        int[] iArr = this.zzcut;
        int i3 = this.zzcur - 1;
        iArr[i3] = iArr[i3] + 1;
        this.zzcus[this.zzcur - 1] = "null";
    }

    public String toString() {
        String valueOf = String.valueOf(getClass().getSimpleName());
        int lineNumber = getLineNumber();
        return new StringBuilder(String.valueOf(valueOf).length() + 39).append(valueOf).append(" at line ").append(lineNumber).append(" column ").append(getColumnNumber()).toString();
    }

    public zzbwy zzaen() throws IOException {
        int i = this.zzcum;
        if (i == 0) {
            i = zzaeA();
        }
        switch (i) {
            case 1:
                return zzbwy.BEGIN_OBJECT;
            case 2:
                return zzbwy.END_OBJECT;
            case 3:
                return zzbwy.BEGIN_ARRAY;
            case 4:
                return zzbwy.END_ARRAY;
            case 5:
            case 6:
                return zzbwy.BOOLEAN;
            case 7:
                return zzbwy.NULL;
            case 8:
            case 9:
            case 10:
            case 11:
                return zzbwy.STRING;
            case 12:
            case 13:
            case 14:
                return zzbwy.NAME;
            case 15:
            case 16:
                return zzbwy.NUMBER;
            case 17:
                return zzbwy.END_DOCUMENT;
            default:
                throw new AssertionError();
        }
    }
}
