package com.google.android.gms.internal;

public class zzbzc {
    public static final zzbzc zzcyh = new C05841();

    static class C05841 extends zzbzc {
        C05841() {
        }
    }
}
