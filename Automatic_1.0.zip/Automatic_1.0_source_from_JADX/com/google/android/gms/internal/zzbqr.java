package com.google.android.gms.internal;

public interface zzbqr<T> {
    public static final zzbqr<Object> zzchC = new C05381();

    class C05381 implements zzbqr<Object> {
        C05381() {
        }

        public boolean zzat(Object obj) {
            return true;
        }
    }

    boolean zzat(T t);
}
