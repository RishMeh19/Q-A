package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public abstract class zzbsy implements zzbpm {
    private ScheduledThreadPoolExecutor zzckz = new ScheduledThreadPoolExecutor(this, 1, new zza()) {
        final /* synthetic */ zzbsy zzckA;

        protected void afterExecute(Runnable runnable, Throwable th) {
            super.afterExecute(runnable, th);
            if (th == null && (runnable instanceof Future)) {
                Future future = (Future) runnable;
                try {
                    if (future.isDone()) {
                        future.get();
                    }
                } catch (CancellationException e) {
                } catch (ExecutionException e2) {
                    th = e2.getCause();
                } catch (InterruptedException e3) {
                    Thread.currentThread().interrupt();
                }
            }
            if (th != null) {
                this.zzckA.zzj(th);
            }
        }
    };

    private class zza implements ThreadFactory {
        final /* synthetic */ zzbsy zzckA;

        class C03131 implements UncaughtExceptionHandler {
            final /* synthetic */ zza zzckB;

            C03131(zza com_google_android_gms_internal_zzbsy_zza) {
                this.zzckB = com_google_android_gms_internal_zzbsy_zza;
            }

            public void uncaughtException(Thread thread, Throwable th) {
                this.zzckB.zzckA.zzj(th);
            }
        }

        private zza(zzbsy com_google_android_gms_internal_zzbsy) {
            this.zzckA = com_google_android_gms_internal_zzbsy;
        }

        public Thread newThread(Runnable runnable) {
            Thread newThread = this.zzckA.getThreadFactory().newThread(runnable);
            zzbpt zzYQ = this.zzckA.zzYQ();
            zzYQ.zza(newThread, "FirebaseDatabaseWorker");
            zzYQ.zza(newThread, true);
            zzYQ.zza(newThread, new C03131(this));
            return newThread;
        }
    }

    public zzbsy() {
        this.zzckz.setKeepAliveTime(3, TimeUnit.SECONDS);
    }

    public static String zzl(Throwable th) {
        if (th instanceof OutOfMemoryError) {
            return "Firebase Database encountered an OutOfMemoryError. You may need to reduce the amount of data you are syncing to the client (e.g. by using queries or syncing a deeper path). See https://firebase.google.com/docs/database/ios/structure-data#best_practices_for_data_structure and https://firebase.google.com/docs/database/android/retrieve-data#filtering_data";
        }
        if (th instanceof DatabaseException) {
            return "";
        }
        String valueOf = String.valueOf(FirebaseDatabase.getSdkVersion());
        return new StringBuilder(String.valueOf(valueOf).length() + 104).append("Uncaught exception in Firebase Database runloop (").append(valueOf).append("). Please report to firebase-database-client@google.com").toString();
    }

    protected ThreadFactory getThreadFactory() {
        return Executors.defaultThreadFactory();
    }

    public void restart() {
        this.zzckz.setCorePoolSize(1);
    }

    public void shutdown() {
        this.zzckz.setCorePoolSize(0);
    }

    public ScheduledExecutorService zzXv() {
        return this.zzckz;
    }

    protected zzbpt zzYQ() {
        return zzbpt.zzcgl;
    }

    public abstract void zzj(Throwable th);

    public void zzs(Runnable runnable) {
        this.zzckz.execute(runnable);
    }
}
