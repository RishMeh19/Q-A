package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbrj.zza;
import java.util.Iterator;

public class zzbri implements zzbrj {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbri.class.desiredAssertionStatus());
    private final int limit;
    private final zzbrk zzciE;
    private final boolean zzciF;
    private final zzbrw zzcia;

    public zzbri(zzbrb com_google_android_gms_internal_zzbrb) {
        this.zzciE = new zzbrk(com_google_android_gms_internal_zzbrb);
        this.zzcia = com_google_android_gms_internal_zzbrb.zzaal();
        this.limit = com_google_android_gms_internal_zzbrb.getLimit();
        this.zzciF = !com_google_android_gms_internal_zzbrb.zzaan();
    }

    private zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc, zza com_google_android_gms_internal_zzbrj_zza, zzbrg com_google_android_gms_internal_zzbrg) {
        if ($assertionsDisabled || com_google_android_gms_internal_zzbrx.zzWK().getChildCount() == this.limit) {
            zzbsb com_google_android_gms_internal_zzbsb = new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc);
            zzbsb zzabg = this.zzciF ? com_google_android_gms_internal_zzbrx.zzabg() : com_google_android_gms_internal_zzbrx.zzabh();
            boolean zza = this.zzciE.zza(com_google_android_gms_internal_zzbsb);
            if (com_google_android_gms_internal_zzbrx.zzWK().zzk(com_google_android_gms_internal_zzbrq)) {
                zzbsc zzm = com_google_android_gms_internal_zzbrx.zzWK().zzm(com_google_android_gms_internal_zzbrq);
                zzbsb zza2 = com_google_android_gms_internal_zzbrj_zza.zza(this.zzcia, zzabg, this.zzciF);
                while (zza2 != null && (zza2.zzabl().equals(com_google_android_gms_internal_zzbrq) || com_google_android_gms_internal_zzbrx.zzWK().zzk(zza2.zzabl()))) {
                    zza2 = com_google_android_gms_internal_zzbrj_zza.zza(this.zzcia, zza2, this.zzciF);
                }
                Object obj = (!zza || com_google_android_gms_internal_zzbsc.isEmpty() || (zza2 == null ? 1 : this.zzcia.zza(zza2, com_google_android_gms_internal_zzbsb, this.zzciF)) < 0) ? null : 1;
                if (obj != null) {
                    if (com_google_android_gms_internal_zzbrg != null) {
                        com_google_android_gms_internal_zzbrg.zza(zzbqw.zza(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc, zzm));
                    }
                    return com_google_android_gms_internal_zzbrx.zzh(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc);
                }
                if (com_google_android_gms_internal_zzbrg != null) {
                    com_google_android_gms_internal_zzbrg.zza(zzbqw.zzd(com_google_android_gms_internal_zzbrq, zzm));
                }
                com_google_android_gms_internal_zzbrx = com_google_android_gms_internal_zzbrx.zzh(com_google_android_gms_internal_zzbrq, zzbrv.zzabb());
                obj = (zza2 == null || !this.zzciE.zza(zza2)) ? null : 1;
                if (obj == null) {
                    return com_google_android_gms_internal_zzbrx;
                }
                if (com_google_android_gms_internal_zzbrg != null) {
                    com_google_android_gms_internal_zzbrg.zza(zzbqw.zzc(zza2.zzabl(), zza2.zzWK()));
                }
                return com_google_android_gms_internal_zzbrx.zzh(zza2.zzabl(), zza2.zzWK());
            } else if (com_google_android_gms_internal_zzbsc.isEmpty() || !zza || this.zzcia.zza(zzabg, com_google_android_gms_internal_zzbsb, this.zzciF) < 0) {
                return com_google_android_gms_internal_zzbrx;
            } else {
                if (com_google_android_gms_internal_zzbrg != null) {
                    com_google_android_gms_internal_zzbrg.zza(zzbqw.zzd(zzabg.zzabl(), zzabg.zzWK()));
                    com_google_android_gms_internal_zzbrg.zza(zzbqw.zzc(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc));
                }
                return com_google_android_gms_internal_zzbrx.zzh(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc).zzh(zzabg.zzabl(), zzbrv.zzabb());
            }
        }
        throw new AssertionError();
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc, zzbph com_google_android_gms_internal_zzbph, zza com_google_android_gms_internal_zzbrj_zza, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbsc zzabb = !this.zzciE.zza(new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc)) ? zzbrv.zzabb() : com_google_android_gms_internal_zzbsc;
        return com_google_android_gms_internal_zzbrx.zzWK().zzm(com_google_android_gms_internal_zzbrq).equals(zzabb) ? com_google_android_gms_internal_zzbrx : com_google_android_gms_internal_zzbrx.zzWK().getChildCount() < this.limit ? this.zzciE.zzaaB().zza(com_google_android_gms_internal_zzbrx, com_google_android_gms_internal_zzbrq, zzabb, com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbrj_zza, com_google_android_gms_internal_zzbrg) : zza(com_google_android_gms_internal_zzbrx, com_google_android_gms_internal_zzbrq, zzabb, com_google_android_gms_internal_zzbrj_zza, com_google_android_gms_internal_zzbrg);
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrx com_google_android_gms_internal_zzbrx2, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbrx zza;
        if (com_google_android_gms_internal_zzbrx2.zzWK().zzaaP() || com_google_android_gms_internal_zzbrx2.zzWK().isEmpty()) {
            zza = zzbrx.zza(zzbrv.zzabb(), this.zzcia);
        } else {
            Object zzaaD;
            Iterator it;
            int i;
            zzbrx zzo = com_google_android_gms_internal_zzbrx2.zzo(zzbsg.zzabn());
            if (this.zzciF) {
                Iterator zzWX = com_google_android_gms_internal_zzbrx2.zzWX();
                Object zzaaE = this.zzciE.zzaaE();
                zzaaD = this.zzciE.zzaaD();
                it = zzWX;
                i = -1;
            } else {
                Iterator it2 = com_google_android_gms_internal_zzbrx2.iterator();
                zzbsb zzaaD2 = this.zzciE.zzaaD();
                zzbsb zzaaE2 = this.zzciE.zzaaE();
                zzbsb com_google_android_gms_internal_zzbsb = zzaaD2;
                i = 1;
                it = it2;
            }
            int i2 = 0;
            zza = zzo;
            Object obj = null;
            while (it.hasNext()) {
                int i3;
                zzbrx com_google_android_gms_internal_zzbrx3;
                zzbsb com_google_android_gms_internal_zzbsb2 = (zzbsb) it.next();
                if (obj == null && this.zzcia.compare(r5, com_google_android_gms_internal_zzbsb2) * i <= 0) {
                    obj = 1;
                }
                Object obj2 = (obj == null || i2 >= this.limit || this.zzcia.compare(com_google_android_gms_internal_zzbsb2, zzaaD) * i > 0) ? null : 1;
                if (obj2 != null) {
                    i3 = i2 + 1;
                    com_google_android_gms_internal_zzbrx3 = zza;
                } else {
                    zza = zza.zzh(com_google_android_gms_internal_zzbsb2.zzabl(), zzbrv.zzabb());
                    i3 = i2;
                    com_google_android_gms_internal_zzbrx3 = zza;
                }
                zza = com_google_android_gms_internal_zzbrx3;
                i2 = i3;
            }
        }
        return this.zzciE.zzaaB().zza(com_google_android_gms_internal_zzbrx, zza, com_google_android_gms_internal_zzbrg);
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbsc com_google_android_gms_internal_zzbsc) {
        return com_google_android_gms_internal_zzbrx;
    }

    public zzbrj zzaaB() {
        return this.zzciE.zzaaB();
    }

    public boolean zzaaC() {
        return true;
    }

    public zzbrw zzaal() {
        return this.zzcia;
    }
}
