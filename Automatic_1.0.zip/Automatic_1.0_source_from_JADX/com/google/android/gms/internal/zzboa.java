package com.google.android.gms.internal;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class zzboa<T> implements Iterable<T> {
    private final zzbny<T, Void> zzcaY;

    private static class zza<T> implements Iterator<T> {
        final Iterator<Entry<T, Void>> zzcaZ;

        public zza(Iterator<Entry<T, Void>> it) {
            this.zzcaZ = it;
        }

        public boolean hasNext() {
            return this.zzcaZ.hasNext();
        }

        public T next() {
            return ((Entry) this.zzcaZ.next()).getKey();
        }

        public void remove() {
            this.zzcaZ.remove();
        }
    }

    private zzboa(zzbny<T, Void> com_google_android_gms_internal_zzbny_T__java_lang_Void) {
        this.zzcaY = com_google_android_gms_internal_zzbny_T__java_lang_Void;
    }

    public zzboa(List<T> list, Comparator<T> comparator) {
        this.zzcaY = com.google.android.gms.internal.zzbny.zza.zzb(list, Collections.emptyMap(), com.google.android.gms.internal.zzbny.zza.zzWY(), comparator);
    }

    public Iterator<T> iterator() {
        return new zza(this.zzcaY.iterator());
    }

    public Iterator<T> zzWX() {
        return new zza(this.zzcaY.zzWX());
    }

    public T zzWZ() {
        return this.zzcaY.zzWV();
    }

    public T zzXa() {
        return this.zzcaY.zzWW();
    }

    public zzboa<T> zzam(T t) {
        zzbny zzah = this.zzcaY.zzah(t);
        return zzah == this.zzcaY ? this : new zzboa(zzah);
    }

    public zzboa<T> zzan(T t) {
        return new zzboa(this.zzcaY.zzi(t, null));
    }

    public T zzao(T t) {
        return this.zzcaY.zzai(t);
    }
}
