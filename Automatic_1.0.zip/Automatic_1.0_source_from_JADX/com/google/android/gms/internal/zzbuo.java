package com.google.android.gms.internal;

public class zzbuo implements zzbun {
    public void zzqX(int i) throws InterruptedException {
        Thread.sleep((long) i);
    }
}
