package com.google.android.gms.internal;

public final class zzbvi extends zzbvg {
    public static final zzbvi zzcrn = new zzbvi();

    public boolean equals(Object obj) {
        return this == obj || (obj instanceof zzbvi);
    }

    public int hashCode() {
        return zzbvi.class.hashCode();
    }
}
