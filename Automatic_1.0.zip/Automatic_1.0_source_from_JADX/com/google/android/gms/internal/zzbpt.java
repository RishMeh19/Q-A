package com.google.android.gms.internal;

import java.lang.Thread.UncaughtExceptionHandler;

public interface zzbpt {
    public static final zzbpt zzcgl = new C05241();

    class C05241 implements zzbpt {
        C05241() {
        }

        public void zza(Thread thread, String str) {
            thread.setName(str);
        }

        public void zza(Thread thread, UncaughtExceptionHandler uncaughtExceptionHandler) {
            thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
        }

        public void zza(Thread thread, boolean z) {
            thread.setDaemon(z);
        }
    }

    void zza(Thread thread, String str);

    void zza(Thread thread, UncaughtExceptionHandler uncaughtExceptionHandler);

    void zza(Thread thread, boolean z);
}
