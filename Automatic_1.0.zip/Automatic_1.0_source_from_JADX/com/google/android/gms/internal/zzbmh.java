package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.List;

public class zzbmh extends zza {
    public static final Creator<zzbmh> CREATOR = new zzbmi();
    @zzbvv("registered")
    private boolean zzagw;
    @zzbmb
    public final int zzaiI;
    @zzbvv("providerId")
    private String zzbYA;
    @zzbvv("forExistingProvider")
    private boolean zzbYB;
    @zzbvv("allProviders")
    private zzbmv zzbYC;
    @zzbvv("authUri")
    private String zzbYz;

    public zzbmh() {
        this.zzaiI = 1;
        this.zzbYC = zzbmv.zzWn();
    }

    zzbmh(int i, String str, boolean z, String str2, boolean z2, zzbmv com_google_android_gms_internal_zzbmv) {
        this.zzaiI = i;
        this.zzbYz = str;
        this.zzagw = z;
        this.zzbYA = str2;
        this.zzbYB = z2;
        this.zzbYC = com_google_android_gms_internal_zzbmv == null ? zzbmv.zzWn() : zzbmv.zza(com_google_android_gms_internal_zzbmv);
    }

    @Nullable
    public List<String> getAllProviders() {
        return this.zzbYC.zzWm();
    }

    @Nullable
    public String getProviderId() {
        return this.zzbYA;
    }

    public boolean isRegistered() {
        return this.zzagw;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmi.zza(this, parcel, i);
    }

    @Nullable
    public String zzVY() {
        return this.zzbYz;
    }

    public boolean zzVZ() {
        return this.zzbYB;
    }

    public zzbmv zzWa() {
        return this.zzbYC;
    }
}
