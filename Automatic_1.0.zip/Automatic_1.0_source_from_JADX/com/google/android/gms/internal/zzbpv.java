package com.google.android.gms.internal;

public class zzbpv {
    private final zzbph zzcai;
    private final long zzcgp;
    private final zzbsc zzcgq;
    private final zzboy zzcgr;
    private final boolean zzcgs;

    public zzbpv(long j, zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        this.zzcgp = j;
        this.zzcai = com_google_android_gms_internal_zzbph;
        this.zzcgq = null;
        this.zzcgr = com_google_android_gms_internal_zzboy;
        this.zzcgs = true;
    }

    public zzbpv(long j, zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, boolean z) {
        this.zzcgp = j;
        this.zzcai = com_google_android_gms_internal_zzbph;
        this.zzcgq = com_google_android_gms_internal_zzbsc;
        this.zzcgr = null;
        this.zzcgs = z;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbpv com_google_android_gms_internal_zzbpv = (zzbpv) obj;
        if (this.zzcgp != com_google_android_gms_internal_zzbpv.zzcgp) {
            return false;
        }
        if (!this.zzcai.equals(com_google_android_gms_internal_zzbpv.zzcai)) {
            return false;
        }
        if (this.zzcgs != com_google_android_gms_internal_zzbpv.zzcgs) {
            return false;
        }
        if (!this.zzcgq == null ? this.zzcgq.equals(com_google_android_gms_internal_zzbpv.zzcgq) : com_google_android_gms_internal_zzbpv.zzcgq == null) {
            return false;
        }
        if (this.zzcgr != null) {
            if (this.zzcgr.equals(com_google_android_gms_internal_zzbpv.zzcgr)) {
                return true;
            }
        } else if (com_google_android_gms_internal_zzbpv.zzcgr == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int i = 0;
        int hashCode = ((this.zzcgq != null ? this.zzcgq.hashCode() : 0) + (((((Long.valueOf(this.zzcgp).hashCode() * 31) + Boolean.valueOf(this.zzcgs).hashCode()) * 31) + this.zzcai.hashCode()) * 31)) * 31;
        if (this.zzcgr != null) {
            i = this.zzcgr.hashCode();
        }
        return hashCode + i;
    }

    public boolean isVisible() {
        return this.zzcgs;
    }

    public String toString() {
        long j = this.zzcgp;
        String valueOf = String.valueOf(this.zzcai);
        boolean z = this.zzcgs;
        String valueOf2 = String.valueOf(this.zzcgq);
        String valueOf3 = String.valueOf(this.zzcgr);
        return new StringBuilder(((String.valueOf(valueOf).length() + 78) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("UserWriteRecord{id=").append(j).append(" path=").append(valueOf).append(" visible=").append(z).append(" overwrite=").append(valueOf2).append(" merge=").append(valueOf3).append("}").toString();
    }

    public zzbph zzWO() {
        return this.zzcai;
    }

    public long zzZo() {
        return this.zzcgp;
    }

    public zzbsc zzZp() {
        if (this.zzcgq != null) {
            return this.zzcgq;
        }
        throw new IllegalArgumentException("Can't access overwrite when write is a merge!");
    }

    public zzboy zzZq() {
        if (this.zzcgr != null) {
            return this.zzcgr;
        }
        throw new IllegalArgumentException("Can't access merge when write is an overwrite!");
    }

    public boolean zzZr() {
        return this.zzcgq != null;
    }
}
