package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbvf<T> {
    T zzb(zzbvg com_google_android_gms_internal_zzbvg, Type type, zzbve com_google_android_gms_internal_zzbve) throws zzbvk;
}
