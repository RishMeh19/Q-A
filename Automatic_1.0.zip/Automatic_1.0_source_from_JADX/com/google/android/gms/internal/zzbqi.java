package com.google.android.gms.internal;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;

public class zzbqi implements zzbql {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbqi.class.desiredAssertionStatus());
    private final zzbrn zzcaH;
    private final zzbqm zzchb;
    private final zzbqp zzchc;
    private final zzbqh zzchd;
    private long zzche;

    public zzbqi(zzbpa com_google_android_gms_internal_zzbpa, zzbqm com_google_android_gms_internal_zzbqm, zzbqh com_google_android_gms_internal_zzbqh) {
        this(com_google_android_gms_internal_zzbpa, com_google_android_gms_internal_zzbqm, com_google_android_gms_internal_zzbqh, new zzbsx());
    }

    public zzbqi(zzbpa com_google_android_gms_internal_zzbpa, zzbqm com_google_android_gms_internal_zzbqm, zzbqh com_google_android_gms_internal_zzbqh, zzbsw com_google_android_gms_internal_zzbsw) {
        this.zzche = 0;
        this.zzchb = com_google_android_gms_internal_zzbqm;
        this.zzcaH = com_google_android_gms_internal_zzbpa.zziV("Persistence");
        this.zzchc = new zzbqp(this.zzchb, this.zzcaH, com_google_android_gms_internal_zzbsw);
        this.zzchd = com_google_android_gms_internal_zzbqh;
    }

    private void zzZJ() {
        this.zzche++;
        if (this.zzchd.zzaR(this.zzche)) {
            if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("Reached prune check threshold.", new Object[0]);
            }
            this.zzche = 0;
            int i = 1;
            long zzWR = this.zzchb.zzWR();
            if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("Cache size: " + zzWR, new Object[0]);
            }
            while (i != 0 && this.zzchd.zzk(r2, this.zzchc.zzZN())) {
                zzbqn zza = this.zzchc.zza(this.zzchd);
                if (zza.zzZK()) {
                    this.zzchb.zza(zzbph.zzYR(), zza);
                } else {
                    i = 0;
                }
                zzWR = this.zzchb.zzWR();
                if (this.zzcaH.zzaaF()) {
                    this.zzcaH.zzi("Cache size after prune: " + zzWR, new Object[0]);
                }
            }
        }
    }

    public List<zzbpv> zzWQ() {
        return this.zzchb.zzWQ();
    }

    public void zzWT() {
        this.zzchb.zzWT();
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, long j) {
        this.zzchb.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy, j);
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, long j) {
        this.zzchb.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc, j);
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbsc com_google_android_gms_internal_zzbsc) {
        if (com_google_android_gms_internal_zzbrc.zzaap()) {
            this.zzchb.zza(com_google_android_gms_internal_zzbrc.zzWO(), com_google_android_gms_internal_zzbsc);
        } else {
            this.zzchb.zzb(com_google_android_gms_internal_zzbrc.zzWO(), com_google_android_gms_internal_zzbsc);
        }
        zzi(com_google_android_gms_internal_zzbrc);
        zzZJ();
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, Set<zzbrq> set) {
        if ($assertionsDisabled || !com_google_android_gms_internal_zzbrc.zzaap()) {
            zzbqo zzl = this.zzchc.zzl(com_google_android_gms_internal_zzbrc);
            if ($assertionsDisabled || (zzl != null && zzl.zzbqZ)) {
                this.zzchb.zza(zzl.id, (Set) set);
                return;
            }
            throw new AssertionError("We only expect tracked keys for currently-active queries.");
        }
        throw new AssertionError("We should only track keys for filtered queries.");
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, Set<zzbrq> set, Set<zzbrq> set2) {
        if ($assertionsDisabled || !com_google_android_gms_internal_zzbrc.zzaap()) {
            zzbqo zzl = this.zzchc.zzl(com_google_android_gms_internal_zzbrc);
            if ($assertionsDisabled || (zzl != null && zzl.zzbqZ)) {
                this.zzchb.zza(zzl.id, (Set) set, (Set) set2);
                return;
            }
            throw new AssertionError("We only expect tracked keys for currently-active queries.");
        }
        throw new AssertionError("We should only track keys for filtered queries.");
    }

    public void zzaE(long j) {
        this.zzchb.zzaE(j);
    }

    public void zzc(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        Iterator it = com_google_android_gms_internal_zzboy.iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            zzk(com_google_android_gms_internal_zzbph.zzh((zzbph) entry.getKey()), (zzbsc) entry.getValue());
        }
    }

    public void zzd(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        this.zzchb.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy);
        zzZJ();
    }

    public zzbqu zzf(zzbrc com_google_android_gms_internal_zzbrc) {
        boolean z;
        Set zzaH;
        if (this.zzchc.zzo(com_google_android_gms_internal_zzbrc)) {
            zzbqo zzl = this.zzchc.zzl(com_google_android_gms_internal_zzbrc);
            zzaH = (com_google_android_gms_internal_zzbrc.zzaap() || zzl == null || !zzl.zzcho) ? null : this.zzchb.zzaH(zzl.id);
            z = true;
        } else {
            zzaH = this.zzchc.zzB(com_google_android_gms_internal_zzbrc.zzWO());
            z = false;
        }
        zzbsc zza = this.zzchb.zza(com_google_android_gms_internal_zzbrc.zzWO());
        if (r0 == null) {
            return new zzbqu(zzbrx.zza(zza, com_google_android_gms_internal_zzbrc.zzaal()), true, false);
        }
        zzbsc zzabb = zzbrv.zzabb();
        for (zzbrq com_google_android_gms_internal_zzbrq : r0) {
            zzabb = zzabb.zze(com_google_android_gms_internal_zzbrq, zza.zzm(com_google_android_gms_internal_zzbrq));
        }
        return new zzbqu(zzbrx.zza(zzabb, com_google_android_gms_internal_zzbrc.zzaal()), z, true);
    }

    public <T> T zzf(Callable<T> callable) {
        this.zzchb.beginTransaction();
        try {
            T call = callable.call();
            this.zzchb.setTransactionSuccessful();
            this.zzchb.endTransaction();
            return call;
        } catch (Throwable th) {
            this.zzchb.endTransaction();
        }
    }

    public void zzg(zzbrc com_google_android_gms_internal_zzbrc) {
        this.zzchc.zzg(com_google_android_gms_internal_zzbrc);
    }

    public void zzh(zzbrc com_google_android_gms_internal_zzbrc) {
        this.zzchc.zzh(com_google_android_gms_internal_zzbrc);
    }

    public void zzi(zzbrc com_google_android_gms_internal_zzbrc) {
        if (com_google_android_gms_internal_zzbrc.zzaap()) {
            this.zzchc.zzA(com_google_android_gms_internal_zzbrc.zzWO());
        } else {
            this.zzchc.zzn(com_google_android_gms_internal_zzbrc);
        }
    }

    public void zzk(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
        if (!this.zzchc.zzD(com_google_android_gms_internal_zzbph)) {
            this.zzchb.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc);
            this.zzchc.zzC(com_google_android_gms_internal_zzbph);
        }
    }
}
