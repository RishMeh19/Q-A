package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqy.zza;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class zzbpx extends zzbpc {
    private final zzbpj zzcab;
    private final zzbrc zzcdH;
    private final ValueEventListener zzcgv;

    public zzbpx(zzbpj com_google_android_gms_internal_zzbpj, ValueEventListener valueEventListener, zzbrc com_google_android_gms_internal_zzbrc) {
        this.zzcab = com_google_android_gms_internal_zzbpj;
        this.zzcgv = valueEventListener;
        this.zzcdH = com_google_android_gms_internal_zzbrc;
    }

    public boolean equals(Object obj) {
        return (obj instanceof zzbpx) && ((zzbpx) obj).zzcgv.equals(this.zzcgv) && ((zzbpx) obj).zzcab.equals(this.zzcab) && ((zzbpx) obj).zzcdH.equals(this.zzcdH);
    }

    public int hashCode() {
        return (((this.zzcgv.hashCode() * 31) + this.zzcab.hashCode()) * 31) + this.zzcdH.hashCode();
    }

    public String toString() {
        return "ValueEventRegistration";
    }

    public zzbrc zzYp() {
        return this.zzcdH;
    }

    public zzbpc zza(zzbrc com_google_android_gms_internal_zzbrc) {
        return new zzbpx(this.zzcab, this.zzcgv, com_google_android_gms_internal_zzbrc);
    }

    public zzbqx zza(zzbqw com_google_android_gms_internal_zzbqw, zzbrc com_google_android_gms_internal_zzbrc) {
        return new zzbqx(zza.VALUE, this, com.google.firebase.database.zza.zza(com.google.firebase.database.zza.zza(this.zzcab, com_google_android_gms_internal_zzbrc.zzWO()), com_google_android_gms_internal_zzbqw.zzZU()), null);
    }

    public void zza(zzbqx com_google_android_gms_internal_zzbqx) {
        if (!zzYN()) {
            this.zzcgv.onDataChange(com_google_android_gms_internal_zzbqx.zzaaa());
        }
    }

    public void zza(DatabaseError databaseError) {
        this.zzcgv.onCancelled(databaseError);
    }

    public boolean zza(zza com_google_android_gms_internal_zzbqy_zza) {
        return com_google_android_gms_internal_zzbqy_zza == zza.VALUE;
    }

    public boolean zzc(zzbpc com_google_android_gms_internal_zzbpc) {
        return (com_google_android_gms_internal_zzbpc instanceof zzbpx) && ((zzbpx) com_google_android_gms_internal_zzbpc).zzcgv.equals(this.zzcgv);
    }
}
