package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class zzbwp implements zzbvt {
    private final zzbwa zzcqW;
    private final boolean zzcsL;

    private final class zza<K, V> extends zzbvs<Map<K, V>> {
        private final zzbwf<? extends Map<K, V>> zzcsD;
        private final zzbvs<K> zzcsM;
        private final zzbvs<V> zzcsN;
        final /* synthetic */ zzbwp zzcsO;

        public zza(zzbwp com_google_android_gms_internal_zzbwp, zzbva com_google_android_gms_internal_zzbva, Type type, zzbvs<K> com_google_android_gms_internal_zzbvs_K, Type type2, zzbvs<V> com_google_android_gms_internal_zzbvs_V, zzbwf<? extends Map<K, V>> com_google_android_gms_internal_zzbwf__extends_java_util_Map_K__V) {
            this.zzcsO = com_google_android_gms_internal_zzbwp;
            this.zzcsM = new zzbwu(com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbvs_K, type);
            this.zzcsN = new zzbwu(com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbvs_V, type2);
            this.zzcsD = com_google_android_gms_internal_zzbwf__extends_java_util_Map_K__V;
        }

        private String zze(zzbvg com_google_android_gms_internal_zzbvg) {
            if (com_google_android_gms_internal_zzbvg.zzadU()) {
                zzbvm zzadY = com_google_android_gms_internal_zzbvg.zzadY();
                if (zzadY.zzaeb()) {
                    return String.valueOf(zzadY.zzadQ());
                }
                if (zzadY.zzaea()) {
                    return Boolean.toString(zzadY.getAsBoolean());
                }
                if (zzadY.zzaec()) {
                    return zzadY.zzadR();
                }
                throw new AssertionError();
            } else if (com_google_android_gms_internal_zzbvg.zzadV()) {
                return "null";
            } else {
                throw new AssertionError();
            }
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, Map<K, V> map) throws IOException {
            int i = 0;
            if (map == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
            } else if (this.zzcsO.zzcsL) {
                List arrayList = new ArrayList(map.size());
                List arrayList2 = new ArrayList(map.size());
                int i2 = 0;
                for (Entry entry : map.entrySet()) {
                    zzbvg zzaP = this.zzcsM.zzaP(entry.getKey());
                    arrayList.add(zzaP);
                    arrayList2.add(entry.getValue());
                    int i3 = (zzaP.zzadS() || zzaP.zzadT()) ? 1 : 0;
                    i2 = i3 | i2;
                }
                if (i2 != 0) {
                    com_google_android_gms_internal_zzbwz.zzaet();
                    while (i < arrayList.size()) {
                        com_google_android_gms_internal_zzbwz.zzaet();
                        zzbwh.zzb((zzbvg) arrayList.get(i), com_google_android_gms_internal_zzbwz);
                        this.zzcsN.zza(com_google_android_gms_internal_zzbwz, arrayList2.get(i));
                        com_google_android_gms_internal_zzbwz.zzaeu();
                        i++;
                    }
                    com_google_android_gms_internal_zzbwz.zzaeu();
                    return;
                }
                com_google_android_gms_internal_zzbwz.zzaev();
                while (i < arrayList.size()) {
                    com_google_android_gms_internal_zzbwz.zzko(zze((zzbvg) arrayList.get(i)));
                    this.zzcsN.zza(com_google_android_gms_internal_zzbwz, arrayList2.get(i));
                    i++;
                }
                com_google_android_gms_internal_zzbwz.zzaew();
            } else {
                com_google_android_gms_internal_zzbwz.zzaev();
                for (Entry entry2 : map.entrySet()) {
                    com_google_android_gms_internal_zzbwz.zzko(String.valueOf(entry2.getKey()));
                    this.zzcsN.zza(com_google_android_gms_internal_zzbwz, entry2.getValue());
                }
                com_google_android_gms_internal_zzbwz.zzaew();
            }
        }

        public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            return zzl(com_google_android_gms_internal_zzbwx);
        }

        public Map<K, V> zzl(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            zzbwy zzaen = com_google_android_gms_internal_zzbwx.zzaen();
            if (zzaen == zzbwy.NULL) {
                com_google_android_gms_internal_zzbwx.nextNull();
                return null;
            }
            Map<K, V> map = (Map) this.zzcsD.zzaeg();
            Object zzb;
            if (zzaen == zzbwy.BEGIN_ARRAY) {
                com_google_android_gms_internal_zzbwx.beginArray();
                while (com_google_android_gms_internal_zzbwx.hasNext()) {
                    com_google_android_gms_internal_zzbwx.beginArray();
                    zzb = this.zzcsM.zzb(com_google_android_gms_internal_zzbwx);
                    if (map.put(zzb, this.zzcsN.zzb(com_google_android_gms_internal_zzbwx)) != null) {
                        String valueOf = String.valueOf(zzb);
                        throw new zzbvp(new StringBuilder(String.valueOf(valueOf).length() + 15).append("duplicate key: ").append(valueOf).toString());
                    }
                    com_google_android_gms_internal_zzbwx.endArray();
                }
                com_google_android_gms_internal_zzbwx.endArray();
                return map;
            }
            com_google_android_gms_internal_zzbwx.beginObject();
            while (com_google_android_gms_internal_zzbwx.hasNext()) {
                zzbwc.zzcsa.zzi(com_google_android_gms_internal_zzbwx);
                zzb = this.zzcsM.zzb(com_google_android_gms_internal_zzbwx);
                if (map.put(zzb, this.zzcsN.zzb(com_google_android_gms_internal_zzbwx)) != null) {
                    valueOf = String.valueOf(zzb);
                    throw new zzbvp(new StringBuilder(String.valueOf(valueOf).length() + 15).append("duplicate key: ").append(valueOf).toString());
                }
            }
            com_google_android_gms_internal_zzbwx.endObject();
            return map;
        }
    }

    public zzbwp(zzbwa com_google_android_gms_internal_zzbwa, boolean z) {
        this.zzcqW = com_google_android_gms_internal_zzbwa;
        this.zzcsL = z;
    }

    private zzbvs<?> zza(zzbva com_google_android_gms_internal_zzbva, Type type) {
        return (type == Boolean.TYPE || type == Boolean.class) ? zzbwv.zzcth : com_google_android_gms_internal_zzbva.zza(zzbww.zzl(type));
    }

    public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
        Type zzaez = com_google_android_gms_internal_zzbww_T.zzaez();
        if (!Map.class.isAssignableFrom(com_google_android_gms_internal_zzbww_T.zzaey())) {
            return null;
        }
        Type[] zzb = zzbvz.zzb(zzaez, zzbvz.zzf(zzaez));
        zzbvs zza = zza(com_google_android_gms_internal_zzbva, zzb[0]);
        zzbvs zza2 = com_google_android_gms_internal_zzbva.zza(zzbww.zzl(zzb[1]));
        zzbwf zzb2 = this.zzcqW.zzb(com_google_android_gms_internal_zzbww_T);
        return new zza(this, com_google_android_gms_internal_zzbva, zzb[0], zza, zzb[1], zza2, zzb2);
    }
}
