package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzac;
import java.io.IOException;
import java.util.List;

public class zzblw extends zzbvs<zzbml> {
    private zzbva zzbYh;

    public zzbml zza(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
        zzbml com_google_android_gms_internal_zzbml = new zzbml();
        zzbvs zzj = this.zzbYh.zzj(zzbmj.class);
        com_google_android_gms_internal_zzbwx.beginArray();
        while (com_google_android_gms_internal_zzbwx.hasNext()) {
            com_google_android_gms_internal_zzbml.zzWd().add((zzbmj) zzj.zzb(com_google_android_gms_internal_zzbwx));
        }
        com_google_android_gms_internal_zzbwx.endArray();
        return com_google_android_gms_internal_zzbml;
    }

    public void zza(@NonNull zzbva com_google_android_gms_internal_zzbva) {
        this.zzbYh = (zzbva) zzac.zzw(com_google_android_gms_internal_zzbva);
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, zzbml com_google_android_gms_internal_zzbml) throws IOException {
        int i = 0;
        if (com_google_android_gms_internal_zzbml == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
            return;
        }
        zzbvs zzj = this.zzbYh.zzj(zzbmj.class);
        com_google_android_gms_internal_zzbwz.zzaet();
        List zzWd = com_google_android_gms_internal_zzbml.zzWd();
        int size = zzWd != null ? zzWd.size() : 0;
        while (i < size) {
            zzj.zza(com_google_android_gms_internal_zzbwz, (zzbmj) zzWd.get(i));
            i++;
        }
        com_google_android_gms_internal_zzbwz.zzaeu();
    }

    public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return zza(com_google_android_gms_internal_zzbwx);
    }
}
