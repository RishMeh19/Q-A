package com.google.android.gms.internal;

import android.util.Log;
import java.io.IOException;
import java.io.InputStream;

public class zzbuk {
    private static final Runtime zzcqv = Runtime.getRuntime();
    private byte[] buffer;
    private final InputStream zzcqw;
    private int zzcqx = 0;
    private boolean zzcqy = false;
    private boolean zzcqz = true;

    public zzbuk(InputStream inputStream, int i) {
        this.zzcqw = inputStream;
        this.buffer = new byte[i];
    }

    private int zzqV(int i) {
        int max = Math.max(this.buffer.length * 2, i);
        if (!this.zzcqz || ((long) (262144 + max)) >= zzcqv.freeMemory()) {
            Log.w("AdaptiveStreamBuffer", "Turning off adaptive buffer resizing to conserve memory.");
        } else {
            try {
                Object obj = new byte[max];
                System.arraycopy(this.buffer, 0, obj, 0, this.zzcqx);
                this.buffer = obj;
            } catch (OutOfMemoryError e) {
                Log.w("AdaptiveStreamBuffer", "Turning off adaptive buffer resizing due to low memory.");
                this.zzcqz = false;
            }
        }
        return this.buffer.length;
    }

    public int available() {
        return this.zzcqx;
    }

    public void close() throws IOException {
        this.zzcqw.close();
    }

    public boolean isFinished() {
        return this.zzcqy;
    }

    public byte[] zzadD() {
        return this.buffer;
    }

    public int zzqT(int i) throws IOException {
        if (i <= this.zzcqx) {
            this.zzcqx -= i;
            System.arraycopy(this.buffer, i, this.buffer, 0, this.zzcqx);
            return i;
        }
        this.zzcqx = 0;
        int i2 = this.zzcqx;
        while (i2 < i) {
            long skip = this.zzcqw.skip((long) (i - i2));
            if (skip > 0) {
                i2 = (int) (((long) i2) + skip);
            } else if (skip != 0) {
                continue;
            } else if (this.zzcqw.read() == -1) {
                return i2;
            } else {
                i2++;
            }
        }
        return i2;
    }

    public int zzqU(int i) throws IOException {
        if (i > this.buffer.length) {
            i = Math.min(i, zzqV(i));
        }
        while (this.zzcqx < i) {
            int read = this.zzcqw.read(this.buffer, this.zzcqx, i - this.zzcqx);
            if (read == -1) {
                this.zzcqy = true;
                break;
            }
            this.zzcqx = read + this.zzcqx;
        }
        return this.zzcqx;
    }
}
