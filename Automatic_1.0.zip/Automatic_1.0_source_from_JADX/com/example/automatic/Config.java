package com.example.automatic;

public class Config {
    public static final String FIREBASE_URL = "https://automatic-168513.firebaseio.com/";
}
