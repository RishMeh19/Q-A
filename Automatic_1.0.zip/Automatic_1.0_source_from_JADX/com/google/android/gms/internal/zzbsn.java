package com.google.android.gms.internal;

public interface zzbsn {
    void onClose();

    void zzYf();

    void zza(zzbso com_google_android_gms_internal_zzbso);

    void zza(zzbsq com_google_android_gms_internal_zzbsq);
}
