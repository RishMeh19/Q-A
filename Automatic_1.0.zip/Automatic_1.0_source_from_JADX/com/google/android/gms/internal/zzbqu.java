package com.google.android.gms.internal;

public class zzbqu {
    private final zzbrx zzchI;
    private final boolean zzchJ;
    private final boolean zzchK;

    public zzbqu(zzbrx com_google_android_gms_internal_zzbrx, boolean z, boolean z2) {
        this.zzchI = com_google_android_gms_internal_zzbrx;
        this.zzchJ = z;
        this.zzchK = z2;
    }

    public boolean zzM(zzbph com_google_android_gms_internal_zzbph) {
        return com_google_android_gms_internal_zzbph.isEmpty() ? zzZS() && !this.zzchK : zzf(com_google_android_gms_internal_zzbph.zzYU());
    }

    public zzbsc zzWK() {
        return this.zzchI.zzWK();
    }

    public boolean zzZS() {
        return this.zzchJ;
    }

    public boolean zzZT() {
        return this.zzchK;
    }

    public zzbrx zzZU() {
        return this.zzchI;
    }

    public boolean zzf(zzbrq com_google_android_gms_internal_zzbrq) {
        return (zzZS() && !this.zzchK) || this.zzchI.zzWK().zzk(com_google_android_gms_internal_zzbrq);
    }
}
