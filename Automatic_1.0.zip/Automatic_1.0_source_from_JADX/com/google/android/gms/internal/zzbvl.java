package com.google.android.gms.internal;

import java.io.Reader;
import java.io.StringReader;

public final class zzbvl {
    public zzbvg zza(Reader reader) throws zzbvh, zzbvp {
        try {
            zzbwx com_google_android_gms_internal_zzbwx = new zzbwx(reader);
            zzbvg zzh = zzh(com_google_android_gms_internal_zzbwx);
            if (zzh.zzadV() || com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.END_DOCUMENT) {
                return zzh;
            }
            throw new zzbvp("Did not consume the entire document.");
        } catch (Throwable e) {
            throw new zzbvp(e);
        } catch (Throwable e2) {
            throw new zzbvh(e2);
        } catch (Throwable e22) {
            throw new zzbvp(e22);
        }
    }

    public zzbvg zzh(zzbwx com_google_android_gms_internal_zzbwx) throws zzbvh, zzbvp {
        String valueOf;
        boolean isLenient = com_google_android_gms_internal_zzbwx.isLenient();
        com_google_android_gms_internal_zzbwx.setLenient(true);
        try {
            zzbvg zzh = zzbwh.zzh(com_google_android_gms_internal_zzbwx);
            com_google_android_gms_internal_zzbwx.setLenient(isLenient);
            return zzh;
        } catch (Throwable e) {
            valueOf = String.valueOf(com_google_android_gms_internal_zzbwx);
            throw new zzbvk(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed parsing JSON source: ").append(valueOf).append(" to Json").toString(), e);
        } catch (Throwable e2) {
            valueOf = String.valueOf(com_google_android_gms_internal_zzbwx);
            throw new zzbvk(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed parsing JSON source: ").append(valueOf).append(" to Json").toString(), e2);
        } catch (Throwable th) {
            com_google_android_gms_internal_zzbwx.setLenient(isLenient);
        }
    }

    public zzbvg zzkm(String str) throws zzbvp {
        return zza(new StringReader(str));
    }
}
