package com.google.android.gms.internal;

public class zzboz {
    public static final zzbrq zzcdO = zzbrq.zzja(".info");
    public static final zzbrq zzcdP = zzbrq.zzja("serverTimeOffset");
    public static final zzbrq zzcdQ = zzbrq.zzja("authenticated");
    public static final zzbrq zzcdR = zzbrq.zzja("connected");
}
