package com.google.android.gms.internal;

import java.io.IOException;

public interface zzbyn {

    public static final class zza extends zzbyd<zza> {
        public int score;
        public boolean zzcwX;
        public String zzcwY;

        public zza() {
            zzafC();
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzbyn_zza = (zza) obj;
            if (this.zzcwX != com_google_android_gms_internal_zzbyn_zza.zzcwX || this.score != com_google_android_gms_internal_zzbyn_zza.score) {
                return false;
            }
            if (this.zzcwY == null) {
                if (com_google_android_gms_internal_zzbyn_zza.zzcwY != null) {
                    return false;
                }
            } else if (!this.zzcwY.equals(com_google_android_gms_internal_zzbyn_zza.zzcwY)) {
                return false;
            }
            return (this.zzcwC == null || this.zzcwC.isEmpty()) ? com_google_android_gms_internal_zzbyn_zza.zzcwC == null || com_google_android_gms_internal_zzbyn_zza.zzcwC.isEmpty() : this.zzcwC.equals(com_google_android_gms_internal_zzbyn_zza.zzcwC);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.zzcwY == null ? 0 : this.zzcwY.hashCode()) + (((((this.zzcwX ? 1231 : 1237) + ((getClass().getName().hashCode() + 527) * 31)) * 31) + this.score) * 31)) * 31;
            if (!(this.zzcwC == null || this.zzcwC.isEmpty())) {
                i = this.zzcwC.hashCode();
            }
            return hashCode + i;
        }

        public void zza(zzbyc com_google_android_gms_internal_zzbyc) throws IOException {
            if (this.zzcwX) {
                com_google_android_gms_internal_zzbyc.zzg(1, this.zzcwX);
            }
            if (this.score != 0) {
                com_google_android_gms_internal_zzbyc.zzJ(2, this.score);
            }
            if (!(this.zzcwY == null || this.zzcwY.equals(""))) {
                com_google_android_gms_internal_zzbyc.zzq(3, this.zzcwY);
            }
            super.zza(com_google_android_gms_internal_zzbyc);
        }

        public zza zzaV(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            while (true) {
                int zzaeW = com_google_android_gms_internal_zzbyb.zzaeW();
                switch (zzaeW) {
                    case 0:
                        break;
                    case 8:
                        this.zzcwX = com_google_android_gms_internal_zzbyb.zzafc();
                        continue;
                    case 16:
                        this.score = com_google_android_gms_internal_zzbyb.zzafa();
                        continue;
                    case 26:
                        this.zzcwY = com_google_android_gms_internal_zzbyb.readString();
                        continue;
                    default:
                        if (!super.zza(com_google_android_gms_internal_zzbyb, zzaeW)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public zza zzafC() {
            this.zzcwX = false;
            this.score = 0;
            this.zzcwY = "";
            this.zzcwC = null;
            this.zzcwL = -1;
            return this;
        }

        public /* synthetic */ zzbyj zzb(zzbyb com_google_android_gms_internal_zzbyb) throws IOException {
            return zzaV(com_google_android_gms_internal_zzbyb);
        }

        protected int zzu() {
            int zzu = super.zzu();
            if (this.zzcwX) {
                zzu += zzbyc.zzh(1, this.zzcwX);
            }
            if (this.score != 0) {
                zzu += zzbyc.zzL(2, this.score);
            }
            return (this.zzcwY == null || this.zzcwY.equals("")) ? zzu : zzu + zzbyc.zzr(3, this.zzcwY);
        }
    }
}
