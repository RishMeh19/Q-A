package com.google.android.gms.internal;

import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.search.GoogleNowAuthState;
import com.google.android.gms.search.SearchAuth;
import com.google.android.gms.search.SearchAuthApi;
import com.google.android.gms.search.SearchAuthApi.GoogleNowAuthResult;

public class zzbag implements SearchAuthApi {

    static abstract class zza extends com.google.android.gms.internal.zzbad.zza {
        zza() {
        }

        public void zza(Status status, GoogleNowAuthState googleNowAuthState) {
            throw new UnsupportedOperationException();
        }

        public void zzbJ(Status status) {
            throw new UnsupportedOperationException();
        }
    }

    static class zzd implements GoogleNowAuthResult {
        private final Status zzair;
        private final GoogleNowAuthState zzbEe;

        zzd(Status status, GoogleNowAuthState googleNowAuthState) {
            this.zzair = status;
            this.zzbEe = googleNowAuthState;
        }

        public GoogleNowAuthState getGoogleNowAuthState() {
            return this.zzbEe;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    static class zzb extends com.google.android.gms.internal.zzaad.zza<Status, zzbaf> {
        private final String zzbDW;
        private final String zzbDZ;
        private final boolean zzbEa = Log.isLoggable("SearchAuth", 3);

        class C06601 extends zza {
            final /* synthetic */ zzb zzbEb;

            C06601(zzb com_google_android_gms_internal_zzbag_zzb) {
                this.zzbEb = com_google_android_gms_internal_zzbag_zzb;
            }

            public void zzbJ(Status status) {
                if (this.zzbEb.zzbEa) {
                    Log.d("SearchAuth", "ClearTokenImpl success");
                }
                this.zzbEb.zzb(status);
            }
        }

        protected zzb(GoogleApiClient googleApiClient, String str) {
            super(SearchAuth.API, googleApiClient);
            this.zzbDW = str;
            this.zzbDZ = googleApiClient.getContext().getPackageName();
        }

        public /* synthetic */ void setResult(Object obj) {
            super.zzb((Status) obj);
        }

        protected void zza(zzbaf com_google_android_gms_internal_zzbaf) throws RemoteException {
            if (this.zzbEa) {
                Log.d("SearchAuth", "ClearTokenImpl started");
            }
            ((zzbae) com_google_android_gms_internal_zzbaf.zzxD()).zzb(new C06601(this), this.zzbDZ, this.zzbDW);
        }

        protected Status zzb(Status status) {
            if (this.zzbEa) {
                String str = "SearchAuth";
                String str2 = "ClearTokenImpl received failure: ";
                String valueOf = String.valueOf(status.getStatusMessage());
                Log.d(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            }
            return status;
        }

        protected /* synthetic */ Result zzc(Status status) {
            return zzb(status);
        }
    }

    static class zzc extends com.google.android.gms.internal.zzaad.zza<GoogleNowAuthResult, zzbaf> {
        private final String zzbDZ;
        private final boolean zzbEa = Log.isLoggable("SearchAuth", 3);
        private final String zzbEc;

        class C06611 extends zza {
            final /* synthetic */ zzc zzbEd;

            C06611(zzc com_google_android_gms_internal_zzbag_zzc) {
                this.zzbEd = com_google_android_gms_internal_zzbag_zzc;
            }

            public void zza(Status status, GoogleNowAuthState googleNowAuthState) {
                if (this.zzbEd.zzbEa) {
                    Log.d("SearchAuth", "GetGoogleNowAuthImpl success");
                }
                this.zzbEd.zzb(new zzd(status, googleNowAuthState));
            }
        }

        protected zzc(GoogleApiClient googleApiClient, String str) {
            super(SearchAuth.API, googleApiClient);
            this.zzbEc = str;
            this.zzbDZ = googleApiClient.getContext().getPackageName();
        }

        public /* synthetic */ void setResult(Object obj) {
            super.zzb((GoogleNowAuthResult) obj);
        }

        protected void zza(zzbaf com_google_android_gms_internal_zzbaf) throws RemoteException {
            if (this.zzbEa) {
                Log.d("SearchAuth", "GetGoogleNowAuthImpl started");
            }
            ((zzbae) com_google_android_gms_internal_zzbaf.zzxD()).zza(new C06611(this), this.zzbDZ, this.zzbEc);
        }

        protected GoogleNowAuthResult zzbK(Status status) {
            if (this.zzbEa) {
                String str = "SearchAuth";
                String str2 = "GetGoogleNowAuthImpl received failure: ";
                String valueOf = String.valueOf(status.getStatusMessage());
                Log.d(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            }
            return new zzd(status, null);
        }

        protected /* synthetic */ Result zzc(Status status) {
            return zzbK(status);
        }
    }

    public PendingResult<Status> clearToken(GoogleApiClient googleApiClient, String str) {
        return googleApiClient.zza(new zzb(googleApiClient, str));
    }

    public PendingResult<GoogleNowAuthResult> getGoogleNowAuth(GoogleApiClient googleApiClient, String str) {
        return googleApiClient.zza(new zzc(googleApiClient, str));
    }
}
