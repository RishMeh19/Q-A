package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzbvs<T> {
    public abstract void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException;

    public final zzbvg zzaP(T t) {
        try {
            zzbwz com_google_android_gms_internal_zzbwo = new zzbwo();
            zza(com_google_android_gms_internal_zzbwo, t);
            return com_google_android_gms_internal_zzbwo.zzaer();
        } catch (Throwable e) {
            throw new zzbvh(e);
        }
    }

    public abstract T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException;
}
