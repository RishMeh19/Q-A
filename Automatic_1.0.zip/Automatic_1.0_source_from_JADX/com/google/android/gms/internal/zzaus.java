package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzac;

class zzaus {
    final String mAppId;
    final String mName;
    final String mOrigin;
    final Object mValue;
    final long zzbwj;

    zzaus(String str, String str2, String str3, long j, Object obj) {
        zzac.zzdr(str);
        zzac.zzdr(str3);
        zzac.zzw(obj);
        this.mAppId = str;
        this.mOrigin = str2;
        this.mName = str3;
        this.zzbwj = j;
        this.mValue = obj;
    }
}
