package com.google.android.gms.internal;

import java.util.Collections;
import java.util.List;

public class zzboi {
    private final List<List<String>> zzcbr;
    private final List<String> zzcbs;

    public zzboi(List<List<String>> list, List<String> list2) {
        if (list.size() != list2.size() - 1) {
            throw new IllegalArgumentException("Number of posts need to be n-1 for n hashes in CompoundHash");
        }
        this.zzcbr = list;
        this.zzcbs = list2;
    }

    public List<List<String>> zzXr() {
        return Collections.unmodifiableList(this.zzcbr);
    }

    public List<String> zzXs() {
        return Collections.unmodifiableList(this.zzcbs);
    }
}
