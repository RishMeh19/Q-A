package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;

public class zzbov extends Reader {
    private boolean closed;
    private List<String> zzcdA;
    private int zzcdB;
    private int zzcdC;
    private int zzcdD;
    private int zzcdE;
    private boolean zzcdF;

    public zzbov() {
        this.zzcdA = null;
        this.closed = false;
        this.zzcdD = this.zzcdB;
        this.zzcdE = this.zzcdC;
        this.zzcdF = false;
        this.zzcdA = new ArrayList();
    }

    private String zzYm() {
        return this.zzcdC < this.zzcdA.size() ? (String) this.zzcdA.get(this.zzcdC) : null;
    }

    private int zzYn() {
        String zzYm = zzYm();
        return zzYm == null ? 0 : zzYm.length() - this.zzcdB;
    }

    private void zzYo() throws IOException {
        if (this.closed) {
            throw new IOException("Stream already closed");
        } else if (!this.zzcdF) {
            throw new IOException("Reader needs to be frozen before read operations can be called");
        }
    }

    private long zzaO(long j) {
        long j2 = 0;
        while (this.zzcdC < this.zzcdA.size() && j2 < j) {
            int zzYn = zzYn();
            long j3 = j - j2;
            if (j3 < ((long) zzYn)) {
                this.zzcdB = (int) (((long) this.zzcdB) + j3);
                j2 += j3;
            } else {
                j2 += (long) zzYn;
                this.zzcdB = 0;
                this.zzcdC++;
            }
        }
        return j2;
    }

    public void close() throws IOException {
        zzYo();
        this.closed = true;
    }

    public void mark(int i) throws IOException {
        zzYo();
        this.zzcdD = this.zzcdB;
        this.zzcdE = this.zzcdC;
    }

    public boolean markSupported() {
        return true;
    }

    public int read() throws IOException {
        zzYo();
        String zzYm = zzYm();
        if (zzYm == null) {
            return -1;
        }
        char charAt = zzYm.charAt(this.zzcdB);
        zzaO(1);
        return charAt;
    }

    public int read(CharBuffer charBuffer) throws IOException {
        zzYo();
        int remaining = charBuffer.remaining();
        int i = 0;
        String zzYm = zzYm();
        while (remaining > 0 && zzYm != null) {
            int min = Math.min(zzYm.length() - this.zzcdB, remaining);
            charBuffer.put((String) this.zzcdA.get(this.zzcdC), this.zzcdB, this.zzcdB + min);
            remaining -= min;
            i += min;
            zzaO((long) min);
            zzYm = zzYm();
        }
        return (i > 0 || zzYm != null) ? i : -1;
    }

    public int read(char[] cArr, int i, int i2) throws IOException {
        zzYo();
        int i3 = 0;
        String zzYm = zzYm();
        while (zzYm != null && i3 < i2) {
            int min = Math.min(zzYn(), i2 - i3);
            zzYm.getChars(this.zzcdB, this.zzcdB + min, cArr, i + i3);
            int i4 = i3 + min;
            zzaO((long) min);
            i3 = i4;
            zzYm = zzYm();
        }
        return (i3 > 0 || zzYm != null) ? i3 : -1;
    }

    public boolean ready() throws IOException {
        zzYo();
        return true;
    }

    public void reset() throws IOException {
        this.zzcdB = this.zzcdD;
        this.zzcdC = this.zzcdE;
    }

    public long skip(long j) throws IOException {
        zzYo();
        return zzaO(j);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String append : this.zzcdA) {
            stringBuilder.append(append);
        }
        return stringBuilder.toString();
    }

    public void zzYl() {
        if (this.zzcdF) {
            throw new IllegalStateException("Trying to freeze frozen StringListReader");
        }
        this.zzcdF = true;
    }

    public void zziT(String str) {
        if (this.zzcdF) {
            throw new IllegalStateException("Trying to add string after reading");
        } else if (str.length() > 0) {
            this.zzcdA.add(str);
        }
    }
}
