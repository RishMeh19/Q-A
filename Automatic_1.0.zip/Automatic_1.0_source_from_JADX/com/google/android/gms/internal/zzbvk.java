package com.google.android.gms.internal;

public class zzbvk extends RuntimeException {
    public zzbvk(String str) {
        super(str);
    }

    public zzbvk(String str, Throwable th) {
        super(str, th);
    }

    public zzbvk(Throwable th) {
        super(th);
    }
}
