package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import android.util.Log;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzi;
import com.google.firebase.FirebaseApp;
import com.google.firebase.appindexing.Indexable;
import java.util.Random;

public class zzbul {
    static zze zzajZ = zzi.zzzc();
    private static Random zzbSZ = new Random();
    static zzbun zzcqA = new zzbuo();
    private volatile boolean zzK;
    private FirebaseApp zzclm;
    private long zzcqB;

    public zzbul(FirebaseApp firebaseApp, long j) {
        this.zzclm = firebaseApp;
        this.zzcqB = j;
    }

    public void cancel() {
        this.zzK = true;
    }

    public void reset() {
        this.zzK = false;
    }

    public void zza(@NonNull zzbuu com_google_android_gms_internal_zzbuu, boolean z) {
        zzac.zzw(com_google_android_gms_internal_zzbuu);
        long elapsedRealtime = zzajZ.elapsedRealtime() + this.zzcqB;
        if (z) {
            com_google_android_gms_internal_zzbuu.zzd(zzbuq.zzi(this.zzclm), this.zzclm.getApplicationContext());
        } else {
            com_google_android_gms_internal_zzbuu.zzkg(zzbuq.zzi(this.zzclm));
        }
        int i = 1000;
        while (zzajZ.elapsedRealtime() + ((long) i) <= elapsedRealtime && !com_google_android_gms_internal_zzbuu.zzadK() && zzqW(com_google_android_gms_internal_zzbuu.getResultCode())) {
            try {
                zzcqA.zzqX(zzbSZ.nextInt(250) + i);
                if (i < Indexable.MAX_BYTE_SIZE) {
                    if (com_google_android_gms_internal_zzbuu.getResultCode() != -2) {
                        i *= 2;
                        Log.w("ExponenentialBackoff", "network error occurred, backing off/sleeping.");
                    } else {
                        Log.w("ExponenentialBackoff", "network unavailable, sleeping.");
                        i = 1000;
                    }
                }
                if (!this.zzK) {
                    com_google_android_gms_internal_zzbuu.reset();
                    if (z) {
                        com_google_android_gms_internal_zzbuu.zzd(zzbuq.zzi(this.zzclm), this.zzclm.getApplicationContext());
                    } else {
                        com_google_android_gms_internal_zzbuu.zzkg(zzbuq.zzi(this.zzclm));
                    }
                } else {
                    return;
                }
            } catch (InterruptedException e) {
                Log.w("ExponenentialBackoff", "thread interrupted during exponential backoff.");
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public void zze(@NonNull zzbuu com_google_android_gms_internal_zzbuu) {
        zza(com_google_android_gms_internal_zzbuu, true);
    }

    public boolean zzqW(int i) {
        return (i >= 500 && i < 600) || i == -2 || i == 429 || i == 408;
    }
}
