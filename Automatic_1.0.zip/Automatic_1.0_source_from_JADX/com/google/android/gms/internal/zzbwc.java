package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzbwc {
    public static zzbwc zzcsa;

    public abstract void zzi(zzbwx com_google_android_gms_internal_zzbwx) throws IOException;
}
