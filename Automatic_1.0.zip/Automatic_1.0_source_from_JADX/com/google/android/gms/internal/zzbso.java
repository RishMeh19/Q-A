package com.google.android.gms.internal;

public class zzbso extends RuntimeException {
    public zzbso(String str) {
        super(str);
    }

    public zzbso(String str, Throwable th) {
        super(str, th);
    }
}
