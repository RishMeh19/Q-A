package com.google.android.gms.internal;

public interface zzbpm {
    void restart();

    void shutdown();

    void zzs(Runnable runnable);
}
