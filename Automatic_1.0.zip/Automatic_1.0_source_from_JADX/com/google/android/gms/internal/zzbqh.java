package com.google.android.gms.internal;

public interface zzbqh {
    public static final zzbqh zzcha = new C05271();

    class C05271 implements zzbqh {
        C05271() {
        }

        public float zzZH() {
            return 0.0f;
        }

        public long zzZI() {
            return Long.MAX_VALUE;
        }

        public boolean zzaR(long j) {
            return false;
        }

        public boolean zzk(long j, long j2) {
            return false;
        }
    }

    float zzZH();

    long zzZI();

    boolean zzaR(long j);

    boolean zzk(long j, long j2);
}
