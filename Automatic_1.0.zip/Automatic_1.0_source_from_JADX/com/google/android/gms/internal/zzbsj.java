package com.google.android.gms.internal;

public class zzbsj extends zzbrw {
    private static final zzbsj zzcjK = new zzbsj();

    private zzbsj() {
    }

    public static zzbsj zzabo() {
        return zzcjK;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return zza((zzbsb) obj, (zzbsb) obj2);
    }

    public boolean equals(Object obj) {
        return obj instanceof zzbsj;
    }

    public int hashCode() {
        return 4;
    }

    public String toString() {
        return "ValueIndex";
    }

    public int zza(zzbsb com_google_android_gms_internal_zzbsb, zzbsb com_google_android_gms_internal_zzbsb2) {
        int compareTo = com_google_android_gms_internal_zzbsb.zzWK().compareTo(com_google_android_gms_internal_zzbsb2.zzWK());
        return compareTo == 0 ? com_google_android_gms_internal_zzbsb.zzabl().zzi(com_google_android_gms_internal_zzbsb2.zzabl()) : compareTo;
    }

    public zzbsb zzabd() {
        return new zzbsb(zzbrq.zzaaJ(), zzbsc.zzcjB);
    }

    public String zzabe() {
        return ".value";
    }

    public zzbsb zzg(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
        return new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc);
    }

    public boolean zzm(zzbsc com_google_android_gms_internal_zzbsc) {
        return true;
    }
}
