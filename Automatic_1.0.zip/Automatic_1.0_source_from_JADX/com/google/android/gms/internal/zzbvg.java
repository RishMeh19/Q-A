package com.google.android.gms.internal;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public abstract class zzbvg {
    public boolean getAsBoolean() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public double getAsDouble() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public int getAsInt() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public long getAsLong() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public String toString() {
        try {
            Writer stringWriter = new StringWriter();
            zzbwz com_google_android_gms_internal_zzbwz = new zzbwz(stringWriter);
            com_google_android_gms_internal_zzbwz.setLenient(true);
            zzbwh.zzb(this, com_google_android_gms_internal_zzbwz);
            return stringWriter.toString();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    public Number zzadQ() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public String zzadR() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public boolean zzadS() {
        return this instanceof zzbvd;
    }

    public boolean zzadT() {
        return this instanceof zzbvj;
    }

    public boolean zzadU() {
        return this instanceof zzbvm;
    }

    public boolean zzadV() {
        return this instanceof zzbvi;
    }

    public zzbvj zzadW() {
        if (zzadT()) {
            return (zzbvj) this;
        }
        String valueOf = String.valueOf(this);
        throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 19).append("Not a JSON Object: ").append(valueOf).toString());
    }

    public zzbvd zzadX() {
        if (zzadS()) {
            return (zzbvd) this;
        }
        throw new IllegalStateException("This is not a JSON Array.");
    }

    public zzbvm zzadY() {
        if (zzadU()) {
            return (zzbvm) this;
        }
        throw new IllegalStateException("This is not a JSON Primitive.");
    }

    Boolean zzadZ() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }
}
