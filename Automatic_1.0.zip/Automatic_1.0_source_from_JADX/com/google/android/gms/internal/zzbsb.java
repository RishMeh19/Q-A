package com.google.android.gms.internal;

public class zzbsb {
    private static final zzbsb zzcjA = new zzbsb(zzbrq.zzaaJ(), zzbsc.zzcjB);
    private static final zzbsb zzcjz = new zzbsb(zzbrq.zzaaI(), zzbrv.zzabb());
    private final zzbrq zzchD;
    private final zzbsc zzcjq;

    public zzbsb(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
        this.zzchD = com_google_android_gms_internal_zzbrq;
        this.zzcjq = com_google_android_gms_internal_zzbsc;
    }

    public static zzbsb zzabj() {
        return zzcjz;
    }

    public static zzbsb zzabk() {
        return zzcjA;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbsb com_google_android_gms_internal_zzbsb = (zzbsb) obj;
        return !this.zzchD.equals(com_google_android_gms_internal_zzbsb.zzchD) ? false : this.zzcjq.equals(com_google_android_gms_internal_zzbsb.zzcjq);
    }

    public int hashCode() {
        return (this.zzchD.hashCode() * 31) + this.zzcjq.hashCode();
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzchD);
        String valueOf2 = String.valueOf(this.zzcjq);
        return new StringBuilder((String.valueOf(valueOf).length() + 23) + String.valueOf(valueOf2).length()).append("NamedNode{name=").append(valueOf).append(", node=").append(valueOf2).append("}").toString();
    }

    public zzbsc zzWK() {
        return this.zzcjq;
    }

    public zzbrq zzabl() {
        return this.zzchD;
    }
}
