package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseUser;
import java.util.ArrayList;
import java.util.List;

public class zzbnj {
    private Context mContext;
    private SharedPreferences zzBd;
    private zzbva zzbYh;
    private String zzbZe;
    private zzbvl zzbZf = new zzbvl();

    public zzbnj(@NonNull Context context, @NonNull String str, @NonNull zzbva com_google_android_gms_internal_zzbva) {
        zzac.zzw(context);
        this.zzbZe = zzac.zzdr(str);
        this.mContext = context.getApplicationContext();
        String format = String.format("com.google.firebase.auth.api.Store.%s", new Object[]{this.zzbZe});
        this.zzbYh = (zzbva) zzac.zzw(com_google_android_gms_internal_zzbva);
        this.zzBd = this.mContext.getSharedPreferences(format, 0);
    }

    private zzbnf zza(@NonNull zzbvj com_google_android_gms_internal_zzbvj) {
        Object zzadR = com_google_android_gms_internal_zzbvj.zzkk("cachedTokenState").zzadR();
        String zzadR2 = com_google_android_gms_internal_zzbvj.zzkk("applicationName").zzadR();
        boolean asBoolean = com_google_android_gms_internal_zzbvj.zzkk("anonymous").getAsBoolean();
        String str = "2";
        zzbvg zzkk = com_google_android_gms_internal_zzbvj.zzkk("version");
        String zzadR3 = (zzkk == null || zzkk.zzadV()) ? str : zzkk.zzadR();
        zzbvd zzkl = com_google_android_gms_internal_zzbvj.zzkl("userInfos");
        int size = zzkl.size();
        List arrayList = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            arrayList.add((zzbnd) this.zzbYh.zza(zzkl.zzqY(i), zzbnd.class));
        }
        zzbnf com_google_android_gms_internal_zzbnf = new zzbnf(FirebaseApp.getInstance(zzadR2), arrayList);
        if (!TextUtils.isEmpty(zzadR)) {
            com_google_android_gms_internal_zzbnf.zza((zzbmn) this.zzbYh.zzf(zzadR, zzbmn.class));
        }
        ((zzbnf) com_google_android_gms_internal_zzbnf.zzaX(asBoolean)).zziz(zzadR3);
        return com_google_android_gms_internal_zzbnf;
    }

    @Nullable
    private String zzi(@NonNull FirebaseUser firebaseUser) {
        zzbvj com_google_android_gms_internal_zzbvj = new zzbvj();
        if (!zzbnf.class.isAssignableFrom(firebaseUser.getClass())) {
            return null;
        }
        zzbnf com_google_android_gms_internal_zzbnf = (zzbnf) firebaseUser;
        com_google_android_gms_internal_zzbvj.zzaG("cachedTokenState", com_google_android_gms_internal_zzbnf.zzVJ());
        com_google_android_gms_internal_zzbvj.zzaG("applicationName", com_google_android_gms_internal_zzbnf.zzVH().getName());
        com_google_android_gms_internal_zzbvj.zzaG("type", "com.google.firebase.auth.internal.DefaultFirebaseUser");
        if (com_google_android_gms_internal_zzbnf.zzWs() != null) {
            zzbvg com_google_android_gms_internal_zzbvd = new zzbvd();
            List zzWs = com_google_android_gms_internal_zzbnf.zzWs();
            for (int i = 0; i < zzWs.size(); i++) {
                com_google_android_gms_internal_zzbvd.zzc(zziA(this.zzbYh.zzaM((zzbnd) zzWs.get(i))));
            }
            com_google_android_gms_internal_zzbvj.zza("userInfos", com_google_android_gms_internal_zzbvd);
        }
        com_google_android_gms_internal_zzbvj.zza("anonymous", Boolean.valueOf(com_google_android_gms_internal_zzbnf.isAnonymous()));
        com_google_android_gms_internal_zzbvj.zzaG("version", "2");
        return com_google_android_gms_internal_zzbvj.toString();
    }

    private static zzbvg zziA(String str) {
        return new zzbvl().zzkm(str);
    }

    public void clear(String str) {
        this.zzBd.edit().remove(str).apply();
    }

    @Nullable
    public String get(String str) {
        return this.zzBd.getString(str, null);
    }

    @Nullable
    public FirebaseUser zzWu() {
        FirebaseUser firebaseUser = null;
        Object obj = get("com.google.firebase.auth.FIREBASE_USER");
        if (!TextUtils.isEmpty(obj)) {
            try {
                zzbvj zzadW = this.zzbZf.zzkm(obj).zzadW();
                if (zzadW.has("type")) {
                    if ("com.google.firebase.auth.internal.DefaultFirebaseUser".equalsIgnoreCase(zzadW.zzkk("type").zzadR())) {
                        firebaseUser = zza(zzadW);
                    }
                }
            } catch (zzbvp e) {
            }
        }
        return firebaseUser;
    }

    public void zzWv() {
        clear("com.google.firebase.auth.FIREBASE_USER");
    }

    public void zza(@NonNull FirebaseUser firebaseUser, @NonNull zzbmn com_google_android_gms_internal_zzbmn) {
        zzac.zzw(firebaseUser);
        zzac.zzw(com_google_android_gms_internal_zzbmn);
        zzo(String.format("com.google.firebase.auth.GET_TOKEN_RESPONSE.%s", new Object[]{firebaseUser.getUid()}), com_google_android_gms_internal_zzbmn);
    }

    public void zzao(String str, String str2) {
        this.zzBd.edit().putString(str, str2).apply();
    }

    @Nullable
    public <T> T zze(String str, Class<T> cls) {
        Object obj = get(str);
        return TextUtils.isEmpty(obj) ? null : this.zzbYh.zzf(obj, cls);
    }

    public void zzf(@NonNull FirebaseUser firebaseUser) {
        zzac.zzw(firebaseUser);
        Object zzi = zzi(firebaseUser);
        if (!TextUtils.isEmpty(zzi)) {
            zzao("com.google.firebase.auth.FIREBASE_USER", zzi);
        }
    }

    public zzbmn zzg(@NonNull FirebaseUser firebaseUser) {
        zzac.zzw(firebaseUser);
        return (zzbmn) zze(String.format("com.google.firebase.auth.GET_TOKEN_RESPONSE.%s", new Object[]{firebaseUser.getUid()}), zzbmn.class);
    }

    public void zzh(@NonNull FirebaseUser firebaseUser) {
        zzac.zzw(firebaseUser);
        clear(String.format("com.google.firebase.auth.GET_TOKEN_RESPONSE.%s", new Object[]{firebaseUser.getUid()}));
    }

    public void zzo(String str, Object obj) {
        this.zzBd.edit().putString(str, this.zzbYh.zzaM(obj)).apply();
    }
}
