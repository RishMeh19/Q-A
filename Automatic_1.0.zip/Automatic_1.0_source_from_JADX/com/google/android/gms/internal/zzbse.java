package com.google.android.gms.internal;

public class zzbse extends zzbrw {
    private final zzbph zzcjF;

    public zzbse(zzbph com_google_android_gms_internal_zzbph) {
        if (com_google_android_gms_internal_zzbph.size() == 1 && com_google_android_gms_internal_zzbph.zzYU().zzaaM()) {
            throw new IllegalArgumentException("Can't create PathIndex with '.priority' as key. Please use PriorityIndex instead!");
        }
        this.zzcjF = com_google_android_gms_internal_zzbph;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return zza((zzbsb) obj, (zzbsb) obj2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.zzcjF.equals(((zzbse) obj).zzcjF);
    }

    public int hashCode() {
        return this.zzcjF.hashCode();
    }

    public int zza(zzbsb com_google_android_gms_internal_zzbsb, zzbsb com_google_android_gms_internal_zzbsb2) {
        int compareTo = com_google_android_gms_internal_zzbsb.zzWK().zzO(this.zzcjF).compareTo(com_google_android_gms_internal_zzbsb2.zzWK().zzO(this.zzcjF));
        return compareTo == 0 ? com_google_android_gms_internal_zzbsb.zzabl().zzi(com_google_android_gms_internal_zzbsb2.zzabl()) : compareTo;
    }

    public zzbsb zzabd() {
        return new zzbsb(zzbrq.zzaaJ(), zzbrv.zzabb().zzl(this.zzcjF, zzbsc.zzcjB));
    }

    public String zzabe() {
        return this.zzcjF.zzYS();
    }

    public zzbsb zzg(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
        return new zzbsb(com_google_android_gms_internal_zzbrq, zzbrv.zzabb().zzl(this.zzcjF, com_google_android_gms_internal_zzbsc));
    }

    public boolean zzm(zzbsc com_google_android_gms_internal_zzbsc) {
        return !com_google_android_gms_internal_zzbsc.zzO(this.zzcjF).isEmpty();
    }
}
