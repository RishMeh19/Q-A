package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;

public class zzbmx extends zza {
    public static final Creator<zzbmx> CREATOR = new zzbmy();
    @zzbvv("postBody")
    private String zzIg;
    @zzbmb
    public final int zzaiI;
    @zzbmb
    private String zzajB;
    @Nullable
    @zzbmb
    private String zzaka;
    @zzbmb
    private String zzbDW;
    @zzbmb
    private String zzbYA;
    @zzbvv("requestUri")
    private String zzbYP;
    @zzbvv("idToken")
    private String zzbYQ;
    @zzbvv("oauthTokenSecret")
    private String zzbYR;
    @zzbvv("returnSecureToken")
    private boolean zzbYS;

    public zzbmx() {
        this.zzaiI = 2;
        this.zzbYS = true;
    }

    zzbmx(int i, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, boolean z) {
        this.zzaiI = i;
        this.zzbYP = str;
        this.zzbYQ = str2;
        this.zzajB = str3;
        this.zzbDW = str4;
        this.zzbYA = str5;
        this.zzaka = str6;
        this.zzIg = str7;
        this.zzbYR = str8;
        this.zzbYS = z;
    }

    public zzbmx(@Nullable String str, @Nullable String str2, String str3, @Nullable String str4, @Nullable String str5) {
        this.zzaiI = 2;
        this.zzbYP = "http://localhost";
        this.zzajB = str;
        this.zzbDW = str2;
        this.zzbYR = str5;
        this.zzbYS = true;
        if (TextUtils.isEmpty(this.zzajB) && TextUtils.isEmpty(this.zzbDW)) {
            throw new IllegalArgumentException("Both idToken, and accessToken cannot be null");
        }
        this.zzbYA = zzac.zzdr(str3);
        this.zzaka = str4;
        StringBuilder stringBuilder = new StringBuilder();
        if (!TextUtils.isEmpty(this.zzajB)) {
            stringBuilder.append("id_token").append("=").append(this.zzajB).append("&");
        }
        if (!TextUtils.isEmpty(this.zzbDW)) {
            stringBuilder.append("access_token").append("=").append(this.zzbDW).append("&");
        }
        if (!TextUtils.isEmpty(this.zzaka)) {
            stringBuilder.append("identifier").append("=").append(this.zzaka).append("&");
        }
        if (!TextUtils.isEmpty(this.zzbYR)) {
            stringBuilder.append("oauth_token_secret").append("=").append(this.zzbYR).append("&");
        }
        stringBuilder.append("providerId").append("=").append(this.zzbYA);
        this.zzIg = stringBuilder.toString();
    }

    public String getAccessToken() {
        return this.zzbDW;
    }

    @Nullable
    public String getEmail() {
        return this.zzaka;
    }

    public String getIdToken() {
        return this.zzajB;
    }

    public String getProviderId() {
        return this.zzbYA;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmy.zza(this, parcel, i);
    }

    public String zzWo() {
        return this.zzbYP;
    }

    public String zzWp() {
        return this.zzbYQ;
    }

    public String zzWq() {
        return this.zzbYR;
    }

    public boolean zzWr() {
        return this.zzbYS;
    }

    public String zzgo() {
        return this.zzIg;
    }
}
