package com.example.automatic;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DatabaseReference.CompletionListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class activity_2 extends AppCompatActivity implements OnClickListener {
    private static final int SELECT_VIDEO = 3;
    String FIREBASE_URL = Config.FIREBASE_URL;
    DatabaseReference Users;
    private String ans;
    private Button button2;
    private Button button4;
    private Button buttonChoose;
    private Button buttonUpload;
    FirebaseDatabase database;
    private String email;
    private String filePath1;
    int f16i;
    private String id;
    private String name;
    ProgressDialog pDialog;
    private String selectedPath;
    private TextView textView10;
    private TextView textView6;
    private TextView textViewResponse;
    private TextView textViewee;
    DatabaseReference use;
    private String userId;
    private String value;

    class C04381 implements CompletionListener {
        C04381() {
        }

        public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
            if (databaseError == null) {
                activity_2.this.pDialog.dismiss();
                activity_2.this.textViewResponse.setText("Successfully submitted");
                return;
            }
            activity_2.this.pDialog.dismiss();
            activity_2.this.textViewResponse.setText("Sorry, can't submit your response!!Check your Internet connection");
        }
    }

    class C04392 implements ValueEventListener {
        C04392() {
        }

        public void onDataChange(DataSnapshot dataSnapshot) {
            if (dataSnapshot.hasChild("Score")) {
                activity_2.this.value = (String) dataSnapshot.child("Score").child("Score1").getValue(String.class);
                activity_2.this.textView6.setText("Your score for Answer-1 is " + activity_2.this.value + "\n");
                activity_2.this.value = (String) dataSnapshot.child("Score").child("Score2").getValue(String.class);
                activity_2.this.textView6.append("Your score for Answer-2 is " + activity_2.this.value + "\n");
                activity_2.this.value = (String) dataSnapshot.child("Score").child("ScoreT").getValue(String.class);
                activity_2.this.textView6.append("Your present Total Score is  " + activity_2.this.value + "\n");
                return;
            }
            activity_2.this.textView6.setText("You haven't answered yet or Your answers haven't been scored");
        }

        public void onCancelled(DatabaseError error) {
            activity_2.this.textView6.setText("sorry!!Check your Internet Connection");
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        this.name = extras.getString("NAME");
        this.email = extras.getString("EMAIL");
        this.ans = extras.getString("ANSWER");
        this.filePath1 = extras.getString("FILE_PATH");
        this.id = extras.getString("ID");
        setContentView((int) C0174R.layout.activity_2);
        this.buttonUpload = (Button) findViewById(C0174R.id.buttonUpload);
        this.button4 = (Button) findViewById(C0174R.id.button4);
        this.button2 = (Button) findViewById(C0174R.id.button2);
        this.textViewResponse = (TextView) findViewById(C0174R.id.textViewResponse);
        this.textViewee = (TextView) findViewById(C0174R.id.textViewee);
        this.textView6 = (TextView) findViewById(C0174R.id.textView6);
        this.textViewee.setText("Go Back to record another answer.");
        this.buttonUpload.setOnClickListener(this);
        this.button4.setOnClickListener(this);
        this.button2.setOnClickListener(this);
        this.database = FirebaseDatabase.getInstance();
        this.Users = this.database.getReference();
    }

    public void uploadVideo() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setTitle("Wait!!while we submit your response");
        this.pDialog.setMessage("Submitting...");
        this.pDialog.setIndeterminate(false);
        this.pDialog.setCancelable(false);
        this.pDialog.show();
        this.Users.child(this.id).child(this.ans).setValue(this.filePath1.trim(), new C04381());
    }

    public void playORdisplay() {
        this.textView6.setText(this.filePath1);
    }

    public void display() {
        this.Users.child(this.id).addListenerForSingleValueEvent(new C04392());
    }

    public void onClick(View v) {
        if (v == this.buttonUpload) {
            uploadVideo();
        }
        if (v == this.button4) {
            playORdisplay();
        }
        if (v == this.button2) {
            display();
        }
    }
}
