package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbod.zzb;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbog<K, V> extends zzbny<K, V> {
    private Comparator<K> zzcaQ;
    private zzbod<K, V> zzcbh;

    private static class zza<A, B, C> {
        private final Map<B, C> values;
        private final List<A> zzcbi;
        private final com.google.android.gms.internal.zzbny.zza.zza<A, B> zzcbj;
        private zzbof<A, C> zzcbk;
        private zzbof<A, C> zzcbl;

        static class zza implements Iterable<zzb> {
            private final int length;
            private long value;

            class C02681 implements Iterator<zzb> {
                private int zzcbm = (this.zzcbn.length - 1);
                final /* synthetic */ zza zzcbn;

                C02681(zza com_google_android_gms_internal_zzbog_zza_zza) {
                    this.zzcbn = com_google_android_gms_internal_zzbog_zza_zza;
                }

                public boolean hasNext() {
                    return this.zzcbm >= 0;
                }

                public /* synthetic */ Object next() {
                    return zzXq();
                }

                public void remove() {
                }

                public zzb zzXq() {
                    boolean z = true;
                    long zzb = this.zzcbn.value & ((long) (1 << this.zzcbm));
                    zzb com_google_android_gms_internal_zzbog_zza_zzb = new zzb();
                    if (zzb != 0) {
                        z = false;
                    }
                    com_google_android_gms_internal_zzbog_zza_zzb.zzcbo = z;
                    com_google_android_gms_internal_zzbog_zza_zzb.zzcbp = (int) Math.pow(2.0d, (double) this.zzcbm);
                    this.zzcbm--;
                    return com_google_android_gms_internal_zzbog_zza_zzb;
                }
            }

            public zza(int i) {
                int i2 = i + 1;
                this.length = (int) Math.floor(Math.log((double) i2) / Math.log(2.0d));
                this.value = ((long) i2) & (((long) Math.pow(2.0d, (double) this.length)) - 1);
            }

            public Iterator<zzb> iterator() {
                return new C02681(this);
            }
        }

        static class zzb {
            public boolean zzcbo;
            public int zzcbp;

            zzb() {
            }
        }

        private zza(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbny.zza.zza<A, B> com_google_android_gms_internal_zzbny_zza_zza_A__B) {
            this.zzcbi = list;
            this.values = map;
            this.zzcbj = com_google_android_gms_internal_zzbny_zza_zza_A__B;
        }

        private zzbod<A, C> zzF(int i, int i2) {
            if (i2 == 0) {
                return zzboc.zzXd();
            }
            if (i2 == 1) {
                Object obj = this.zzcbi.get(i);
                return new zzbob(obj, zzaq(obj), null, null);
            }
            int i3 = i2 / 2;
            int i4 = i + i3;
            zzbod zzF = zzF(i, i3);
            zzbod zzF2 = zzF(i4 + 1, i3);
            obj = this.zzcbi.get(i4);
            return new zzbob(obj, zzaq(obj), zzF, zzF2);
        }

        private void zza(com.google.android.gms.internal.zzbod.zza com_google_android_gms_internal_zzbod_zza, int i, int i2) {
            zzbod zzF = zzF(i2 + 1, i - 1);
            Object obj = this.zzcbi.get(i2);
            Object com_google_android_gms_internal_zzboe = com_google_android_gms_internal_zzbod_zza == com.google.android.gms.internal.zzbod.zza.RED ? new zzboe(obj, zzaq(obj), null, zzF) : new zzbob(obj, zzaq(obj), null, zzF);
            if (this.zzcbk == null) {
                this.zzcbk = com_google_android_gms_internal_zzboe;
                this.zzcbl = com_google_android_gms_internal_zzboe;
                return;
            }
            this.zzcbl.zzb(com_google_android_gms_internal_zzboe);
            this.zzcbl = com_google_android_gms_internal_zzboe;
        }

        private C zzaq(A a) {
            return this.values.get(this.zzcbj.zzal(a));
        }

        public static <A, B, C> zzbog<A, C> zzc(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbny.zza.zza<A, B> com_google_android_gms_internal_zzbny_zza_zza_A__B, Comparator<A> comparator) {
            zza com_google_android_gms_internal_zzbog_zza = new zza(list, map, com_google_android_gms_internal_zzbny_zza_zza_A__B);
            Collections.sort(list, comparator);
            Iterator it = new zza(list.size()).iterator();
            int size = list.size();
            while (it.hasNext()) {
                int i;
                zzb com_google_android_gms_internal_zzbog_zza_zzb = (zzb) it.next();
                size -= com_google_android_gms_internal_zzbog_zza_zzb.zzcbp;
                if (com_google_android_gms_internal_zzbog_zza_zzb.zzcbo) {
                    com_google_android_gms_internal_zzbog_zza.zza(com.google.android.gms.internal.zzbod.zza.BLACK, com_google_android_gms_internal_zzbog_zza_zzb.zzcbp, size);
                    i = size;
                } else {
                    com_google_android_gms_internal_zzbog_zza.zza(com.google.android.gms.internal.zzbod.zza.BLACK, com_google_android_gms_internal_zzbog_zza_zzb.zzcbp, size);
                    size -= com_google_android_gms_internal_zzbog_zza_zzb.zzcbp;
                    com_google_android_gms_internal_zzbog_zza.zza(com.google.android.gms.internal.zzbod.zza.RED, com_google_android_gms_internal_zzbog_zza_zzb.zzcbp, size);
                    i = size;
                }
                size = i;
            }
            return new zzbog(com_google_android_gms_internal_zzbog_zza.zzcbk == null ? zzboc.zzXd() : com_google_android_gms_internal_zzbog_zza.zzcbk, comparator);
        }
    }

    private zzbog(zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, Comparator<K> comparator) {
        this.zzcbh = com_google_android_gms_internal_zzbod_K__V;
        this.zzcaQ = comparator;
    }

    private zzbod<K, V> zzap(K k) {
        zzbod<K, V> com_google_android_gms_internal_zzbod_K__V = this.zzcbh;
        while (!com_google_android_gms_internal_zzbod_K__V.isEmpty()) {
            int compare = this.zzcaQ.compare(k, com_google_android_gms_internal_zzbod_K__V.getKey());
            if (compare < 0) {
                com_google_android_gms_internal_zzbod_K__V = com_google_android_gms_internal_zzbod_K__V.zzXe();
            } else if (compare == 0) {
                return com_google_android_gms_internal_zzbod_K__V;
            } else {
                com_google_android_gms_internal_zzbod_K__V = com_google_android_gms_internal_zzbod_K__V.zzXf();
            }
        }
        return null;
    }

    public static <A, B, C> zzbog<A, C> zzc(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbny.zza.zza<A, B> com_google_android_gms_internal_zzbny_zza_zza_A__B, Comparator<A> comparator) {
        return zza.zzc(list, map, com_google_android_gms_internal_zzbny_zza_zza_A__B, comparator);
    }

    public static <A, B> zzbog<A, B> zzc(Map<A, B> map, Comparator<A> comparator) {
        return zza.zzc(new ArrayList(map.keySet()), map, com.google.android.gms.internal.zzbny.zza.zzWY(), comparator);
    }

    public boolean containsKey(K k) {
        return zzap(k) != null;
    }

    public V get(K k) {
        zzbod zzap = zzap(k);
        return zzap != null ? zzap.getValue() : null;
    }

    public Comparator<K> getComparator() {
        return this.zzcaQ;
    }

    public boolean isEmpty() {
        return this.zzcbh.isEmpty();
    }

    public Iterator<Entry<K, V>> iterator() {
        return new zzbnz(this.zzcbh, null, this.zzcaQ, false);
    }

    public int size() {
        return this.zzcbh.zzXi();
    }

    public K zzWV() {
        return this.zzcbh.zzXg().getKey();
    }

    public K zzWW() {
        return this.zzcbh.zzXh().getKey();
    }

    public Iterator<Entry<K, V>> zzWX() {
        return new zzbnz(this.zzcbh, null, this.zzcaQ, true);
    }

    public void zza(zzb<K, V> com_google_android_gms_internal_zzbod_zzb_K__V) {
        this.zzcbh.zza(com_google_android_gms_internal_zzbod_zzb_K__V);
    }

    public zzbny<K, V> zzah(K k) {
        if (!containsKey(k)) {
            return this;
        }
        return new zzbog(this.zzcbh.zza(k, this.zzcaQ).zza(null, null, com.google.android.gms.internal.zzbod.zza.BLACK, null, null), this.zzcaQ);
    }

    public K zzai(K k) {
        zzbod com_google_android_gms_internal_zzbod = this.zzcbh;
        zzbod com_google_android_gms_internal_zzbod2 = null;
        while (!com_google_android_gms_internal_zzbod.isEmpty()) {
            int compare = this.zzcaQ.compare(k, com_google_android_gms_internal_zzbod.getKey());
            if (compare == 0) {
                if (com_google_android_gms_internal_zzbod.zzXe().isEmpty()) {
                    return com_google_android_gms_internal_zzbod2 != null ? com_google_android_gms_internal_zzbod2.getKey() : null;
                } else {
                    com_google_android_gms_internal_zzbod2 = com_google_android_gms_internal_zzbod.zzXe();
                    while (!com_google_android_gms_internal_zzbod2.zzXf().isEmpty()) {
                        com_google_android_gms_internal_zzbod2 = com_google_android_gms_internal_zzbod2.zzXf();
                    }
                    return com_google_android_gms_internal_zzbod2.getKey();
                }
            } else if (compare < 0) {
                com_google_android_gms_internal_zzbod = com_google_android_gms_internal_zzbod.zzXe();
            } else {
                zzbod com_google_android_gms_internal_zzbod3 = com_google_android_gms_internal_zzbod;
                com_google_android_gms_internal_zzbod = com_google_android_gms_internal_zzbod.zzXf();
                com_google_android_gms_internal_zzbod2 = com_google_android_gms_internal_zzbod3;
            }
        }
        String valueOf = String.valueOf(k);
        throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Couldn't find predecessor key of non-present key: ").append(valueOf).toString());
    }

    public zzbny<K, V> zzi(K k, V v) {
        return new zzbog(this.zzcbh.zza(k, v, this.zzcaQ).zza(null, null, com.google.android.gms.internal.zzbod.zza.BLACK, null, null), this.zzcaQ);
    }
}
