package com.google.android.gms.internal;

import java.lang.reflect.Field;

public interface zzbuz {
    String zzc(Field field);
}
