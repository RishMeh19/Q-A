package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqy.zza;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class zzbrg {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbrg.class.desiredAssertionStatus());
    private final Map<zzbrq, zzbqw> zzciD = new HashMap();

    public void zza(zzbqw com_google_android_gms_internal_zzbqw) {
        zza zzZX = com_google_android_gms_internal_zzbqw.zzZX();
        zzbrq zzZW = com_google_android_gms_internal_zzbqw.zzZW();
        if (!$assertionsDisabled && zzZX != zza.CHILD_ADDED && zzZX != zza.CHILD_CHANGED && zzZX != zza.CHILD_REMOVED) {
            throw new AssertionError("Only child changes supported for tracking");
        } else if (!$assertionsDisabled && com_google_android_gms_internal_zzbqw.zzZW().zzaaM()) {
            throw new AssertionError();
        } else if (this.zzciD.containsKey(zzZW)) {
            zzbqw com_google_android_gms_internal_zzbqw2 = (zzbqw) this.zzciD.get(zzZW);
            zza zzZX2 = com_google_android_gms_internal_zzbqw2.zzZX();
            if (zzZX == zza.CHILD_ADDED && zzZX2 == zza.CHILD_REMOVED) {
                this.zzciD.put(com_google_android_gms_internal_zzbqw.zzZW(), zzbqw.zza(zzZW, com_google_android_gms_internal_zzbqw.zzZU(), com_google_android_gms_internal_zzbqw2.zzZU()));
            } else if (zzZX == zza.CHILD_REMOVED && zzZX2 == zza.CHILD_ADDED) {
                this.zzciD.remove(zzZW);
            } else if (zzZX == zza.CHILD_REMOVED && zzZX2 == zza.CHILD_CHANGED) {
                this.zzciD.put(zzZW, zzbqw.zzb(zzZW, com_google_android_gms_internal_zzbqw2.zzZZ()));
            } else if (zzZX == zza.CHILD_CHANGED && zzZX2 == zza.CHILD_ADDED) {
                this.zzciD.put(zzZW, zzbqw.zza(zzZW, com_google_android_gms_internal_zzbqw.zzZU()));
            } else if (zzZX == zza.CHILD_CHANGED && zzZX2 == zza.CHILD_CHANGED) {
                this.zzciD.put(zzZW, zzbqw.zza(zzZW, com_google_android_gms_internal_zzbqw.zzZU(), com_google_android_gms_internal_zzbqw2.zzZZ()));
            } else {
                String valueOf = String.valueOf(com_google_android_gms_internal_zzbqw);
                String valueOf2 = String.valueOf(com_google_android_gms_internal_zzbqw2);
                throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 48) + String.valueOf(valueOf2).length()).append("Illegal combination of changes: ").append(valueOf).append(" occurred after ").append(valueOf2).toString());
            }
        } else {
            this.zzciD.put(com_google_android_gms_internal_zzbqw.zzZW(), com_google_android_gms_internal_zzbqw);
        }
    }

    public List<zzbqw> zzaaA() {
        return new ArrayList(this.zzciD.values());
    }
}
