package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbsc.zza;
import java.util.Map;

public class zzbrt extends zzbrz<zzbrt> {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbrt.class.desiredAssertionStatus());
    private Map<Object, Object> zzcjm;

    public zzbrt(Map<Object, Object> map, zzbsc com_google_android_gms_internal_zzbsc) {
        super(com_google_android_gms_internal_zzbsc);
        this.zzcjm = map;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zzbrt)) {
            return false;
        }
        zzbrt com_google_android_gms_internal_zzbrt = (zzbrt) obj;
        return this.zzcjm.equals(com_google_android_gms_internal_zzbrt.zzcjm) && this.zzciX.equals(com_google_android_gms_internal_zzbrt.zzciX);
    }

    public Object getValue() {
        return this.zzcjm;
    }

    public int hashCode() {
        return this.zzcjm.hashCode() + this.zzciX.hashCode();
    }

    public String zza(zza com_google_android_gms_internal_zzbsc_zza) {
        String valueOf = String.valueOf(zzb(com_google_android_gms_internal_zzbsc_zza));
        String valueOf2 = String.valueOf(this.zzcjm);
        return new StringBuilder((String.valueOf(valueOf).length() + 14) + String.valueOf(valueOf2).length()).append(valueOf).append("deferredValue:").append(valueOf2).toString();
    }

    protected zza zzaaH() {
        return zza.DeferredValue;
    }

    public /* synthetic */ zzbsc zzg(zzbsc com_google_android_gms_internal_zzbsc) {
        return zzj(com_google_android_gms_internal_zzbsc);
    }

    public zzbrt zzj(zzbsc com_google_android_gms_internal_zzbsc) {
        if ($assertionsDisabled || zzbsg.zzq(com_google_android_gms_internal_zzbsc)) {
            return new zzbrt(this.zzcjm, com_google_android_gms_internal_zzbsc);
        }
        throw new AssertionError();
    }
}
