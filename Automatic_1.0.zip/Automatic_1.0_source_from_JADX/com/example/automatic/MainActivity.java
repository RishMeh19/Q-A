package com.example.automatic;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DatabaseReference.CompletionListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity implements OnClickListener, OnConnectionFailedListener {
    private int RC_SIGN_IN = 100;
    DatabaseReference Users;
    private ImageButton button3;
    final AtomicInteger count = new AtomicInteger();
    FirebaseDatabase database;
    private GoogleSignInOptions gso;
    private GoogleApiClient mGoogleApiClient;
    private String f15s;
    private String s1;
    private String s2;
    private SignInButton signInButton;
    private TextView textViewEmail;
    private TextView textViewName;
    private TextView textViewResponse;
    long value;

    class C04331 implements CompletionListener {

        class C04321 implements CompletionListener {

            class C04311 implements ValueEventListener {
                C04311() {
                }

                public void onDataChange(DataSnapshot dataSnapshot) {
                    MainActivity.this.value = dataSnapshot.getChildrenCount();
                    MainActivity mainActivity = MainActivity.this;
                    mainActivity.value++;
                    MainActivity.this.Users.child("Users").child(String.valueOf(MainActivity.this.value)).setValue(MainActivity.this.s2);
                    MainActivity.this.Users.child("Co").child("Count").setValue(Long.valueOf(MainActivity.this.value));
                    MainActivity.this.textViewResponse.setText("Successfully Registered");
                    MainActivity.this.next();
                }

                public void onCancelled(DatabaseError error) {
                    MainActivity.this.textViewResponse.setText("Sorry, can't Register you!!Check your Internet connection");
                }
            }

            C04321() {
            }

            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                if (databaseError == null) {
                    MainActivity.this.Users.child("Users").addListenerForSingleValueEvent(new C04311());
                } else {
                    MainActivity.this.textViewResponse.setText("Sorry, can't Register you!!Check your Internet connection");
                }
            }
        }

        C04331() {
        }

        public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
            if (databaseError == null) {
                MainActivity.this.Users.child(MainActivity.this.s2).child("Email").setValue(MainActivity.this.s1, new C04321());
            } else {
                MainActivity.this.textViewResponse.setText("Sorry, can't Register you!!Check your Internet connection");
            }
        }
    }

    class C04342 implements ResultCallback<Status> {
        C04342() {
        }

        public void onResult(Status status) {
            MainActivity.this.textViewResponse.setText("You have been Signed Out successfully");
            MainActivity.this.textViewName.setText("");
            MainActivity.this.textViewEmail.setText("");
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0174R.layout.activity_main);
        this.textViewName = (TextView) findViewById(C0174R.id.textViewName);
        this.textViewEmail = (TextView) findViewById(C0174R.id.textViewEmail);
        this.textViewResponse = (TextView) findViewById(C0174R.id.textViewResponse);
        this.button3 = (ImageButton) findViewById(C0174R.id.button3);
        this.gso = new Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        this.signInButton = (SignInButton) findViewById(C0174R.id.sign_in_button);
        this.signInButton.setSize(1);
        this.signInButton.setScopes(this.gso.getScopeArray());
        this.mGoogleApiClient = new GoogleApiClient.Builder(this).enableAutoManage(this, this).addApi(Auth.GOOGLE_SIGN_IN_API, this.gso).build();
        this.button3.setOnClickListener(this);
        this.signInButton.setOnClickListener(this);
        this.button3.setEnabled(false);
        this.button3.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.database = FirebaseDatabase.getInstance();
        this.Users = this.database.getReference();
    }

    private void signIn() {
        startActivityForResult(Auth.GoogleSignInApi.getSignInIntent(this.mGoogleApiClient), this.RC_SIGN_IN);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.RC_SIGN_IN) {
            handleSignInResult(Auth.GoogleSignInApi.getSignInResultFromIntent(data));
        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            this.f15s = acct.getDisplayName();
            this.s1 = acct.getEmail();
            this.s2 = acct.getId();
            this.textViewName.setText(acct.getDisplayName());
            this.textViewEmail.setText(acct.getEmail());
            this.button3.setEnabled(true);
            this.Users.child(this.s2).child("Name").setValue(this.f15s, new C04331());
            return;
        }
        Toast.makeText(this, "Login Failed", 1).show();
    }

    public void next() {
        Intent myIntent = new Intent(this, activity_1.class);
        Bundle extras = new Bundle();
        extras.putString("NAME", this.f15s);
        extras.putString("EMAIL", this.s1);
        extras.putString("ID", this.s2);
        myIntent.putExtras(extras);
        startActivity(myIntent);
    }

    public void signout() {
        Auth.GoogleSignInApi.signOut(this.mGoogleApiClient).setResultCallback(new C04342());
    }

    public void onClick(View v) {
        if (v == this.signInButton) {
            signIn();
        }
        if (v == this.button3) {
            signout();
        }
    }

    public void onConnectionFailed(ConnectionResult connectionResult) {
    }
}
