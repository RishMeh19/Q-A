package com.example.automatic;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Person {
    public int Count;

    public void setCount(int Count) {
        this.Count = Count;
    }

    public int getCount() {
        return this.Count;
    }
}
