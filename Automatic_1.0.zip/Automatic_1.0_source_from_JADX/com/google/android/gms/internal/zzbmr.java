package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class zzbmr extends zza {
    public static final Creator<zzbmr> CREATOR = new zzbms();
    public final int zzaiI;
    private List<zzbmp> zzbYL;

    public zzbmr() {
        this.zzaiI = 1;
        this.zzbYL = new ArrayList();
    }

    zzbmr(int i, List<zzbmp> list) {
        this.zzaiI = i;
        if (list == null || list.isEmpty()) {
            this.zzbYL = Collections.emptyList();
        } else {
            this.zzbYL = Collections.unmodifiableList(list);
        }
    }

    public static zzbmr zzWj() {
        return new zzbmr();
    }

    public static zzbmr zza(zzbmr com_google_android_gms_internal_zzbmr) {
        Collection zzWb = com_google_android_gms_internal_zzbmr.zzWb();
        zzbmr com_google_android_gms_internal_zzbmr2 = new zzbmr();
        if (zzWb != null) {
            com_google_android_gms_internal_zzbmr2.zzWb().addAll(zzWb);
        }
        return com_google_android_gms_internal_zzbmr2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbms.zza(this, parcel, i);
    }

    public List<zzbmp> zzWb() {
        return this.zzbYL;
    }
}
