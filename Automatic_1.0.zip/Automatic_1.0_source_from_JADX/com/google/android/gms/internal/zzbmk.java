package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzbmk implements Creator<zzbmj> {
    static void zza(zzbmj com_google_android_gms_internal_zzbmj, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_internal_zzbmj.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_internal_zzbmj.getLocalId(), false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zzbmj.getEmail(), false);
        zzc.zza(parcel, 4, com_google_android_gms_internal_zzbmj.isEmailVerified());
        zzc.zza(parcel, 5, com_google_android_gms_internal_zzbmj.getDisplayName(), false);
        zzc.zza(parcel, 6, com_google_android_gms_internal_zzbmj.zzVN(), false);
        zzc.zza(parcel, 7, com_google_android_gms_internal_zzbmj.zzWc(), i, false);
        zzc.zza(parcel, 8, com_google_android_gms_internal_zzbmj.getPassword(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlF(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzqm(i);
    }

    public zzbmj zzlF(Parcel parcel) {
        boolean z = false;
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        zzbmr com_google_android_gms_internal_zzbmr = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        int i = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    str5 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 5:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 7:
                    com_google_android_gms_internal_zzbmr = (zzbmr) zzb.zza(parcel, zzaX, zzbmr.CREATOR);
                    break;
                case 8:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbmj(i, str5, str4, z, str3, str2, com_google_android_gms_internal_zzbmr, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbmj[] zzqm(int i) {
        return new zzbmj[i];
    }
}
