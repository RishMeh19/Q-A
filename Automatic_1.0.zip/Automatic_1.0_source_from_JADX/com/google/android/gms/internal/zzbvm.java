package com.google.android.gms.internal;

import java.math.BigInteger;

public final class zzbvm extends zzbvg {
    private static final Class<?>[] zzcrp = new Class[]{Integer.TYPE, Long.TYPE, Short.TYPE, Float.TYPE, Double.TYPE, Byte.TYPE, Boolean.TYPE, Character.TYPE, Integer.class, Long.class, Short.class, Float.class, Double.class, Byte.class, Boolean.class, Character.class};
    private Object value;

    public zzbvm(Boolean bool) {
        setValue(bool);
    }

    public zzbvm(Number number) {
        setValue(number);
    }

    zzbvm(Object obj) {
        setValue(obj);
    }

    public zzbvm(String str) {
        setValue(str);
    }

    private static boolean zza(zzbvm com_google_android_gms_internal_zzbvm) {
        if (!(com_google_android_gms_internal_zzbvm.value instanceof Number)) {
            return false;
        }
        Number number = (Number) com_google_android_gms_internal_zzbvm.value;
        return (number instanceof BigInteger) || (number instanceof Long) || (number instanceof Integer) || (number instanceof Short) || (number instanceof Byte);
    }

    private static boolean zzaO(Object obj) {
        if (obj instanceof String) {
            return true;
        }
        Class cls = obj.getClass();
        for (Class isAssignableFrom : zzcrp) {
            if (isAssignableFrom.isAssignableFrom(cls)) {
                return true;
            }
        }
        return false;
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbvm com_google_android_gms_internal_zzbvm = (zzbvm) obj;
        if (this.value == null) {
            return com_google_android_gms_internal_zzbvm.value == null;
        } else {
            if (zza(this) && zza(com_google_android_gms_internal_zzbvm)) {
                return zzadQ().longValue() == com_google_android_gms_internal_zzbvm.zzadQ().longValue();
            } else {
                if (!(this.value instanceof Number) || !(com_google_android_gms_internal_zzbvm.value instanceof Number)) {
                    return this.value.equals(com_google_android_gms_internal_zzbvm.value);
                }
                double doubleValue = zzadQ().doubleValue();
                double doubleValue2 = com_google_android_gms_internal_zzbvm.zzadQ().doubleValue();
                if (doubleValue == doubleValue2 || (Double.isNaN(doubleValue) && Double.isNaN(doubleValue2))) {
                    z = true;
                }
                return z;
            }
        }
    }

    public boolean getAsBoolean() {
        return zzaea() ? zzadZ().booleanValue() : Boolean.parseBoolean(zzadR());
    }

    public double getAsDouble() {
        return zzaeb() ? zzadQ().doubleValue() : Double.parseDouble(zzadR());
    }

    public int getAsInt() {
        return zzaeb() ? zzadQ().intValue() : Integer.parseInt(zzadR());
    }

    public long getAsLong() {
        return zzaeb() ? zzadQ().longValue() : Long.parseLong(zzadR());
    }

    public int hashCode() {
        if (this.value == null) {
            return 31;
        }
        long longValue;
        if (zza(this)) {
            longValue = zzadQ().longValue();
            return (int) (longValue ^ (longValue >>> 32));
        } else if (!(this.value instanceof Number)) {
            return this.value.hashCode();
        } else {
            longValue = Double.doubleToLongBits(zzadQ().doubleValue());
            return (int) (longValue ^ (longValue >>> 32));
        }
    }

    void setValue(Object obj) {
        if (obj instanceof Character) {
            this.value = String.valueOf(((Character) obj).charValue());
            return;
        }
        boolean z = (obj instanceof Number) || zzaO(obj);
        zzbvy.zzaw(z);
        this.value = obj;
    }

    public Number zzadQ() {
        return this.value instanceof String ? new zzbwd((String) this.value) : (Number) this.value;
    }

    public String zzadR() {
        return zzaeb() ? zzadQ().toString() : zzaea() ? zzadZ().toString() : (String) this.value;
    }

    Boolean zzadZ() {
        return (Boolean) this.value;
    }

    public boolean zzaea() {
        return this.value instanceof Boolean;
    }

    public boolean zzaeb() {
        return this.value instanceof Number;
    }

    public boolean zzaec() {
        return this.value instanceof String;
    }
}
