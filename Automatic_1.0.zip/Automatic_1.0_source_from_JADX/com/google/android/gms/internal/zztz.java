package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.internal.zztx.zzb;
import java.util.ArrayList;
import java.util.List;

public class zztz implements Creator<zzb> {
    static void zza(zzb com_google_android_gms_internal_zztx_zzb, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_internal_zztx_zzb.zzahw, i, false);
        zzc.zzc(parcel, 2, com_google_android_gms_internal_zztx_zzb.zzahx, false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zztx_zzb.zzahy, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzD(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzaO(i);
    }

    public zzb zzD(Parcel parcel) {
        String[] strArr = null;
        int zzaY = com.google.android.gms.common.internal.safeparcel.zzb.zzaY(parcel);
        List list = null;
        Status status = null;
        while (parcel.dataPosition() < zzaY) {
            List list2;
            Status status2;
            String[] strArr2;
            int zzaX = com.google.android.gms.common.internal.safeparcel.zzb.zzaX(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zzb.zzdc(zzaX)) {
                case 1:
                    String[] strArr3 = strArr;
                    list2 = list;
                    status2 = (Status) com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, zzaX, Status.CREATOR);
                    strArr2 = strArr3;
                    break;
                case 2:
                    status2 = status;
                    ArrayList zzc = com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, zzaX, zzud.CREATOR);
                    strArr2 = strArr;
                    Object obj = zzc;
                    break;
                case 3:
                    strArr2 = com.google.android.gms.common.internal.safeparcel.zzb.zzC(parcel, zzaX);
                    list2 = list;
                    status2 = status;
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, zzaX);
                    strArr2 = strArr;
                    list2 = list;
                    status2 = status;
                    break;
            }
            status = status2;
            list = list2;
            strArr = strArr2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzb(status, list, strArr);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzb[] zzaO(int i) {
        return new zzb[i];
    }
}
