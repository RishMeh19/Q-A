package com.google.android.gms.internal;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.GetTokenResult;

public interface zzbti {
    Task<GetTokenResult> zzaW(boolean z);
}
