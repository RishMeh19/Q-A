package com.google.android.gms.internal;

import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.zzvk.zza;

public class zzuy extends zza {
    public void zza(Status status, Credential credential) {
        throw new UnsupportedOperationException();
    }

    public void zza(Status status, String str) {
        throw new UnsupportedOperationException();
    }

    public void zzh(Status status) {
        throw new UnsupportedOperationException();
    }
}
