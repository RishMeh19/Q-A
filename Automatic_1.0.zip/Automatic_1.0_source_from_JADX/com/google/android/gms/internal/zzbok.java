package com.google.android.gms.internal;

public interface zzbok {

    public interface zza {
        void onError(String str);

        void zziL(String str);
    }

    void zza(boolean z, zza com_google_android_gms_internal_zzbok_zza);
}
