package com.google.android.gms.internal;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;

public final class zzbwe<K, V> extends AbstractMap<K, V> implements Serializable {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbwe.class.desiredAssertionStatus());
    private static final Comparator<Comparable> zzcsb = new C03151();
    int modCount;
    int size;
    Comparator<? super K> zzcaQ;
    zzd<K, V> zzcsc;
    final zzd<K, V> zzcsd;
    private zza zzcse;
    private zzb zzcsf;

    static class C03151 implements Comparator<Comparable> {
        C03151() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return zza((Comparable) obj, (Comparable) obj2);
        }

        public int zza(Comparable comparable, Comparable comparable2) {
            return comparable.compareTo(comparable2);
        }
    }

    class zza extends AbstractSet<Entry<K, V>> {
        final /* synthetic */ zzbwe zzcsg;

        class C05611 extends zzc<Entry<K, V>> {
            final /* synthetic */ zza zzcsh;

            C05611(zza com_google_android_gms_internal_zzbwe_zza) {
                this.zzcsh = com_google_android_gms_internal_zzbwe_zza;
                super();
            }

            public Entry<K, V> next() {
                return zzaei();
            }
        }

        zza(zzbwe com_google_android_gms_internal_zzbwe) {
            this.zzcsg = com_google_android_gms_internal_zzbwe;
        }

        public void clear() {
            this.zzcsg.clear();
        }

        public boolean contains(Object obj) {
            return (obj instanceof Entry) && this.zzcsg.zzc((Entry) obj) != null;
        }

        public Iterator<Entry<K, V>> iterator() {
            return new C05611(this);
        }

        public boolean remove(Object obj) {
            if (!(obj instanceof Entry)) {
                return false;
            }
            zzd zzc = this.zzcsg.zzc((Entry) obj);
            if (zzc == null) {
                return false;
            }
            this.zzcsg.zza(zzc, true);
            return true;
        }

        public int size() {
            return this.zzcsg.size;
        }
    }

    final class zzb extends AbstractSet<K> {
        final /* synthetic */ zzbwe zzcsg;

        class C05621 extends zzc<K> {
            final /* synthetic */ zzb zzcsi;

            C05621(zzb com_google_android_gms_internal_zzbwe_zzb) {
                this.zzcsi = com_google_android_gms_internal_zzbwe_zzb;
                super();
            }

            public K next() {
                return zzaei().zzcbe;
            }
        }

        zzb(zzbwe com_google_android_gms_internal_zzbwe) {
            this.zzcsg = com_google_android_gms_internal_zzbwe;
        }

        public void clear() {
            this.zzcsg.clear();
        }

        public boolean contains(Object obj) {
            return this.zzcsg.containsKey(obj);
        }

        public Iterator<K> iterator() {
            return new C05621(this);
        }

        public boolean remove(Object obj) {
            return this.zzcsg.zzaT(obj) != null;
        }

        public int size() {
            return this.zzcsg.size;
        }
    }

    private abstract class zzc<T> implements Iterator<T> {
        final /* synthetic */ zzbwe zzcsg;
        zzd<K, V> zzcsj;
        zzd<K, V> zzcsk;
        int zzcsl;

        private zzc(zzbwe com_google_android_gms_internal_zzbwe) {
            this.zzcsg = com_google_android_gms_internal_zzbwe;
            this.zzcsj = this.zzcsg.zzcsd.zzcsj;
            this.zzcsk = null;
            this.zzcsl = this.zzcsg.modCount;
        }

        public final boolean hasNext() {
            return this.zzcsj != this.zzcsg.zzcsd;
        }

        public final void remove() {
            if (this.zzcsk == null) {
                throw new IllegalStateException();
            }
            this.zzcsg.zza(this.zzcsk, true);
            this.zzcsk = null;
            this.zzcsl = this.zzcsg.modCount;
        }

        final zzd<K, V> zzaei() {
            zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V = this.zzcsj;
            if (com_google_android_gms_internal_zzbwe_zzd_K__V == this.zzcsg.zzcsd) {
                throw new NoSuchElementException();
            } else if (this.zzcsg.modCount != this.zzcsl) {
                throw new ConcurrentModificationException();
            } else {
                this.zzcsj = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsj;
                this.zzcsk = com_google_android_gms_internal_zzbwe_zzd_K__V;
                return com_google_android_gms_internal_zzbwe_zzd_K__V;
            }
        }
    }

    static final class zzd<K, V> implements Entry<K, V> {
        int height;
        V value;
        final K zzcbe;
        zzd<K, V> zzcsj;
        zzd<K, V> zzcsm;
        zzd<K, V> zzcsn;
        zzd<K, V> zzcso;
        zzd<K, V> zzcsp;

        zzd() {
            this.zzcbe = null;
            this.zzcsp = this;
            this.zzcsj = this;
        }

        zzd(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V, K k, zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V2, zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V3) {
            this.zzcsm = com_google_android_gms_internal_zzbwe_zzd_K__V;
            this.zzcbe = k;
            this.height = 1;
            this.zzcsj = com_google_android_gms_internal_zzbwe_zzd_K__V2;
            this.zzcsp = com_google_android_gms_internal_zzbwe_zzd_K__V3;
            com_google_android_gms_internal_zzbwe_zzd_K__V3.zzcsj = this;
            com_google_android_gms_internal_zzbwe_zzd_K__V2.zzcsp = this;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof Entry)) {
                return false;
            }
            Entry entry = (Entry) obj;
            if (this.zzcbe == null) {
                if (entry.getKey() != null) {
                    return false;
                }
            } else if (!this.zzcbe.equals(entry.getKey())) {
                return false;
            }
            if (this.value == null) {
                if (entry.getValue() != null) {
                    return false;
                }
            } else if (!this.value.equals(entry.getValue())) {
                return false;
            }
            return true;
        }

        public K getKey() {
            return this.zzcbe;
        }

        public V getValue() {
            return this.value;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = this.zzcbe == null ? 0 : this.zzcbe.hashCode();
            if (this.value != null) {
                i = this.value.hashCode();
            }
            return hashCode ^ i;
        }

        public V setValue(V v) {
            V v2 = this.value;
            this.value = v;
            return v2;
        }

        public String toString() {
            String valueOf = String.valueOf(this.zzcbe);
            String valueOf2 = String.valueOf(this.value);
            return new StringBuilder((String.valueOf(valueOf).length() + 1) + String.valueOf(valueOf2).length()).append(valueOf).append("=").append(valueOf2).toString();
        }

        public zzd<K, V> zzaej() {
            zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V;
            for (zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V2 = this.zzcsn; com_google_android_gms_internal_zzbwe_zzd_K__V2 != null; com_google_android_gms_internal_zzbwe_zzd_K__V2 = com_google_android_gms_internal_zzbwe_zzd_K__V2.zzcsn) {
                com_google_android_gms_internal_zzbwe_zzd_K__V = com_google_android_gms_internal_zzbwe_zzd_K__V2;
            }
            return com_google_android_gms_internal_zzbwe_zzd_K__V;
        }

        public zzd<K, V> zzaek() {
            zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V;
            for (zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V2 = this.zzcso; com_google_android_gms_internal_zzbwe_zzd_K__V2 != null; com_google_android_gms_internal_zzbwe_zzd_K__V2 = com_google_android_gms_internal_zzbwe_zzd_K__V2.zzcso) {
                com_google_android_gms_internal_zzbwe_zzd_K__V = com_google_android_gms_internal_zzbwe_zzd_K__V2;
            }
            return com_google_android_gms_internal_zzbwe_zzd_K__V;
        }
    }

    public zzbwe() {
        this(zzcsb);
    }

    public zzbwe(Comparator<? super K> comparator) {
        Comparator comparator2;
        this.size = 0;
        this.modCount = 0;
        this.zzcsd = new zzd();
        if (comparator == null) {
            comparator2 = zzcsb;
        }
        this.zzcaQ = comparator2;
    }

    private boolean equal(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    private void zza(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V) {
        int i = 0;
        zzd com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn;
        zzd com_google_android_gms_internal_zzbwe_zzd2 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso;
        zzd com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd2.zzcsn;
        zzd com_google_android_gms_internal_zzbwe_zzd4 = com_google_android_gms_internal_zzbwe_zzd2.zzcso;
        com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso = com_google_android_gms_internal_zzbwe_zzd3;
        if (com_google_android_gms_internal_zzbwe_zzd3 != null) {
            com_google_android_gms_internal_zzbwe_zzd3.zzcsm = com_google_android_gms_internal_zzbwe_zzd_K__V;
        }
        zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, com_google_android_gms_internal_zzbwe_zzd2);
        com_google_android_gms_internal_zzbwe_zzd2.zzcsn = com_google_android_gms_internal_zzbwe_zzd_K__V;
        com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsm = com_google_android_gms_internal_zzbwe_zzd2;
        com_google_android_gms_internal_zzbwe_zzd_K__V.height = Math.max(com_google_android_gms_internal_zzbwe_zzd != null ? com_google_android_gms_internal_zzbwe_zzd.height : 0, com_google_android_gms_internal_zzbwe_zzd3 != null ? com_google_android_gms_internal_zzbwe_zzd3.height : 0) + 1;
        int i2 = com_google_android_gms_internal_zzbwe_zzd_K__V.height;
        if (com_google_android_gms_internal_zzbwe_zzd4 != null) {
            i = com_google_android_gms_internal_zzbwe_zzd4.height;
        }
        com_google_android_gms_internal_zzbwe_zzd2.height = Math.max(i2, i) + 1;
    }

    private void zza(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V, zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V2) {
        zzd com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsm;
        com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsm = null;
        if (com_google_android_gms_internal_zzbwe_zzd_K__V2 != null) {
            com_google_android_gms_internal_zzbwe_zzd_K__V2.zzcsm = com_google_android_gms_internal_zzbwe_zzd;
        }
        if (com_google_android_gms_internal_zzbwe_zzd == null) {
            this.zzcsc = com_google_android_gms_internal_zzbwe_zzd_K__V2;
        } else if (com_google_android_gms_internal_zzbwe_zzd.zzcsn == com_google_android_gms_internal_zzbwe_zzd_K__V) {
            com_google_android_gms_internal_zzbwe_zzd.zzcsn = com_google_android_gms_internal_zzbwe_zzd_K__V2;
        } else if ($assertionsDisabled || com_google_android_gms_internal_zzbwe_zzd.zzcso == com_google_android_gms_internal_zzbwe_zzd_K__V) {
            com_google_android_gms_internal_zzbwe_zzd.zzcso = com_google_android_gms_internal_zzbwe_zzd_K__V2;
        } else {
            throw new AssertionError();
        }
    }

    private void zzb(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V) {
        int i = 0;
        zzd com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn;
        zzd com_google_android_gms_internal_zzbwe_zzd2 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso;
        zzd com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd.zzcsn;
        zzd com_google_android_gms_internal_zzbwe_zzd4 = com_google_android_gms_internal_zzbwe_zzd.zzcso;
        com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn = com_google_android_gms_internal_zzbwe_zzd4;
        if (com_google_android_gms_internal_zzbwe_zzd4 != null) {
            com_google_android_gms_internal_zzbwe_zzd4.zzcsm = com_google_android_gms_internal_zzbwe_zzd_K__V;
        }
        zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, com_google_android_gms_internal_zzbwe_zzd);
        com_google_android_gms_internal_zzbwe_zzd.zzcso = com_google_android_gms_internal_zzbwe_zzd_K__V;
        com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsm = com_google_android_gms_internal_zzbwe_zzd;
        com_google_android_gms_internal_zzbwe_zzd_K__V.height = Math.max(com_google_android_gms_internal_zzbwe_zzd2 != null ? com_google_android_gms_internal_zzbwe_zzd2.height : 0, com_google_android_gms_internal_zzbwe_zzd4 != null ? com_google_android_gms_internal_zzbwe_zzd4.height : 0) + 1;
        int i2 = com_google_android_gms_internal_zzbwe_zzd_K__V.height;
        if (com_google_android_gms_internal_zzbwe_zzd3 != null) {
            i = com_google_android_gms_internal_zzbwe_zzd3.height;
        }
        com_google_android_gms_internal_zzbwe_zzd.height = Math.max(i2, i) + 1;
    }

    private void zzb(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V, boolean z) {
        zzd com_google_android_gms_internal_zzbwe_zzd;
        while (com_google_android_gms_internal_zzbwe_zzd != null) {
            zzd com_google_android_gms_internal_zzbwe_zzd2 = com_google_android_gms_internal_zzbwe_zzd.zzcsn;
            zzd com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd.zzcso;
            int i = com_google_android_gms_internal_zzbwe_zzd2 != null ? com_google_android_gms_internal_zzbwe_zzd2.height : 0;
            int i2 = com_google_android_gms_internal_zzbwe_zzd3 != null ? com_google_android_gms_internal_zzbwe_zzd3.height : 0;
            int i3 = i - i2;
            zzd com_google_android_gms_internal_zzbwe_zzd4;
            if (i3 == -2) {
                com_google_android_gms_internal_zzbwe_zzd2 = com_google_android_gms_internal_zzbwe_zzd3.zzcsn;
                com_google_android_gms_internal_zzbwe_zzd4 = com_google_android_gms_internal_zzbwe_zzd3.zzcso;
                i2 = (com_google_android_gms_internal_zzbwe_zzd2 != null ? com_google_android_gms_internal_zzbwe_zzd2.height : 0) - (com_google_android_gms_internal_zzbwe_zzd4 != null ? com_google_android_gms_internal_zzbwe_zzd4.height : 0);
                if (i2 == -1 || (i2 == 0 && !z)) {
                    zza(com_google_android_gms_internal_zzbwe_zzd);
                } else if ($assertionsDisabled || i2 == 1) {
                    zzb(com_google_android_gms_internal_zzbwe_zzd3);
                    zza(com_google_android_gms_internal_zzbwe_zzd);
                } else {
                    throw new AssertionError();
                }
                if (z) {
                    return;
                }
            } else if (i3 == 2) {
                com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd2.zzcsn;
                com_google_android_gms_internal_zzbwe_zzd4 = com_google_android_gms_internal_zzbwe_zzd2.zzcso;
                i2 = (com_google_android_gms_internal_zzbwe_zzd3 != null ? com_google_android_gms_internal_zzbwe_zzd3.height : 0) - (com_google_android_gms_internal_zzbwe_zzd4 != null ? com_google_android_gms_internal_zzbwe_zzd4.height : 0);
                if (i2 == 1 || (i2 == 0 && !z)) {
                    zzb(com_google_android_gms_internal_zzbwe_zzd);
                } else if ($assertionsDisabled || i2 == -1) {
                    zza(com_google_android_gms_internal_zzbwe_zzd2);
                    zzb(com_google_android_gms_internal_zzbwe_zzd);
                } else {
                    throw new AssertionError();
                }
                if (z) {
                    return;
                }
            } else if (i3 == 0) {
                com_google_android_gms_internal_zzbwe_zzd.height = i + 1;
                if (z) {
                    return;
                }
            } else if ($assertionsDisabled || i3 == -1 || i3 == 1) {
                com_google_android_gms_internal_zzbwe_zzd.height = Math.max(i, i2) + 1;
                if (!z) {
                    return;
                }
            } else {
                throw new AssertionError();
            }
            com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd.zzcsm;
        }
    }

    public void clear() {
        this.zzcsc = null;
        this.size = 0;
        this.modCount++;
        zzd com_google_android_gms_internal_zzbwe_zzd = this.zzcsd;
        com_google_android_gms_internal_zzbwe_zzd.zzcsp = com_google_android_gms_internal_zzbwe_zzd;
        com_google_android_gms_internal_zzbwe_zzd.zzcsj = com_google_android_gms_internal_zzbwe_zzd;
    }

    public boolean containsKey(Object obj) {
        return zzaS(obj) != null;
    }

    public Set<Entry<K, V>> entrySet() {
        Set set = this.zzcse;
        if (set != null) {
            return set;
        }
        set = new zza(this);
        this.zzcse = set;
        return set;
    }

    public V get(Object obj) {
        zzd zzaS = zzaS(obj);
        return zzaS != null ? zzaS.value : null;
    }

    public Set<K> keySet() {
        Set set = this.zzcsf;
        if (set != null) {
            return set;
        }
        set = new zzb(this);
        this.zzcsf = set;
        return set;
    }

    public V put(K k, V v) {
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        zzd zza = zza((Object) k, true);
        V v2 = zza.value;
        zza.value = v;
        return v2;
    }

    public V remove(Object obj) {
        zzd zzaT = zzaT(obj);
        return zzaT != null ? zzaT.value : null;
    }

    public int size() {
        return this.size;
    }

    zzd<K, V> zza(K k, boolean z) {
        int i;
        Comparator comparator = this.zzcaQ;
        zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V = this.zzcsc;
        if (com_google_android_gms_internal_zzbwe_zzd_K__V != null) {
            int compareTo;
            Comparable comparable = comparator == zzcsb ? (Comparable) k : null;
            while (true) {
                compareTo = comparable != null ? comparable.compareTo(com_google_android_gms_internal_zzbwe_zzd_K__V.zzcbe) : comparator.compare(k, com_google_android_gms_internal_zzbwe_zzd_K__V.zzcbe);
                if (compareTo == 0) {
                    return com_google_android_gms_internal_zzbwe_zzd_K__V;
                }
                zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V2 = compareTo < 0 ? com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn : com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso;
                if (com_google_android_gms_internal_zzbwe_zzd_K__V2 == null) {
                    break;
                }
                com_google_android_gms_internal_zzbwe_zzd_K__V = com_google_android_gms_internal_zzbwe_zzd_K__V2;
            }
            int i2 = compareTo;
            zzd com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd_K__V;
            i = i2;
        } else {
            zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V3 = com_google_android_gms_internal_zzbwe_zzd_K__V;
            i = 0;
        }
        if (!z) {
            return null;
        }
        zzd<K, V> com_google_android_gms_internal_zzbwe_zzd2;
        zzd com_google_android_gms_internal_zzbwe_zzd3 = this.zzcsd;
        if (com_google_android_gms_internal_zzbwe_zzd != null) {
            com_google_android_gms_internal_zzbwe_zzd2 = new zzd(com_google_android_gms_internal_zzbwe_zzd, k, com_google_android_gms_internal_zzbwe_zzd3, com_google_android_gms_internal_zzbwe_zzd3.zzcsp);
            if (i < 0) {
                com_google_android_gms_internal_zzbwe_zzd.zzcsn = com_google_android_gms_internal_zzbwe_zzd2;
            } else {
                com_google_android_gms_internal_zzbwe_zzd.zzcso = com_google_android_gms_internal_zzbwe_zzd2;
            }
            zzb(com_google_android_gms_internal_zzbwe_zzd, true);
        } else if (comparator != zzcsb || (k instanceof Comparable)) {
            com_google_android_gms_internal_zzbwe_zzd2 = new zzd(com_google_android_gms_internal_zzbwe_zzd, k, com_google_android_gms_internal_zzbwe_zzd3, com_google_android_gms_internal_zzbwe_zzd3.zzcsp);
            this.zzcsc = com_google_android_gms_internal_zzbwe_zzd2;
        } else {
            throw new ClassCastException(String.valueOf(k.getClass().getName()).concat(" is not Comparable"));
        }
        this.size++;
        this.modCount++;
        return com_google_android_gms_internal_zzbwe_zzd2;
    }

    void zza(zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V, boolean z) {
        int i = 0;
        if (z) {
            com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsp.zzcsj = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsj;
            com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsj.zzcsp = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsp;
        }
        zzd com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn;
        zzd com_google_android_gms_internal_zzbwe_zzd2 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso;
        zzd com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsm;
        if (com_google_android_gms_internal_zzbwe_zzd == null || com_google_android_gms_internal_zzbwe_zzd2 == null) {
            if (com_google_android_gms_internal_zzbwe_zzd != null) {
                zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, com_google_android_gms_internal_zzbwe_zzd);
                com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn = null;
            } else if (com_google_android_gms_internal_zzbwe_zzd2 != null) {
                zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, com_google_android_gms_internal_zzbwe_zzd2);
                com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso = null;
            } else {
                zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, null);
            }
            zzb(com_google_android_gms_internal_zzbwe_zzd3, false);
            this.size--;
            this.modCount++;
            return;
        }
        int i2;
        com_google_android_gms_internal_zzbwe_zzd = com_google_android_gms_internal_zzbwe_zzd.height > com_google_android_gms_internal_zzbwe_zzd2.height ? com_google_android_gms_internal_zzbwe_zzd.zzaek() : com_google_android_gms_internal_zzbwe_zzd2.zzaej();
        zza(com_google_android_gms_internal_zzbwe_zzd, false);
        com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn;
        if (com_google_android_gms_internal_zzbwe_zzd3 != null) {
            i2 = com_google_android_gms_internal_zzbwe_zzd3.height;
            com_google_android_gms_internal_zzbwe_zzd.zzcsn = com_google_android_gms_internal_zzbwe_zzd3;
            com_google_android_gms_internal_zzbwe_zzd3.zzcsm = com_google_android_gms_internal_zzbwe_zzd;
            com_google_android_gms_internal_zzbwe_zzd_K__V.zzcsn = null;
        } else {
            i2 = 0;
        }
        com_google_android_gms_internal_zzbwe_zzd3 = com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso;
        if (com_google_android_gms_internal_zzbwe_zzd3 != null) {
            i = com_google_android_gms_internal_zzbwe_zzd3.height;
            com_google_android_gms_internal_zzbwe_zzd.zzcso = com_google_android_gms_internal_zzbwe_zzd3;
            com_google_android_gms_internal_zzbwe_zzd3.zzcsm = com_google_android_gms_internal_zzbwe_zzd;
            com_google_android_gms_internal_zzbwe_zzd_K__V.zzcso = null;
        }
        com_google_android_gms_internal_zzbwe_zzd.height = Math.max(i2, i) + 1;
        zza((zzd) com_google_android_gms_internal_zzbwe_zzd_K__V, com_google_android_gms_internal_zzbwe_zzd);
    }

    zzd<K, V> zzaS(Object obj) {
        zzd<K, V> com_google_android_gms_internal_zzbwe_zzd_K__V = null;
        if (obj != null) {
            try {
                com_google_android_gms_internal_zzbwe_zzd_K__V = zza(obj, false);
            } catch (ClassCastException e) {
            }
        }
        return com_google_android_gms_internal_zzbwe_zzd_K__V;
    }

    zzd<K, V> zzaT(Object obj) {
        zzd zzaS = zzaS(obj);
        if (zzaS != null) {
            zza(zzaS, true);
        }
        return zzaS;
    }

    zzd<K, V> zzc(Entry<?, ?> entry) {
        zzd<K, V> zzaS = zzaS(entry.getKey());
        Object obj = (zzaS == null || !equal(zzaS.value, entry.getValue())) ? null : 1;
        return obj != null ? zzaS : null;
    }
}
