package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public final class zzbwj<E> extends zzbvs<Object> {
    public static final zzbvt zzcsz = new C05671();
    private final Class<E> zzcsA;
    private final zzbvs<E> zzcsB;

    static class C05671 implements zzbvt {
        C05671() {
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            Type zzaez = com_google_android_gms_internal_zzbww_T.zzaez();
            if (!(zzaez instanceof GenericArrayType) && (!(zzaez instanceof Class) || !((Class) zzaez).isArray())) {
                return null;
            }
            zzaez = zzbvz.zzh(zzaez);
            return new zzbwj(com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbva.zza(zzbww.zzl(zzaez)), zzbvz.zzf(zzaez));
        }
    }

    public zzbwj(zzbva com_google_android_gms_internal_zzbva, zzbvs<E> com_google_android_gms_internal_zzbvs_E, Class<E> cls) {
        this.zzcsB = new zzbwu(com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbvs_E, cls);
        this.zzcsA = cls;
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, Object obj) throws IOException {
        if (obj == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
            return;
        }
        com_google_android_gms_internal_zzbwz.zzaet();
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            this.zzcsB.zza(com_google_android_gms_internal_zzbwz, Array.get(obj, i));
        }
        com_google_android_gms_internal_zzbwz.zzaeu();
    }

    public Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
        List arrayList = new ArrayList();
        com_google_android_gms_internal_zzbwx.beginArray();
        while (com_google_android_gms_internal_zzbwx.hasNext()) {
            arrayList.add(this.zzcsB.zzb(com_google_android_gms_internal_zzbwx));
        }
        com_google_android_gms_internal_zzbwx.endArray();
        Object newInstance = Array.newInstance(this.zzcsA, arrayList.size());
        for (int i = 0; i < arrayList.size(); i++) {
            Array.set(newInstance, i, arrayList.get(i));
        }
        return newInstance;
    }
}
