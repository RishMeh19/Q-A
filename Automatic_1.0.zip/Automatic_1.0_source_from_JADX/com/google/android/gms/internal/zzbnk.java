package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import java.util.concurrent.Executor;

public class zzbnk implements Executor {
    private static zzbnk zzbZg = new zzbnk();
    private Handler mHandler = new Handler(Looper.getMainLooper());

    private zzbnk() {
    }

    public static zzbnk zzWw() {
        return zzbZg;
    }

    public void execute(@NonNull Runnable runnable) {
        this.mHandler.post(runnable);
    }
}
