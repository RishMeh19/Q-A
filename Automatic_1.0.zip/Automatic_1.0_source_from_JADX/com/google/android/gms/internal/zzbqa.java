package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class zzbqa implements zzbpd {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbqa.class.desiredAssertionStatus());
    private static zzbqa zzcgG = new zzbqa();
    final HashMap<zzbpc, List<zzbpc>> zzcgF = new HashMap();

    private zzbqa() {
    }

    public static zzbqa zzZw() {
        return zzcgG;
    }

    private void zzj(zzbpc com_google_android_gms_internal_zzbpc) {
        int i = 0;
        synchronized (this.zzcgF) {
            List list = (List) this.zzcgF.get(com_google_android_gms_internal_zzbpc);
            int i2;
            if (list != null) {
                int i3;
                for (int i4 = 0; i4 < list.size(); i4++) {
                    if (list.get(i4) == com_google_android_gms_internal_zzbpc) {
                        i3 = 1;
                        list.remove(i4);
                        break;
                    }
                }
                i3 = 0;
                if (list.isEmpty()) {
                    this.zzcgF.remove(com_google_android_gms_internal_zzbpc);
                }
                i2 = i3;
            } else {
                i2 = 0;
            }
            if (!$assertionsDisabled && r0 == 0 && com_google_android_gms_internal_zzbpc.zzYO()) {
                throw new AssertionError();
            }
            if (!com_google_android_gms_internal_zzbpc.zzYp().isDefault()) {
                zzbpc zza = com_google_android_gms_internal_zzbpc.zza(zzbrc.zzN(com_google_android_gms_internal_zzbpc.zzYp().zzWO()));
                list = (List) this.zzcgF.get(zza);
                if (list != null) {
                    while (i < list.size()) {
                        if (list.get(i) == com_google_android_gms_internal_zzbpc) {
                            list.remove(i);
                            break;
                        }
                        i++;
                    }
                    if (list.isEmpty()) {
                        this.zzcgF.remove(zza);
                    }
                }
            }
        }
    }

    public void zzd(zzbpc com_google_android_gms_internal_zzbpc) {
        zzj(com_google_android_gms_internal_zzbpc);
    }

    public void zzi(zzbpc com_google_android_gms_internal_zzbpc) {
        synchronized (this.zzcgF) {
            List list = (List) this.zzcgF.get(com_google_android_gms_internal_zzbpc);
            if (list == null) {
                list = new ArrayList();
                this.zzcgF.put(com_google_android_gms_internal_zzbpc, list);
            }
            list.add(com_google_android_gms_internal_zzbpc);
            if (!com_google_android_gms_internal_zzbpc.zzYp().isDefault()) {
                zzbpc zza = com_google_android_gms_internal_zzbpc.zza(zzbrc.zzN(com_google_android_gms_internal_zzbpc.zzYp().zzWO()));
                list = (List) this.zzcgF.get(zza);
                if (list == null) {
                    list = new ArrayList();
                    this.zzcgF.put(zza, list);
                }
                list.add(com_google_android_gms_internal_zzbpc);
            }
            com_google_android_gms_internal_zzbpc.zzbe(true);
            com_google_android_gms_internal_zzbpc.zza((zzbpd) this);
        }
    }

    public void zzk(zzbpc com_google_android_gms_internal_zzbpc) {
        synchronized (this.zzcgF) {
            List list = (List) this.zzcgF.get(com_google_android_gms_internal_zzbpc);
            if (!(list == null || list.isEmpty())) {
                if (com_google_android_gms_internal_zzbpc.zzYp().isDefault()) {
                    HashSet hashSet = new HashSet();
                    for (int size = list.size() - 1; size >= 0; size--) {
                        zzbpc com_google_android_gms_internal_zzbpc2 = (zzbpc) list.get(size);
                        if (!hashSet.contains(com_google_android_gms_internal_zzbpc2.zzYp())) {
                            hashSet.add(com_google_android_gms_internal_zzbpc2.zzYp());
                            com_google_android_gms_internal_zzbpc2.zzYM();
                        }
                    }
                } else {
                    ((zzbpc) list.get(0)).zzYM();
                }
            }
        }
    }
}
