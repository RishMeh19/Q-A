package com.google.android.gms.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public final class zzbwa {
    private final Map<Type, zzbvc<?>> zzcri;

    class C05522 implements zzbwf<T> {
        final /* synthetic */ zzbwa zzcrK;

        C05522(zzbwa com_google_android_gms_internal_zzbwa) {
            this.zzcrK = com_google_android_gms_internal_zzbwa;
        }

        public T zzaeg() {
            return new LinkedHashMap();
        }
    }

    class C05533 implements zzbwf<T> {
        final /* synthetic */ zzbwa zzcrK;

        C05533(zzbwa com_google_android_gms_internal_zzbwa) {
            this.zzcrK = com_google_android_gms_internal_zzbwa;
        }

        public T zzaeg() {
            return new zzbwe();
        }
    }

    class C05577 implements zzbwf<T> {
        final /* synthetic */ zzbwa zzcrK;

        C05577(zzbwa com_google_android_gms_internal_zzbwa) {
            this.zzcrK = com_google_android_gms_internal_zzbwa;
        }

        public T zzaeg() {
            return new TreeSet();
        }
    }

    class C05599 implements zzbwf<T> {
        final /* synthetic */ zzbwa zzcrK;

        C05599(zzbwa com_google_android_gms_internal_zzbwa) {
            this.zzcrK = com_google_android_gms_internal_zzbwa;
        }

        public T zzaeg() {
            return new LinkedHashSet();
        }
    }

    public zzbwa(Map<Type, zzbvc<?>> map) {
        this.zzcri = map;
    }

    private <T> zzbwf<T> zzc(final Type type, Class<? super T> cls) {
        return Collection.class.isAssignableFrom(cls) ? SortedSet.class.isAssignableFrom(cls) ? new C05577(this) : EnumSet.class.isAssignableFrom(cls) ? new zzbwf<T>(this) {
            final /* synthetic */ zzbwa zzcrK;

            public T zzaeg() {
                if (type instanceof ParameterizedType) {
                    Type type = ((ParameterizedType) type).getActualTypeArguments()[0];
                    if (type instanceof Class) {
                        return EnumSet.noneOf((Class) type);
                    }
                    String str = "Invalid EnumSet type: ";
                    String valueOf = String.valueOf(type.toString());
                    throw new zzbvh(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                }
                str = "Invalid EnumSet type: ";
                valueOf = String.valueOf(type.toString());
                throw new zzbvh(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            }
        } : Set.class.isAssignableFrom(cls) ? new C05599(this) : Queue.class.isAssignableFrom(cls) ? new zzbwf<T>(this) {
            final /* synthetic */ zzbwa zzcrK;

            {
                this.zzcrK = r1;
            }

            public T zzaeg() {
                return new LinkedList();
            }
        } : new zzbwf<T>(this) {
            final /* synthetic */ zzbwa zzcrK;

            {
                this.zzcrK = r1;
            }

            public T zzaeg() {
                return new ArrayList();
            }
        } : Map.class.isAssignableFrom(cls) ? SortedMap.class.isAssignableFrom(cls) ? new zzbwf<T>(this) {
            final /* synthetic */ zzbwa zzcrK;

            {
                this.zzcrK = r1;
            }

            public T zzaeg() {
                return new TreeMap();
            }
        } : (!(type instanceof ParameterizedType) || String.class.isAssignableFrom(zzbww.zzl(((ParameterizedType) type).getActualTypeArguments()[0]).zzaey())) ? new C05533(this) : new C05522(this) : null;
    }

    private <T> zzbwf<T> zzd(final Type type, final Class<? super T> cls) {
        return new zzbwf<T>(this) {
            final /* synthetic */ zzbwa zzcrK;
            private final zzbwi zzcrL = zzbwi.zzael();

            public T zzaeg() {
                try {
                    return this.zzcrL.zze(cls);
                } catch (Throwable e) {
                    String valueOf = String.valueOf(type);
                    throw new RuntimeException(new StringBuilder(String.valueOf(valueOf).length() + 116).append("Unable to invoke no-args constructor for ").append(valueOf).append(". ").append("Register an InstanceCreator with Gson for this type may fix this problem.").toString(), e);
                }
            }
        };
    }

    private <T> zzbwf<T> zzk(Class<? super T> cls) {
        try {
            final Constructor declaredConstructor = cls.getDeclaredConstructor(new Class[0]);
            if (!declaredConstructor.isAccessible()) {
                declaredConstructor.setAccessible(true);
            }
            return new zzbwf<T>(this) {
                final /* synthetic */ zzbwa zzcrK;

                public T zzaeg() {
                    String valueOf;
                    try {
                        return declaredConstructor.newInstance(null);
                    } catch (Throwable e) {
                        valueOf = String.valueOf(declaredConstructor);
                        throw new RuntimeException(new StringBuilder(String.valueOf(valueOf).length() + 30).append("Failed to invoke ").append(valueOf).append(" with no args").toString(), e);
                    } catch (InvocationTargetException e2) {
                        valueOf = String.valueOf(declaredConstructor);
                        throw new RuntimeException(new StringBuilder(String.valueOf(valueOf).length() + 30).append("Failed to invoke ").append(valueOf).append(" with no args").toString(), e2.getTargetException());
                    } catch (IllegalAccessException e3) {
                        throw new AssertionError(e3);
                    }
                }
            };
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    public String toString() {
        return this.zzcri.toString();
    }

    public <T> zzbwf<T> zzb(zzbww<T> com_google_android_gms_internal_zzbww_T) {
        final Type zzaez = com_google_android_gms_internal_zzbww_T.zzaez();
        Class zzaey = com_google_android_gms_internal_zzbww_T.zzaey();
        final zzbvc com_google_android_gms_internal_zzbvc = (zzbvc) this.zzcri.get(zzaez);
        if (com_google_android_gms_internal_zzbvc != null) {
            return new zzbwf<T>(this) {
                final /* synthetic */ zzbwa zzcrK;

                public T zzaeg() {
                    return com_google_android_gms_internal_zzbvc.zza(zzaez);
                }
            };
        }
        com_google_android_gms_internal_zzbvc = (zzbvc) this.zzcri.get(zzaey);
        if (com_google_android_gms_internal_zzbvc != null) {
            return new zzbwf<T>(this) {
                final /* synthetic */ zzbwa zzcrK;

                public T zzaeg() {
                    return com_google_android_gms_internal_zzbvc.zza(zzaez);
                }
            };
        }
        zzbwf<T> zzk = zzk(zzaey);
        if (zzk != null) {
            return zzk;
        }
        zzk = zzc(zzaez, zzaey);
        return zzk == null ? zzd(zzaez, zzaey) : zzk;
    }
}
