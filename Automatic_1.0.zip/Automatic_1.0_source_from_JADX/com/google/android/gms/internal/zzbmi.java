package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzbmi implements Creator<zzbmh> {
    static void zza(zzbmh com_google_android_gms_internal_zzbmh, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_internal_zzbmh.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_internal_zzbmh.zzVY(), false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zzbmh.isRegistered());
        zzc.zza(parcel, 4, com_google_android_gms_internal_zzbmh.getProviderId(), false);
        zzc.zza(parcel, 5, com_google_android_gms_internal_zzbmh.zzVZ());
        zzc.zza(parcel, 6, com_google_android_gms_internal_zzbmh.zzWa(), i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlE(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzql(i);
    }

    public zzbmh zzlE(Parcel parcel) {
        zzbmv com_google_android_gms_internal_zzbmv = null;
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        String str = null;
        boolean z2 = false;
        String str2 = null;
        int i = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    z2 = zzb.zzc(parcel, zzaX);
                    break;
                case 4:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 6:
                    com_google_android_gms_internal_zzbmv = (zzbmv) zzb.zza(parcel, zzaX, zzbmv.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbmh(i, str2, z2, str, z, com_google_android_gms_internal_zzbmv);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbmh[] zzql(int i) {
        return new zzbmh[i];
    }
}
