package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.firebase.auth.ActionCodeResult;

public class zzbnb implements ActionCodeResult {
    private final String zzaka;
    private final String zzbYT;
    private final int zzbkO;

    public zzbnb(@NonNull zzbmt com_google_android_gms_internal_zzbmt) {
        if (TextUtils.isEmpty(com_google_android_gms_internal_zzbmt.zzWk())) {
            this.zzaka = com_google_android_gms_internal_zzbmt.getEmail();
        } else {
            this.zzaka = com_google_android_gms_internal_zzbmt.zzWk();
        }
        this.zzbYT = com_google_android_gms_internal_zzbmt.getEmail();
        if (TextUtils.isEmpty(com_google_android_gms_internal_zzbmt.zzWl())) {
            this.zzbkO = 3;
        } else if (com_google_android_gms_internal_zzbmt.zzWl().equals("PASSWORD_RESET")) {
            this.zzbkO = 0;
        } else if (com_google_android_gms_internal_zzbmt.zzWl().equals("VERIFY_EMAIL")) {
            this.zzbkO = 1;
        } else if (com_google_android_gms_internal_zzbmt.zzWl().equals("RECOVER_EMAIL")) {
            this.zzbkO = 2;
        } else {
            this.zzbkO = 3;
        }
    }

    @Nullable
    public String getData(int i) {
        switch (i) {
            case 0:
                return this.zzaka;
            case 1:
                return this.zzbYT;
            default:
                return null;
        }
    }

    public int getOperation() {
        return this.zzbkO;
    }
}
