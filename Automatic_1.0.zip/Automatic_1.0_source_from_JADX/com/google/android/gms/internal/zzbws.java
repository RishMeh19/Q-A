package com.google.android.gms.internal;

import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class zzbws extends zzbvs<Date> {
    public static final zzbvt zzcsz = new C05711();
    private final DateFormat zzcsZ = new SimpleDateFormat("MMM d, yyyy");

    static class C05711 implements zzbvt {
        C05711() {
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            return com_google_android_gms_internal_zzbww_T.zzaey() == Date.class ? new zzbws() : null;
        }
    }

    public synchronized void zza(zzbwz com_google_android_gms_internal_zzbwz, Date date) throws IOException {
        com_google_android_gms_internal_zzbwz.zzkp(date == null ? null : this.zzcsZ.format(date));
    }

    public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return zzm(com_google_android_gms_internal_zzbwx);
    }

    public synchronized Date zzm(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        Date date;
        if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
            com_google_android_gms_internal_zzbwx.nextNull();
            date = null;
        } else {
            try {
                date = new Date(this.zzcsZ.parse(com_google_android_gms_internal_zzbwx.nextString()).getTime());
            } catch (Throwable e) {
                throw new zzbvp(e);
            }
        }
        return date;
    }
}
