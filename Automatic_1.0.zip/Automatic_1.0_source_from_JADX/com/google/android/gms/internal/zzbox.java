package com.google.android.gms.internal;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.zza;

public class zzbox extends zzbpc {
    private final zzbpj zzcab;
    private final ChildEventListener zzcdG;
    private final zzbrc zzcdH;

    public zzbox(zzbpj com_google_android_gms_internal_zzbpj, ChildEventListener childEventListener, zzbrc com_google_android_gms_internal_zzbrc) {
        this.zzcab = com_google_android_gms_internal_zzbpj;
        this.zzcdG = childEventListener;
        this.zzcdH = com_google_android_gms_internal_zzbrc;
    }

    public boolean equals(Object obj) {
        return (obj instanceof zzbox) && ((zzbox) obj).zzcdG.equals(this.zzcdG) && ((zzbox) obj).zzcab.equals(this.zzcab) && ((zzbox) obj).zzcdH.equals(this.zzcdH);
    }

    public int hashCode() {
        return (((this.zzcdG.hashCode() * 31) + this.zzcab.hashCode()) * 31) + this.zzcdH.hashCode();
    }

    public String toString() {
        return "ChildEventRegistration";
    }

    public zzbrc zzYp() {
        return this.zzcdH;
    }

    public zzbpc zza(zzbrc com_google_android_gms_internal_zzbrc) {
        return new zzbox(this.zzcab, this.zzcdG, com_google_android_gms_internal_zzbrc);
    }

    public zzbqx zza(zzbqw com_google_android_gms_internal_zzbqw, zzbrc com_google_android_gms_internal_zzbrc) {
        return new zzbqx(com_google_android_gms_internal_zzbqw.zzZX(), this, zza.zza(zza.zza(this.zzcab, com_google_android_gms_internal_zzbrc.zzWO().zza(com_google_android_gms_internal_zzbqw.zzZW())), com_google_android_gms_internal_zzbqw.zzZU()), com_google_android_gms_internal_zzbqw.zzZY() != null ? com_google_android_gms_internal_zzbqw.zzZY().asString() : null);
    }

    public void zza(zzbqx com_google_android_gms_internal_zzbqx) {
        if (!zzYN()) {
            switch (com_google_android_gms_internal_zzbqx.zzZX()) {
                case CHILD_ADDED:
                    this.zzcdG.onChildAdded(com_google_android_gms_internal_zzbqx.zzaaa(), com_google_android_gms_internal_zzbqx.zzaab());
                    return;
                case CHILD_CHANGED:
                    this.zzcdG.onChildChanged(com_google_android_gms_internal_zzbqx.zzaaa(), com_google_android_gms_internal_zzbqx.zzaab());
                    return;
                case CHILD_MOVED:
                    this.zzcdG.onChildMoved(com_google_android_gms_internal_zzbqx.zzaaa(), com_google_android_gms_internal_zzbqx.zzaab());
                    return;
                case CHILD_REMOVED:
                    this.zzcdG.onChildRemoved(com_google_android_gms_internal_zzbqx.zzaaa());
                    return;
                default:
                    return;
            }
        }
    }

    public void zza(DatabaseError databaseError) {
        this.zzcdG.onCancelled(databaseError);
    }

    public boolean zza(zzbqy.zza com_google_android_gms_internal_zzbqy_zza) {
        return com_google_android_gms_internal_zzbqy_zza != zzbqy.zza.VALUE;
    }

    public boolean zzc(zzbpc com_google_android_gms_internal_zzbpc) {
        return (com_google_android_gms_internal_zzbpc instanceof zzbox) && ((zzbox) com_google_android_gms_internal_zzbpc).zzcdG.equals(this.zzcdG);
    }
}
