package com.example.automatic;

import android.app.Activity;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoViewActivity extends Activity {
    String VideoURL = "";
    ProgressDialog pDialog;
    VideoView videoview;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.VideoURL = getIntent().getExtras().getString("FILE_PATH");
        setContentView(C0174R.layout.videoview_main);
        this.videoview = (VideoView) findViewById(C0174R.id.VideoView);
        try {
            MediaController mediacontroller = new MediaController(this);
            mediacontroller.setAnchorView(this.videoview);
            Uri video = Uri.parse(this.VideoURL);
            this.videoview.setMediaController(mediacontroller);
            this.videoview.setVideoURI(video);
            this.videoview.start();
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }
    }
}
