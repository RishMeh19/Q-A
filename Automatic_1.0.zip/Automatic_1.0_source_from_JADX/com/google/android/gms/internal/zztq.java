package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zztq implements Creator<zztp> {
    static void zza(zztp com_google_android_gms_internal_zztp, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_internal_zztp.zzahb, i, false);
        zzc.zza(parcel, 2, com_google_android_gms_internal_zztp.zzahc, false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zztp.zzahd);
        zzc.zza(parcel, 4, com_google_android_gms_internal_zztp.account, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzy(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzaJ(i);
    }

    public zztp[] zzaJ(int i) {
        return new zztp[i];
    }

    public zztp zzy(Parcel parcel) {
        Account account = null;
        int zzaY = zzb.zzaY(parcel);
        boolean z = false;
        String str = null;
        zztt[] com_google_android_gms_internal_zzttArr = null;
        while (parcel.dataPosition() < zzaY) {
            boolean z2;
            String str2;
            zztt[] com_google_android_gms_internal_zzttArr2;
            Account account2;
            int zzaX = zzb.zzaX(parcel);
            Account account3;
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    account3 = account;
                    z2 = z;
                    str2 = str;
                    com_google_android_gms_internal_zzttArr2 = (zztt[]) zzb.zzb(parcel, zzaX, zztt.CREATOR);
                    account2 = account3;
                    break;
                case 2:
                    com_google_android_gms_internal_zzttArr2 = com_google_android_gms_internal_zzttArr;
                    boolean z3 = z;
                    str2 = zzb.zzq(parcel, zzaX);
                    account2 = account;
                    z2 = z3;
                    break;
                case 3:
                    str2 = str;
                    com_google_android_gms_internal_zzttArr2 = com_google_android_gms_internal_zzttArr;
                    account3 = account;
                    z2 = zzb.zzc(parcel, zzaX);
                    account2 = account3;
                    break;
                case 4:
                    account2 = (Account) zzb.zza(parcel, zzaX, Account.CREATOR);
                    z2 = z;
                    str2 = str;
                    com_google_android_gms_internal_zzttArr2 = com_google_android_gms_internal_zzttArr;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    account2 = account;
                    z2 = z;
                    str2 = str;
                    com_google_android_gms_internal_zzttArr2 = com_google_android_gms_internal_zzttArr;
                    break;
            }
            com_google_android_gms_internal_zzttArr = com_google_android_gms_internal_zzttArr2;
            str = str2;
            z = z2;
            account = account2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zztp(com_google_android_gms_internal_zzttArr, str, z, account);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }
}
