package com.example.automatic;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.example.automatic.permission.C2D_MESSAGE";
    }
}
