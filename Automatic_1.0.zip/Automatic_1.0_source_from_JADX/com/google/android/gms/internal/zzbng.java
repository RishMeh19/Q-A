package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.auth.ProviderQueryResult;
import java.util.List;

public class zzbng implements ProviderQueryResult {
    private List<String> zzbZa;

    public zzbng(@NonNull zzbmh com_google_android_gms_internal_zzbmh) {
        zzac.zzw(com_google_android_gms_internal_zzbmh);
        this.zzbZa = com_google_android_gms_internal_zzbmh.getAllProviders();
    }

    @Nullable
    public List<String> getProviders() {
        return this.zzbZa;
    }
}
