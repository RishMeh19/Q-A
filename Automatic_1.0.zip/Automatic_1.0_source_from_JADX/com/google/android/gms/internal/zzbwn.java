package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public final class zzbwn extends zzbwx {
    private static final Reader zzcsE = new C03171();
    private static final Object zzcsF = new Object();
    private final List<Object> zzcsG = new ArrayList();

    static class C03171 extends Reader {
        C03171() {
        }

        public void close() throws IOException {
            throw new AssertionError();
        }

        public int read(char[] cArr, int i, int i2) throws IOException {
            throw new AssertionError();
        }
    }

    public zzbwn(zzbvg com_google_android_gms_internal_zzbvg) {
        super(zzcsE);
        this.zzcsG.add(com_google_android_gms_internal_zzbvg);
    }

    private void zza(zzbwy com_google_android_gms_internal_zzbwy) throws IOException {
        if (zzaen() != com_google_android_gms_internal_zzbwy) {
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbwy);
            String valueOf2 = String.valueOf(zzaen());
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
        }
    }

    private Object zzaeo() {
        return this.zzcsG.get(this.zzcsG.size() - 1);
    }

    private Object zzaep() {
        return this.zzcsG.remove(this.zzcsG.size() - 1);
    }

    public void beginArray() throws IOException {
        zza(zzbwy.BEGIN_ARRAY);
        this.zzcsG.add(((zzbvd) zzaeo()).iterator());
    }

    public void beginObject() throws IOException {
        zza(zzbwy.BEGIN_OBJECT);
        this.zzcsG.add(((zzbvj) zzaeo()).entrySet().iterator());
    }

    public void close() throws IOException {
        this.zzcsG.clear();
        this.zzcsG.add(zzcsF);
    }

    public void endArray() throws IOException {
        zza(zzbwy.END_ARRAY);
        zzaep();
        zzaep();
    }

    public void endObject() throws IOException {
        zza(zzbwy.END_OBJECT);
        zzaep();
        zzaep();
    }

    public boolean hasNext() throws IOException {
        zzbwy zzaen = zzaen();
        return (zzaen == zzbwy.END_OBJECT || zzaen == zzbwy.END_ARRAY) ? false : true;
    }

    public boolean nextBoolean() throws IOException {
        zza(zzbwy.BOOLEAN);
        return ((zzbvm) zzaep()).getAsBoolean();
    }

    public double nextDouble() throws IOException {
        zzbwy zzaen = zzaen();
        if (zzaen == zzbwy.NUMBER || zzaen == zzbwy.STRING) {
            double asDouble = ((zzbvm) zzaeo()).getAsDouble();
            if (isLenient() || !(Double.isNaN(asDouble) || Double.isInfinite(asDouble))) {
                zzaep();
                return asDouble;
            }
            throw new NumberFormatException("JSON forbids NaN and infinities: " + asDouble);
        }
        String valueOf = String.valueOf(zzbwy.NUMBER);
        String valueOf2 = String.valueOf(zzaen);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    public int nextInt() throws IOException {
        zzbwy zzaen = zzaen();
        if (zzaen == zzbwy.NUMBER || zzaen == zzbwy.STRING) {
            int asInt = ((zzbvm) zzaeo()).getAsInt();
            zzaep();
            return asInt;
        }
        String valueOf = String.valueOf(zzbwy.NUMBER);
        String valueOf2 = String.valueOf(zzaen);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    public long nextLong() throws IOException {
        zzbwy zzaen = zzaen();
        if (zzaen == zzbwy.NUMBER || zzaen == zzbwy.STRING) {
            long asLong = ((zzbvm) zzaeo()).getAsLong();
            zzaep();
            return asLong;
        }
        String valueOf = String.valueOf(zzbwy.NUMBER);
        String valueOf2 = String.valueOf(zzaen);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    public String nextName() throws IOException {
        zza(zzbwy.NAME);
        Entry entry = (Entry) ((Iterator) zzaeo()).next();
        this.zzcsG.add(entry.getValue());
        return (String) entry.getKey();
    }

    public void nextNull() throws IOException {
        zza(zzbwy.NULL);
        zzaep();
    }

    public String nextString() throws IOException {
        zzbwy zzaen = zzaen();
        if (zzaen == zzbwy.STRING || zzaen == zzbwy.NUMBER) {
            return ((zzbvm) zzaep()).zzadR();
        }
        String valueOf = String.valueOf(zzbwy.STRING);
        String valueOf2 = String.valueOf(zzaen);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    public void skipValue() throws IOException {
        if (zzaen() == zzbwy.NAME) {
            nextName();
        } else {
            zzaep();
        }
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public zzbwy zzaen() throws IOException {
        if (this.zzcsG.isEmpty()) {
            return zzbwy.END_DOCUMENT;
        }
        Object zzaeo = zzaeo();
        if (zzaeo instanceof Iterator) {
            boolean z = this.zzcsG.get(this.zzcsG.size() - 2) instanceof zzbvj;
            Iterator it = (Iterator) zzaeo;
            if (!it.hasNext()) {
                return z ? zzbwy.END_OBJECT : zzbwy.END_ARRAY;
            } else {
                if (z) {
                    return zzbwy.NAME;
                }
                this.zzcsG.add(it.next());
                return zzaen();
            }
        } else if (zzaeo instanceof zzbvj) {
            return zzbwy.BEGIN_OBJECT;
        } else {
            if (zzaeo instanceof zzbvd) {
                return zzbwy.BEGIN_ARRAY;
            }
            if (zzaeo instanceof zzbvm) {
                zzbvm com_google_android_gms_internal_zzbvm = (zzbvm) zzaeo;
                if (com_google_android_gms_internal_zzbvm.zzaec()) {
                    return zzbwy.STRING;
                }
                if (com_google_android_gms_internal_zzbvm.zzaea()) {
                    return zzbwy.BOOLEAN;
                }
                if (com_google_android_gms_internal_zzbvm.zzaeb()) {
                    return zzbwy.NUMBER;
                }
                throw new AssertionError();
            } else if (zzaeo instanceof zzbvi) {
                return zzbwy.NULL;
            } else {
                if (zzaeo == zzcsF) {
                    throw new IllegalStateException("JsonReader is closed");
                }
                throw new AssertionError();
            }
        }
    }

    public void zzaeq() throws IOException {
        zza(zzbwy.NAME);
        Entry entry = (Entry) ((Iterator) zzaeo()).next();
        this.zzcsG.add(entry.getValue());
        this.zzcsG.add(new zzbvm((String) entry.getKey()));
    }
}
