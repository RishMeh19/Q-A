package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbwr.zza;
import java.io.IOException;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

final class zzbwu<T> extends zzbvs<T> {
    private final zzbvs<T> zzcre;
    private final zzbva zzcta;
    private final Type zzctb;

    zzbwu(zzbva com_google_android_gms_internal_zzbva, zzbvs<T> com_google_android_gms_internal_zzbvs_T, Type type) {
        this.zzcta = com_google_android_gms_internal_zzbva;
        this.zzcre = com_google_android_gms_internal_zzbvs_T;
        this.zzctb = type;
    }

    private Type zzb(Type type, Object obj) {
        return obj != null ? (type == Object.class || (type instanceof TypeVariable) || (type instanceof Class)) ? obj.getClass() : type : type;
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException {
        zzbvs com_google_android_gms_internal_zzbvs = this.zzcre;
        Type zzb = zzb(this.zzctb, t);
        if (zzb != this.zzctb) {
            com_google_android_gms_internal_zzbvs = this.zzcta.zza(zzbww.zzl(zzb));
            if ((com_google_android_gms_internal_zzbvs instanceof zza) && !(this.zzcre instanceof zza)) {
                com_google_android_gms_internal_zzbvs = this.zzcre;
            }
        }
        com_google_android_gms_internal_zzbvs.zza(com_google_android_gms_internal_zzbwz, t);
    }

    public T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return this.zzcre.zzb(com_google_android_gms_internal_zzbwx);
    }
}
