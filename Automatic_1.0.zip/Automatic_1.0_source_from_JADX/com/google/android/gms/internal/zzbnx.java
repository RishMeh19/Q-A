package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbny.zza.zza;
import com.google.android.gms.internal.zzbod.zzb;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbnx<K, V> extends zzbny<K, V> {
    private final K[] zzcaO;
    private final V[] zzcaP;
    private final Comparator<K> zzcaQ;

    public zzbnx(Comparator<K> comparator) {
        this.zzcaO = new Object[0];
        this.zzcaP = new Object[0];
        this.zzcaQ = comparator;
    }

    private zzbnx(Comparator<K> comparator, K[] kArr, V[] vArr) {
        this.zzcaO = kArr;
        this.zzcaP = vArr;
        this.zzcaQ = comparator;
    }

    public static <A, B, C> zzbnx<A, C> zza(List<A> list, Map<B, C> map, zza<A, B> com_google_android_gms_internal_zzbny_zza_zza_A__B, Comparator<A> comparator) {
        Collections.sort(list, comparator);
        int size = list.size();
        Object[] objArr = new Object[size];
        Object[] objArr2 = new Object[size];
        size = 0;
        for (Object next : list) {
            objArr[size] = next;
            objArr2[size] = map.get(com_google_android_gms_internal_zzbny_zza_zza_A__B.zzal(next));
            size++;
        }
        return new zzbnx(comparator, objArr, objArr2);
    }

    public static <K, V> zzbnx<K, V> zza(Map<K, V> map, Comparator<K> comparator) {
        return zza(new ArrayList(map.keySet()), map, zzbny.zza.zzWY(), comparator);
    }

    private static <T> T[] zza(T[] tArr, int i) {
        int length = tArr.length - 1;
        Object obj = new Object[length];
        System.arraycopy(tArr, 0, obj, 0, i);
        System.arraycopy(tArr, i + 1, obj, i, length - i);
        return obj;
    }

    private static <T> T[] zza(T[] tArr, int i, T t) {
        int length = tArr.length + 1;
        Object obj = new Object[length];
        System.arraycopy(tArr, 0, obj, 0, i);
        obj[i] = t;
        System.arraycopy(tArr, i, obj, i + 1, (length - i) - 1);
        return obj;
    }

    private int zzaj(K k) {
        int i = 0;
        while (i < this.zzcaO.length && this.zzcaQ.compare(this.zzcaO[i], k) < 0) {
            i++;
        }
        return i;
    }

    private int zzak(K k) {
        int i = 0;
        Object[] objArr = this.zzcaO;
        int length = objArr.length;
        int i2 = 0;
        while (i2 < length) {
            if (this.zzcaQ.compare(k, objArr[i2]) == 0) {
                return i;
            }
            i2++;
            i++;
        }
        return -1;
    }

    private static <T> T[] zzb(T[] tArr, int i, T t) {
        int length = tArr.length;
        Object obj = new Object[length];
        System.arraycopy(tArr, 0, obj, 0, length);
        obj[i] = t;
        return obj;
    }

    private Iterator<Entry<K, V>> zze(final int i, final boolean z) {
        return new Iterator<Entry<K, V>>(this) {
            int zzcaR = i;
            final /* synthetic */ zzbnx zzcaU;

            public boolean hasNext() {
                return z ? this.zzcaR >= 0 : this.zzcaR < this.zzcaU.zzcaO.length;
            }

            public Entry<K, V> next() {
                Object obj = this.zzcaU.zzcaO[this.zzcaR];
                Object obj2 = this.zzcaU.zzcaP[this.zzcaR];
                this.zzcaR = z ? this.zzcaR - 1 : this.zzcaR + 1;
                return new SimpleImmutableEntry(obj, obj2);
            }

            public void remove() {
                throw new UnsupportedOperationException("Can't remove elements from ImmutableSortedMap");
            }
        };
    }

    public boolean containsKey(K k) {
        return zzak(k) != -1;
    }

    public V get(K k) {
        int zzak = zzak(k);
        return zzak != -1 ? this.zzcaP[zzak] : null;
    }

    public Comparator<K> getComparator() {
        return this.zzcaQ;
    }

    public boolean isEmpty() {
        return this.zzcaO.length == 0;
    }

    public Iterator<Entry<K, V>> iterator() {
        return zze(0, false);
    }

    public int size() {
        return this.zzcaO.length;
    }

    public K zzWV() {
        return this.zzcaO.length > 0 ? this.zzcaO[0] : null;
    }

    public K zzWW() {
        return this.zzcaO.length > 0 ? this.zzcaO[this.zzcaO.length - 1] : null;
    }

    public Iterator<Entry<K, V>> zzWX() {
        return zze(this.zzcaO.length - 1, true);
    }

    public void zza(zzb<K, V> com_google_android_gms_internal_zzbod_zzb_K__V) {
        for (int i = 0; i < this.zzcaO.length; i++) {
            com_google_android_gms_internal_zzbod_zzb_K__V.zzj(this.zzcaO[i], this.zzcaP[i]);
        }
    }

    public zzbny<K, V> zzah(K k) {
        int zzak = zzak(k);
        if (zzak == -1) {
            return this;
        }
        return new zzbnx(this.zzcaQ, zza(this.zzcaO, zzak), zza(this.zzcaP, zzak));
    }

    public K zzai(K k) {
        int zzak = zzak(k);
        if (zzak != -1) {
            return zzak > 0 ? this.zzcaO[zzak - 1] : null;
        } else {
            throw new IllegalArgumentException("Can't find predecessor of nonexistent key");
        }
    }

    public zzbny<K, V> zzi(K k, V v) {
        int zzak = zzak(k);
        if (zzak != -1) {
            if (this.zzcaO[zzak] == k && this.zzcaP[zzak] == v) {
                return this;
            }
            return new zzbnx(this.zzcaQ, zzb(this.zzcaO, zzak, k), zzb(this.zzcaP, zzak, v));
        } else if (this.zzcaO.length > 25) {
            Map hashMap = new HashMap(this.zzcaO.length + 1);
            for (zzak = 0; zzak < this.zzcaO.length; zzak++) {
                hashMap.put(this.zzcaO[zzak], this.zzcaP[zzak]);
            }
            hashMap.put(k, v);
            return zzbog.zzc(hashMap, this.zzcaQ);
        } else {
            zzak = zzaj(k);
            return new zzbnx(this.zzcaQ, zza(this.zzcaO, zzak, k), zza(this.zzcaP, zzak, v));
        }
    }
}
