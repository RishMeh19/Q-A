package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzuc implements Creator<zzub> {
    static void zza(zzub com_google_android_gms_internal_zzub, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_internal_zzub.name, false);
        zzc.zza(parcel, 2, com_google_android_gms_internal_zzub.zzahB, false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zzub.zzahC);
        zzc.zzc(parcel, 4, com_google_android_gms_internal_zzub.weight);
        zzc.zza(parcel, 5, com_google_android_gms_internal_zzub.zzahD);
        zzc.zza(parcel, 6, com_google_android_gms_internal_zzub.zzahE, false);
        zzc.zza(parcel, 7, com_google_android_gms_internal_zzub.zzahF, i, false);
        zzc.zza(parcel, 8, com_google_android_gms_internal_zzub.zzahG, false);
        zzc.zza(parcel, 11, com_google_android_gms_internal_zzub.zzahH, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzE(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzaR(i);
    }

    public zzub zzE(Parcel parcel) {
        boolean z = false;
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 1;
        int[] iArr = null;
        zztv[] com_google_android_gms_internal_zztvArr = null;
        String str2 = null;
        boolean z2 = false;
        String str3 = null;
        String str4 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 2:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    z2 = zzb.zzc(parcel, zzaX);
                    break;
                case 4:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 5:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 6:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 7:
                    com_google_android_gms_internal_zztvArr = (zztv[]) zzb.zzb(parcel, zzaX, zztv.CREATOR);
                    break;
                case 8:
                    iArr = zzb.zzw(parcel, zzaX);
                    break;
                case 11:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzub(str4, str3, z2, i, z, str2, com_google_android_gms_internal_zztvArr, iArr, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzub[] zzaR(int i) {
        return new zzub[i];
    }
}
