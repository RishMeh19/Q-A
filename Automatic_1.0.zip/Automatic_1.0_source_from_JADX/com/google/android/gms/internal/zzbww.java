package com.google.android.gms.internal;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class zzbww<T> {
    final Type zzctb;
    final Class<? super T> zzcuf;
    final int zzcug;

    protected zzbww() {
        this.zzctb = zzp(getClass());
        this.zzcuf = zzbvz.zzf(this.zzctb);
        this.zzcug = this.zzctb.hashCode();
    }

    zzbww(Type type) {
        this.zzctb = zzbvz.zze((Type) zzbvy.zzw(type));
        this.zzcuf = zzbvz.zzf(this.zzctb);
        this.zzcug = this.zzctb.hashCode();
    }

    public static zzbww<?> zzl(Type type) {
        return new zzbww(type);
    }

    static Type zzp(Class<?> cls) {
        Type genericSuperclass = cls.getGenericSuperclass();
        if (!(genericSuperclass instanceof Class)) {
            return zzbvz.zze(((ParameterizedType) genericSuperclass).getActualTypeArguments()[0]);
        }
        throw new RuntimeException("Missing type parameter.");
    }

    public static <T> zzbww<T> zzq(Class<T> cls) {
        return new zzbww(cls);
    }

    public final boolean equals(Object obj) {
        return (obj instanceof zzbww) && zzbvz.zza(this.zzctb, ((zzbww) obj).zzctb);
    }

    public final int hashCode() {
        return this.zzcug;
    }

    public final String toString() {
        return zzbvz.zzg(this.zzctb);
    }

    public final Class<? super T> zzaey() {
        return this.zzcuf;
    }

    public final Type zzaez() {
        return this.zzctb;
    }
}
