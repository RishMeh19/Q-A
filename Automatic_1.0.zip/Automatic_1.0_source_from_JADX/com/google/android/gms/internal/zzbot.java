package com.google.android.gms.internal;

import java.io.EOFException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class zzbot {
    private static long zzccJ = 0;
    private final zzbrn zzcaH;
    private final ScheduledExecutorService zzcav;
    private zzb zzccK;
    private boolean zzccL = false;
    private boolean zzccM = false;
    private long zzccN = 0;
    private zzbov zzccO;
    private zza zzccP;
    private ScheduledFuture<?> zzccQ;
    private ScheduledFuture<?> zzccR;
    private final zzbol zzccS;

    class C02711 implements Runnable {
        final /* synthetic */ zzbot zzccT;

        C02711(zzbot com_google_android_gms_internal_zzbot) {
            this.zzccT = com_google_android_gms_internal_zzbot;
        }

        public void run() {
            this.zzccT.zzYe();
        }
    }

    class C02722 implements Runnable {
        final /* synthetic */ zzbot zzccT;

        C02722(zzbot com_google_android_gms_internal_zzbot) {
            this.zzccT = com_google_android_gms_internal_zzbot;
        }

        public void run() {
            if (this.zzccT.zzccK != null) {
                this.zzccT.zzccK.zziS("0");
                this.zzccT.zzYb();
            }
        }
    }

    public interface zza {
        void zzaZ(boolean z);

        void zzat(Map<String, Object> map);
    }

    private interface zzb {
        void close();

        void connect();

        void zziS(String str);
    }

    private class zzc implements zzb, zzbsn {
        final /* synthetic */ zzbot zzccT;
        private zzbsm zzccU;

        class C02731 implements Runnable {
            final /* synthetic */ zzc zzccV;

            C02731(zzc com_google_android_gms_internal_zzbot_zzc) {
                this.zzccV = com_google_android_gms_internal_zzbot_zzc;
            }

            public void run() {
                this.zzccV.zzccT.zzccR.cancel(false);
                this.zzccV.zzccT.zzccL = true;
                if (this.zzccV.zzccT.zzcaH.zzaaF()) {
                    this.zzccV.zzccT.zzcaH.zzi("websocket opened", new Object[0]);
                }
                this.zzccV.zzccT.zzYb();
            }
        }

        class C02753 implements Runnable {
            final /* synthetic */ zzc zzccV;

            C02753(zzc com_google_android_gms_internal_zzbot_zzc) {
                this.zzccV = com_google_android_gms_internal_zzbot_zzc;
            }

            public void run() {
                if (this.zzccV.zzccT.zzcaH.zzaaF()) {
                    this.zzccV.zzccT.zzcaH.zzi("closed", new Object[0]);
                }
                this.zzccV.zzccT.zzYd();
            }
        }

        private zzc(zzbot com_google_android_gms_internal_zzbot, zzbsm com_google_android_gms_internal_zzbsm) {
            this.zzccT = com_google_android_gms_internal_zzbot;
            this.zzccU = com_google_android_gms_internal_zzbsm;
            this.zzccU.zza((zzbsn) this);
        }

        private void shutdown() {
            this.zzccU.close();
            try {
                this.zzccU.zzabx();
            } catch (Throwable e) {
                this.zzccT.zzcaH.zzd("Interrupted while shutting down websocket threads", e);
            }
        }

        public void close() {
            this.zzccU.close();
        }

        public void connect() {
            try {
                this.zzccU.connect();
            } catch (Throwable e) {
                if (this.zzccT.zzcaH.zzaaF()) {
                    this.zzccT.zzcaH.zza("Error connecting", e, new Object[0]);
                }
                shutdown();
            }
        }

        public void onClose() {
            this.zzccT.zzcav.execute(new C02753(this));
        }

        public void zzYf() {
            this.zzccT.zzcav.execute(new C02731(this));
        }

        public void zza(final zzbso com_google_android_gms_internal_zzbso) {
            this.zzccT.zzcav.execute(new Runnable(this) {
                final /* synthetic */ zzc zzccV;

                public void run() {
                    if (com_google_android_gms_internal_zzbso.getCause() == null || !(com_google_android_gms_internal_zzbso.getCause() instanceof EOFException)) {
                        this.zzccV.zzccT.zzcaH.zza("WebSocket error.", com_google_android_gms_internal_zzbso, new Object[0]);
                    } else {
                        this.zzccV.zzccT.zzcaH.zzi("WebSocket reached EOF.", new Object[0]);
                    }
                    this.zzccV.zzccT.zzYd();
                }
            });
        }

        public void zza(zzbsq com_google_android_gms_internal_zzbsq) {
            final String text = com_google_android_gms_internal_zzbsq.getText();
            if (this.zzccT.zzcaH.zzaaF()) {
                zzbrn zzb = this.zzccT.zzcaH;
                String str = "ws message: ";
                String valueOf = String.valueOf(text);
                zzb.zzi(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), new Object[0]);
            }
            this.zzccT.zzcav.execute(new Runnable(this) {
                final /* synthetic */ zzc zzccV;

                public void run() {
                    this.zzccV.zzccT.zziR(text);
                }
            });
        }

        public void zziS(String str) {
            this.zzccU.zziS(str);
        }
    }

    public zzbot(zzbol com_google_android_gms_internal_zzbol, zzbon com_google_android_gms_internal_zzbon, String str, zza com_google_android_gms_internal_zzbot_zza, String str2) {
        this.zzccS = com_google_android_gms_internal_zzbol;
        this.zzcav = com_google_android_gms_internal_zzbol.zzXv();
        this.zzccP = com_google_android_gms_internal_zzbot_zza;
        long j = zzccJ;
        zzccJ = 1 + j;
        this.zzcaH = new zzbrn(com_google_android_gms_internal_zzbol.zzXt(), "WebSocket", "ws_" + j);
        this.zzccK = zza(com_google_android_gms_internal_zzbon, str, str2);
    }

    private boolean isBuffering() {
        return this.zzccO != null;
    }

    private void shutdown() {
        this.zzccM = true;
        this.zzccP.zzaZ(this.zzccL);
    }

    private static String[] zzF(String str, int i) {
        int i2 = 0;
        if (str.length() <= i) {
            return new String[]{str};
        }
        ArrayList arrayList = new ArrayList();
        while (i2 < str.length()) {
            arrayList.add(str.substring(i2, Math.min(i2 + i, str.length())));
            i2 += i;
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    private void zzYb() {
        if (!this.zzccM) {
            if (this.zzccQ != null) {
                this.zzccQ.cancel(false);
                if (this.zzcaH.zzaaF()) {
                    this.zzcaH.zzi("Reset keepAlive. Remaining: " + this.zzccQ.getDelay(TimeUnit.MILLISECONDS), new Object[0]);
                }
            } else if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("Reset keepAlive", new Object[0]);
            }
            this.zzccQ = this.zzcav.schedule(zzYc(), 45000, TimeUnit.MILLISECONDS);
        }
    }

    private Runnable zzYc() {
        return new C02722(this);
    }

    private void zzYd() {
        if (!this.zzccM) {
            if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("closing itself", new Object[0]);
            }
            shutdown();
        }
        this.zzccK = null;
        if (this.zzccQ != null) {
            this.zzccQ.cancel(false);
        }
    }

    private void zzYe() {
        if (!this.zzccL && !this.zzccM) {
            if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("timed out on connect", new Object[0]);
            }
            this.zzccK.close();
        }
    }

    private zzb zza(zzbon com_google_android_gms_internal_zzbon, String str, String str2) {
        if (str == null) {
            str = com_google_android_gms_internal_zzbon.getHost();
        }
        URI zza = zzbon.zza(str, com_google_android_gms_internal_zzbon.isSecure(), com_google_android_gms_internal_zzbon.getNamespace(), str2);
        Map hashMap = new HashMap();
        hashMap.put("User-Agent", this.zzccS.zzkn());
        return new zzc(new zzbsm(zza, null, hashMap));
    }

    private void zziP(String str) {
        Throwable th;
        zzbrn com_google_android_gms_internal_zzbrn;
        String str2;
        String valueOf;
        this.zzccO.zziT(str);
        this.zzccN--;
        if (this.zzccN == 0) {
            try {
                this.zzccO.zzYl();
                Map zzje = zzbsv.zzje(this.zzccO.toString());
                this.zzccO = null;
                if (this.zzcaH.zzaaF()) {
                    zzbrn com_google_android_gms_internal_zzbrn2 = this.zzcaH;
                    String valueOf2 = String.valueOf(zzje);
                    com_google_android_gms_internal_zzbrn2.zzi(new StringBuilder(String.valueOf(valueOf2).length() + 36).append("handleIncomingFrame complete frame: ").append(valueOf2).toString(), new Object[0]);
                }
                this.zzccP.zzat(zzje);
            } catch (Throwable e) {
                th = e;
                com_google_android_gms_internal_zzbrn = this.zzcaH;
                str2 = "Error parsing frame: ";
                valueOf = String.valueOf(this.zzccO.toString());
                com_google_android_gms_internal_zzbrn.zzd(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
                close();
                shutdown();
            } catch (Throwable e2) {
                th = e2;
                com_google_android_gms_internal_zzbrn = this.zzcaH;
                str2 = "Error parsing frame (cast error): ";
                valueOf = String.valueOf(this.zzccO.toString());
                com_google_android_gms_internal_zzbrn.zzd(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
                close();
                shutdown();
            }
        }
    }

    private String zziQ(String str) {
        if (str.length() <= 6) {
            try {
                int parseInt = Integer.parseInt(str);
                if (parseInt > 0) {
                    zzqw(parseInt);
                }
                return null;
            } catch (NumberFormatException e) {
            }
        }
        zzqw(1);
        return str;
    }

    private void zziR(String str) {
        if (!this.zzccM) {
            zzYb();
            if (isBuffering()) {
                zziP(str);
                return;
            }
            String zziQ = zziQ(str);
            if (zziQ != null) {
                zziP(zziQ);
            }
        }
    }

    private void zzqw(int i) {
        this.zzccN = (long) i;
        this.zzccO = new zzbov();
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("HandleNewFrameCount: " + this.zzccN, new Object[0]);
        }
    }

    public void close() {
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("websocket is being closed", new Object[0]);
        }
        this.zzccM = true;
        this.zzccK.close();
        if (this.zzccR != null) {
            this.zzccR.cancel(true);
        }
        if (this.zzccQ != null) {
            this.zzccQ.cancel(true);
        }
    }

    public void open() {
        this.zzccK.connect();
        this.zzccR = this.zzcav.schedule(new C02711(this), 30000, TimeUnit.MILLISECONDS);
    }

    public void send(Map<String, Object> map) {
        String str;
        zzYb();
        try {
            String[] zzF = zzF(zzbsv.zzaF(map), 16384);
            if (zzF.length > 1) {
                this.zzccK.zziS(zzF.length);
            }
            for (String str2 : zzF) {
                this.zzccK.zziS(str2);
            }
        } catch (Throwable e) {
            Throwable th = e;
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            str2 = "Failed to serialize message: ";
            String valueOf = String.valueOf(map.toString());
            com_google_android_gms_internal_zzbrn.zzd(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
            shutdown();
        }
    }
}
