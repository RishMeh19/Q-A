package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class zzbne extends FirebaseAuth {
    public zzbne(@NonNull FirebaseApp firebaseApp) {
        super(firebaseApp);
    }
}
