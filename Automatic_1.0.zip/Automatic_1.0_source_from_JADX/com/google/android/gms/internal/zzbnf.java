package com.google.android.gms.internal;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuthProvider;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class zzbnf extends FirebaseUser {
    private zzbmn zzbYV;
    private zzbnd zzbYW;
    private String zzbYX;
    private String zzbYY = "com.google.firebase.auth.internal.DefaultFirebaseUser";
    private List<zzbnd> zzbYZ;
    private zzbva zzbYh = zzblx.zzVS();
    private List<String> zzbZa;
    private Map<String, zzbnd> zzbZb;
    private String zzbZc = "2";
    private boolean zzbZd;

    public zzbnf(@NonNull FirebaseApp firebaseApp, @NonNull List<? extends UserInfo> list) {
        zzac.zzw(firebaseApp);
        this.zzbYX = firebaseApp.getName();
        zzU(list);
    }

    @Nullable
    public String getDisplayName() {
        return this.zzbYW.getDisplayName();
    }

    @Nullable
    public String getEmail() {
        return this.zzbYW.getEmail();
    }

    @Nullable
    public Uri getPhotoUrl() {
        return this.zzbYW.getPhotoUrl();
    }

    @NonNull
    public List<? extends UserInfo> getProviderData() {
        return this.zzbYZ;
    }

    @NonNull
    public String getProviderId() {
        return this.zzbYW.getProviderId();
    }

    @Nullable
    public List<String> getProviders() {
        return this.zzbZa;
    }

    @NonNull
    public String getUid() {
        return this.zzbYW.getUid();
    }

    public boolean isAnonymous() {
        return this.zzbZd;
    }

    public boolean isEmailVerified() {
        return this.zzbYW.isEmailVerified();
    }

    @NonNull
    public FirebaseUser zzU(@NonNull List<? extends UserInfo> list) {
        zzac.zzw(list);
        this.zzbYZ = new ArrayList(list.size());
        this.zzbZa = new ArrayList(list.size());
        this.zzbZb = new ArrayMap();
        for (int i = 0; i < list.size(); i++) {
            UserInfo userInfo = (UserInfo) list.get(i);
            if (userInfo.getProviderId().equals(FirebaseAuthProvider.PROVIDER_ID)) {
                this.zzbYW = (zzbnd) userInfo;
            } else {
                this.zzbZa.add(userInfo.getProviderId());
            }
            this.zzbYZ.add((zzbnd) userInfo);
            this.zzbZb.put(userInfo.getProviderId(), (zzbnd) userInfo);
        }
        if (this.zzbYW == null) {
            this.zzbYW = (zzbnd) this.zzbYZ.get(0);
        }
        return this;
    }

    @NonNull
    public FirebaseApp zzVH() {
        return FirebaseApp.getInstance(this.zzbYX);
    }

    @NonNull
    public zzbmn zzVI() {
        return this.zzbYV;
    }

    @NonNull
    public String zzVJ() {
        return this.zzbYh.zzaM(this.zzbYV);
    }

    @NonNull
    public String zzVK() {
        return zzVI().getAccessToken();
    }

    public List<zzbnd> zzWs() {
        return this.zzbYZ;
    }

    public void zza(@NonNull zzbmn com_google_android_gms_internal_zzbmn) {
        this.zzbYV = (zzbmn) zzac.zzw(com_google_android_gms_internal_zzbmn);
    }

    public /* synthetic */ FirebaseUser zzaX(boolean z) {
        return zzaY(z);
    }

    public zzbnf zzaY(boolean z) {
        this.zzbZd = z;
        return this;
    }

    public zzbnf zziz(@NonNull String str) {
        this.zzbZc = str;
        return this;
    }
}
