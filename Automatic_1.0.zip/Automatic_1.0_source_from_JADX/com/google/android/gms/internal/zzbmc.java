package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;

interface zzbmc<ResultT> {
    void zza(ResultT resultT, Status status);
}
