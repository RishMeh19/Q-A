package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqy.zza;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class zzbqz {
    private final zzbrc zzchZ;
    private final zzbrw zzcia;

    class C02981 implements Comparator<zzbqw> {
        static final /* synthetic */ boolean $assertionsDisabled = (!zzbqz.class.desiredAssertionStatus());
        final /* synthetic */ zzbqz zzcib;

        C02981(zzbqz com_google_android_gms_internal_zzbqz) {
            this.zzcib = com_google_android_gms_internal_zzbqz;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return zza((zzbqw) obj, (zzbqw) obj2);
        }

        public int zza(zzbqw com_google_android_gms_internal_zzbqw, zzbqw com_google_android_gms_internal_zzbqw2) {
            if ($assertionsDisabled || !(com_google_android_gms_internal_zzbqw.zzZW() == null || com_google_android_gms_internal_zzbqw2.zzZW() == null)) {
                return this.zzcib.zzcia.compare(new zzbsb(com_google_android_gms_internal_zzbqw.zzZW(), com_google_android_gms_internal_zzbqw.zzZU().zzWK()), new zzbsb(com_google_android_gms_internal_zzbqw2.zzZW(), com_google_android_gms_internal_zzbqw2.zzZU().zzWK()));
            }
            throw new AssertionError();
        }
    }

    public zzbqz(zzbrc com_google_android_gms_internal_zzbrc) {
        this.zzchZ = com_google_android_gms_internal_zzbrc;
        this.zzcia = com_google_android_gms_internal_zzbrc.zzaal();
    }

    private zzbqx zza(zzbqw com_google_android_gms_internal_zzbqw, zzbpc com_google_android_gms_internal_zzbpc, zzbrx com_google_android_gms_internal_zzbrx) {
        if (!(com_google_android_gms_internal_zzbqw.zzZX().equals(zza.VALUE) || com_google_android_gms_internal_zzbqw.zzZX().equals(zza.CHILD_REMOVED))) {
            com_google_android_gms_internal_zzbqw = com_google_android_gms_internal_zzbqw.zzg(com_google_android_gms_internal_zzbrx.zza(com_google_android_gms_internal_zzbqw.zzZW(), com_google_android_gms_internal_zzbqw.zzZU().zzWK(), this.zzcia));
        }
        return com_google_android_gms_internal_zzbpc.zza(com_google_android_gms_internal_zzbqw, this.zzchZ);
    }

    private void zza(List<zzbqx> list, zza com_google_android_gms_internal_zzbqy_zza, List<zzbqw> list2, List<zzbpc> list3, zzbrx com_google_android_gms_internal_zzbrx) {
        List<zzbqw> arrayList = new ArrayList();
        for (zzbqw com_google_android_gms_internal_zzbqw : list2) {
            if (com_google_android_gms_internal_zzbqw.zzZX().equals(com_google_android_gms_internal_zzbqy_zza)) {
                arrayList.add(com_google_android_gms_internal_zzbqw);
            }
        }
        Collections.sort(arrayList, zzaac());
        for (zzbqw com_google_android_gms_internal_zzbqw2 : arrayList) {
            for (zzbpc com_google_android_gms_internal_zzbpc : list3) {
                if (com_google_android_gms_internal_zzbpc.zza(com_google_android_gms_internal_zzbqy_zza)) {
                    list.add(zza(com_google_android_gms_internal_zzbqw2, com_google_android_gms_internal_zzbpc, com_google_android_gms_internal_zzbrx));
                }
            }
        }
    }

    private Comparator<zzbqw> zzaac() {
        return new C02981(this);
    }

    public List<zzbqx> zza(List<zzbqw> list, zzbrx com_google_android_gms_internal_zzbrx, List<zzbpc> list2) {
        List<zzbqx> arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        for (zzbqw com_google_android_gms_internal_zzbqw : list) {
            if (com_google_android_gms_internal_zzbqw.zzZX().equals(zza.CHILD_CHANGED) && this.zzcia.zza(com_google_android_gms_internal_zzbqw.zzZZ().zzWK(), com_google_android_gms_internal_zzbqw.zzZU().zzWK())) {
                arrayList2.add(zzbqw.zzc(com_google_android_gms_internal_zzbqw.zzZW(), com_google_android_gms_internal_zzbqw.zzZU()));
            }
        }
        zza(arrayList, zza.CHILD_REMOVED, list, list2, com_google_android_gms_internal_zzbrx);
        zza(arrayList, zza.CHILD_ADDED, list, list2, com_google_android_gms_internal_zzbrx);
        zza(arrayList, zza.CHILD_MOVED, arrayList2, list2, com_google_android_gms_internal_zzbrx);
        zza(arrayList, zza.CHILD_CHANGED, list, list2, com_google_android_gms_internal_zzbrx);
        zza(arrayList, zza.VALUE, list, list2, com_google_android_gms_internal_zzbrx);
        return arrayList;
    }
}
