package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzac;
import java.io.IOException;
import java.util.List;

public class zzbme extends zzbvs<zzbmr> {
    private zzbva zzbYh;

    public void zza(@NonNull zzbva com_google_android_gms_internal_zzbva) {
        this.zzbYh = (zzbva) zzac.zzw(com_google_android_gms_internal_zzbva);
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, zzbmr com_google_android_gms_internal_zzbmr) throws IOException {
        int i = 0;
        if (com_google_android_gms_internal_zzbmr == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
            return;
        }
        zzbvs zzj = this.zzbYh.zzj(zzbmp.class);
        com_google_android_gms_internal_zzbwz.zzaet();
        List zzWb = com_google_android_gms_internal_zzbmr.zzWb();
        int size = zzWb != null ? zzWb.size() : 0;
        while (i < size) {
            zzj.zza(com_google_android_gms_internal_zzbwz, (zzbmp) zzWb.get(i));
            i++;
        }
        com_google_android_gms_internal_zzbwz.zzaeu();
    }

    public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return zzc(com_google_android_gms_internal_zzbwx);
    }

    public zzbmr zzc(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
        zzbmr com_google_android_gms_internal_zzbmr = new zzbmr();
        zzbvs zzj = this.zzbYh.zzj(zzbmp.class);
        com_google_android_gms_internal_zzbwx.beginArray();
        while (com_google_android_gms_internal_zzbwx.hasNext()) {
            com_google_android_gms_internal_zzbmr.zzWb().add((zzbmp) zzj.zzb(com_google_android_gms_internal_zzbwx));
        }
        com_google_android_gms_internal_zzbwx.endArray();
        return com_google_android_gms_internal_zzbmr;
    }
}
