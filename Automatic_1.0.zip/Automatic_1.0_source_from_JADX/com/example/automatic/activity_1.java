package com.example.automatic;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.util.Locale;

public class activity_1 extends Activity implements OnClickListener, OnInitListener {
    private static final int PERMISSIONS_REQUEST_CAMERA = 1;
    private static final int PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;
    private static final int PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    private static final int SELECT_VIDEO = 3;
    private static final int VIDEO_CAPTURE = 101;
    public static Context context;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    AlertDialog alertDialog1;
    String ans;
    private Button button;
    private Button button11;
    private Button button12;
    private Button button13;
    private Button button14;
    private ImageButton button6;
    private ImageButton button7;
    String email;
    int f4f = 1;
    private Uri fileUri;
    String id;
    Intent intent;
    String name;
    String path;
    int f5q = 1;
    private Button recordButton;
    private String selectedPath;
    FileOutputStream stream;
    TextView textView;
    TextView textView2;
    TextView textView3;
    private TextView textView4;
    TextView textView6;
    TextView textView7;
    private TextToSpeech tts;
    private EditText txtSpeechInput;

    class C01751 implements DialogInterface.OnClickListener {
        C01751() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    class C01762 implements DialogInterface.OnClickListener {
        C01762() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        this.name = extras.getString("NAME");
        this.email = extras.getString("EMAIL");
        this.id = extras.getString("ID");
        super.onStart();
        setContentView(C0174R.layout.activity_1);
        AlertDialog alertDialog = new Builder(this).create();
        alertDialog.setTitle("Welcome " + this.name);
        alertDialog.setMessage("\"If you have paused and haven't completed your answer, click on CONTINUE.If you want to rerecord,click on RECORD\")");
        alertDialog.setButton(-3, "OK", new C01751());
        alertDialog.show();
        this.recordButton = (Button) findViewById(C0174R.id.recordButton);
        this.textView = (TextView) findViewById(C0174R.id.textView);
        this.textView6 = (TextView) findViewById(C0174R.id.textView6);
        this.textView7 = (TextView) findViewById(C0174R.id.textView7);
        Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/Monotype.ttf");
        this.textView2 = (TextView) findViewById(C0174R.id.textView2);
        this.textView2.setTypeface(tf);
        this.textView2.setText("Q1..Which algorithm is use to find shortest path between two points in graph?");
        this.textView3 = (TextView) findViewById(C0174R.id.textView3);
        this.textView3.setTypeface(tf);
        this.textView3.setText("Q2..What does Big-Oh notation signifies?");
        this.txtSpeechInput = (EditText) findViewById(C0174R.id.editText);
        this.button = (Button) findViewById(C0174R.id.button);
        this.button11 = (Button) findViewById(C0174R.id.button11);
        this.button12 = (Button) findViewById(C0174R.id.button12);
        this.button13 = (Button) findViewById(C0174R.id.button13);
        this.button14 = (Button) findViewById(C0174R.id.button14);
        this.tts = new TextToSpeech(getApplicationContext(), this);
        this.button6 = (ImageButton) findViewById(C0174R.id.imageButton6);
        this.button7 = (ImageButton) findViewById(C0174R.id.imageButton7);
        this.recordButton.setOnClickListener(this);
        this.button.setOnClickListener(this);
        this.button6.setOnClickListener(this);
        this.button11.setOnClickListener(this);
        this.button12.setOnClickListener(this);
        this.button13.setOnClickListener(this);
        this.button7.setOnClickListener(this);
        this.button14.setOnClickListener(this);
    }

    private void promptSpeechInput() {
        this.alertDialog1 = new Builder(this).create();
        this.alertDialog1.setTitle("Welcome " + this.name);
        this.alertDialog1.setMessage("\"If you have paused and haven't completed your answer, click on CONTINUE.If you want to rerecord,click on RECORD\")");
        this.alertDialog1.setButton(-3, "OK", new C01762());
        this.intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        this.intent.putExtra("android.speech.extra.LANGUAGE", Locale.getDefault());
        this.intent.putExtra("android.speech.extra.PROMPT", "Speak");
        this.intent.putExtra("android.speech.extras.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", "600000");
        if (this.f4f == 1) {
            try {
                startActivityForResult(this.intent, 100);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(getApplicationContext(), getString(C0174R.string.speech_not_supported), 0).show();
            }
        }
        if (this.f5q == 1) {
            new CountDownTimer(30000, 1000) {
                public void onTick(long millisUntilFinished) {
                    activity_1.this.textView7.setText("Seconds Remaining: " + (millisUntilFinished / 1000));
                }

                public void onFinish() {
                    activity_1.this.textView7.setText("done!");
                    activity_1.this.finishActivity(100);
                    activity_1.this.alertDialog1.show();
                    activity_1.this.f4f = 0;
                }
            }.start();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 100:
                if (resultCode == -1 && data != null) {
                    this.txtSpeechInput.append(" " + ((String) data.getStringArrayListExtra("android.speech.extra.RESULTS").get(0)));
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void next() {
        this.path = this.txtSpeechInput.getText().toString();
        Intent myIntent2 = new Intent(this, activity_2.class);
        Bundle extras = new Bundle();
        extras.putString("NAME", this.name);
        extras.putString("EMAIL", this.email);
        extras.putString("ANSWER", this.ans);
        extras.putString("ID", this.id);
        extras.putString("FILE_PATH", this.path);
        myIntent2.putExtras(extras);
        startActivity(myIntent2);
    }

    public void speakit(int i) {
        String text;
        if (i == 1) {
            text = this.textView2.getText().toString();
            this.tts.setLanguage(Locale.US);
            this.tts.speak(text, 0, null);
        } else if (i == 2) {
            text = this.textView3.getText().toString();
            this.tts.setLanguage(Locale.US);
            this.tts.speak(text, 0, null);
        }
    }

    public void onClick(View v) {
        if (v == this.recordButton) {
            this.ans = "Answer 1";
            this.txtSpeechInput.setText("");
            promptSpeechInput();
        }
        if (v == this.button) {
            this.ans = "Answer 2";
            this.txtSpeechInput.setText("");
            promptSpeechInput();
        }
        if (v == this.button6) {
            speakit(1);
        }
        if (v == this.button7) {
            speakit(2);
        }
        if (v == this.button11) {
            this.f5q = 0;
            promptSpeechInput();
        }
        if (v == this.button12) {
            this.f5q = 0;
            promptSpeechInput();
        }
        if (v == this.button13) {
            next();
        }
        if (v == this.button14) {
            next();
        }
    }

    public void onDestroy() {
        if (this.tts != null) {
            this.tts.stop();
            this.tts.shutdown();
        }
        super.onDestroy();
    }

    public void onInit(int status) {
        if (status == 0) {
            this.tts.setLanguage(Locale.US);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != 1) {
            return;
        }
        if (grantResults.length <= 0 || grantResults[0] != 0) {
            this.recordButton.setEnabled(false);
            this.button.setEnabled(false);
        }
    }
}
