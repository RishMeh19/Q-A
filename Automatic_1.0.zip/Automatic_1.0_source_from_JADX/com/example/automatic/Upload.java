package com.example.automatic;

import android.net.Uri;
import android.support.annotation.NonNull;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.UploadTask.TaskSnapshot;
import java.io.File;

public class Upload {
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    int f3i;

    class C04351 implements OnProgressListener<TaskSnapshot> {
        C04351() {
        }

        public void onProgress(TaskSnapshot taskSnapshot) {
        }
    }

    class C04362 implements OnFailureListener {
        C04362() {
        }

        public void onFailure(@NonNull Exception exception) {
            Upload.this.f3i = 2;
        }
    }

    class C04373 implements OnSuccessListener<TaskSnapshot> {
        C04373() {
        }

        public void onSuccess(TaskSnapshot taskSnapshot) {
            Upload.this.f3i = 1;
        }
    }

    public String uploadVideo(String s1, String s2, String s3) {
        Uri filePath = Uri.fromFile(new File("/storage/emulated/0/DCIM/Camera/myvideo.mp4"));
        if (filePath == null) {
            return "File not found";
        }
        FirebaseStorage.getInstance().getReference().child(s2 + "/" + s3 + "/" + s1 + ".mp4").putFile(filePath).addOnSuccessListener(new C04373()).addOnFailureListener(new C04362()).addOnProgressListener(new C04351());
        if (this.f3i == 1) {
            return "Successfully uploaded";
        }
        return "Sorry!!Try again..(Check your internet connection or Check whether Storage Permission is enable for the app)";
    }
}
