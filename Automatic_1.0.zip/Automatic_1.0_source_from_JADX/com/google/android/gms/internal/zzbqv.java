package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseError;

public class zzbqv implements zzbqy {
    private final zzbph zzcai;
    private final zzbpc zzchL;
    private final DatabaseError zzchM;

    public zzbqv(zzbpc com_google_android_gms_internal_zzbpc, DatabaseError databaseError, zzbph com_google_android_gms_internal_zzbph) {
        this.zzchL = com_google_android_gms_internal_zzbpc;
        this.zzcai = com_google_android_gms_internal_zzbph;
        this.zzchM = databaseError;
    }

    public String toString() {
        String valueOf = String.valueOf(zzWO());
        return new StringBuilder(String.valueOf(valueOf).length() + 7).append(valueOf).append(":CANCEL").toString();
    }

    public zzbph zzWO() {
        return this.zzcai;
    }

    public void zzZV() {
        this.zzchL.zza(this.zzchM);
    }
}
