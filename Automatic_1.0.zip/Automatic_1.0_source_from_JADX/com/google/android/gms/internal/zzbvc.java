package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbvc<T> {
    T zza(Type type);
}
