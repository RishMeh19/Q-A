package com.google.android.gms.internal;

public class zzblx {
    public static zzbva zzVS() {
        zzblw com_google_android_gms_internal_zzblw = new zzblw();
        zzbmf com_google_android_gms_internal_zzbmf = new zzbmf();
        zzbme com_google_android_gms_internal_zzbme = new zzbme();
        zzbva zzadP = new zzbvb().zzf(8, 128, 64).zzadO().zza(new zzblr()).zza(zzbml.class, com_google_android_gms_internal_zzblw).zza(zzbmv.class, com_google_android_gms_internal_zzbmf).zza(zzbmr.class, com_google_android_gms_internal_zzbme).zzadP();
        com_google_android_gms_internal_zzblw.zza(zzadP);
        com_google_android_gms_internal_zzbmf.zza(zzadP);
        com_google_android_gms_internal_zzbme.zza(zzadP);
        return zzadP;
    }
}
