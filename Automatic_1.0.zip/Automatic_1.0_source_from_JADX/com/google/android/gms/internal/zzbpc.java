package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqy.zza;
import com.google.firebase.database.DatabaseError;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class zzbpc {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbpc.class.desiredAssertionStatus());
    private AtomicBoolean zzceb = new AtomicBoolean(false);
    private zzbpd zzcec;
    private boolean zzced = false;

    public void zzYM() {
        if (this.zzceb.compareAndSet(false, true) && this.zzcec != null) {
            this.zzcec.zzd(this);
            this.zzcec = null;
        }
    }

    public boolean zzYN() {
        return this.zzceb.get();
    }

    public boolean zzYO() {
        return this.zzced;
    }

    public abstract zzbrc zzYp();

    public abstract zzbpc zza(zzbrc com_google_android_gms_internal_zzbrc);

    public abstract zzbqx zza(zzbqw com_google_android_gms_internal_zzbqw, zzbrc com_google_android_gms_internal_zzbrc);

    public void zza(zzbpd com_google_android_gms_internal_zzbpd) {
        if (!$assertionsDisabled && zzYN()) {
            throw new AssertionError();
        } else if ($assertionsDisabled || this.zzcec == null) {
            this.zzcec = com_google_android_gms_internal_zzbpd;
        } else {
            throw new AssertionError();
        }
    }

    public abstract void zza(zzbqx com_google_android_gms_internal_zzbqx);

    public abstract void zza(DatabaseError databaseError);

    public abstract boolean zza(zza com_google_android_gms_internal_zzbqy_zza);

    public void zzbe(boolean z) {
        this.zzced = z;
    }

    public abstract boolean zzc(zzbpc com_google_android_gms_internal_zzbpc);
}
