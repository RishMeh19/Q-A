package com.google.android.gms.internal;

public interface zzabq {
    void zzrq();
}
