package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.appindexing.AppIndexApi.AppIndexingLink;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;

public class zzud extends com.google.android.gms.common.internal.safeparcel.zza {
    public static final Creator<zzud> CREATOR = new zzue();
    public final String zzAT;
    final zztr zzahP;
    final long zzahQ;
    int zzahR;
    final zztp zzahS;
    final boolean zzahT;
    int zzahU;
    int zzahV;

    public static final class zza {
        private zztr zzahP;
        private long zzahQ = -1;
        private int zzahR = -1;
        private zztp zzahS;
        private boolean zzahT = false;
        private int zzahU = -1;
        private int zzahV = 0;

        public zza zzB(long j) {
            this.zzahQ = j;
            return this;
        }

        public zza zza(zztp com_google_android_gms_internal_zztp) {
            this.zzahS = com_google_android_gms_internal_zztp;
            return this;
        }

        public zza zza(zztr com_google_android_gms_internal_zztr) {
            this.zzahP = com_google_android_gms_internal_zztr;
            return this;
        }

        public zza zzaS(int i) {
            this.zzahR = i;
            return this;
        }

        public zza zzaT(int i) {
            this.zzahV = i;
            return this;
        }

        public zza zzaa(boolean z) {
            this.zzahT = z;
            return this;
        }

        public zzud zzqI() {
            return new zzud(this.zzahP, this.zzahQ, this.zzahR, null, this.zzahS, this.zzahT, this.zzahU, this.zzahV);
        }
    }

    zzud(zztr com_google_android_gms_internal_zztr, long j, int i, String str, zztp com_google_android_gms_internal_zztp, boolean z, int i2, int i3) {
        this.zzahP = com_google_android_gms_internal_zztr;
        this.zzahQ = j;
        this.zzahR = i;
        this.zzAT = str;
        this.zzahS = com_google_android_gms_internal_zztp;
        this.zzahT = z;
        this.zzahU = i2;
        this.zzahV = i3;
    }

    public zzud(String str, Intent intent, String str2, Uri uri, String str3, List<AppIndexingLink> list, int i) {
        this(zza(str, intent), System.currentTimeMillis(), 0, null, zza(intent, str2, uri, str3, list).zzqE(), false, -1, i);
    }

    public static com.google.android.gms.internal.zztp.zza zza(Intent intent, String str, Uri uri, String str2, List<AppIndexingLink> list) {
        com.google.android.gms.internal.zztp.zza com_google_android_gms_internal_zztp_zza = new com.google.android.gms.internal.zztp.zza();
        com_google_android_gms_internal_zztp_zza.zza(zzcp(str));
        if (uri != null) {
            com_google_android_gms_internal_zztp_zza.zza(zzk(uri));
        }
        if (list != null) {
            com_google_android_gms_internal_zztp_zza.zza(zzv(list));
        }
        String action = intent.getAction();
        if (action != null) {
            com_google_android_gms_internal_zztp_zza.zza(zzu("intent_action", action));
        }
        action = intent.getDataString();
        if (action != null) {
            com_google_android_gms_internal_zztp_zza.zza(zzu("intent_data", action));
        }
        ComponentName component = intent.getComponent();
        if (component != null) {
            com_google_android_gms_internal_zztp_zza.zza(zzu("intent_activity", component.getClassName()));
        }
        Bundle extras = intent.getExtras();
        if (extras != null) {
            action = extras.getString("intent_extra_data_key");
            if (action != null) {
                com_google_android_gms_internal_zztp_zza.zza(zzu("intent_extra_data", action));
            }
        }
        return com_google_android_gms_internal_zztp_zza.zzcl(str2).zzX(true);
    }

    public static zztr zza(String str, Intent intent) {
        return zzt(str, zzg(intent));
    }

    private static zztt zzcp(String str) {
        return new zztt(str, new com.google.android.gms.internal.zzub.zza("title").zzaQ(1).zzZ(true).zzco("name").zzqH(), "text1");
    }

    private static String zzg(Intent intent) {
        String toUri = intent.toUri(1);
        CRC32 crc32 = new CRC32();
        try {
            crc32.update(toUri.getBytes("UTF-8"));
            return Long.toHexString(crc32.getValue());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public static zztt zzk(Uri uri) {
        return new zztt(uri.toString(), new com.google.android.gms.internal.zzub.zza("web_url").zzaQ(4).zzY(true).zzco("url").zzqH());
    }

    private static zztr zzt(String str, String str2) {
        return new zztr(str, "", str2);
    }

    private static zztt zzu(String str, String str2) {
        return new zztt(str2, new com.google.android.gms.internal.zzub.zza(str).zzY(true).zzqH(), str);
    }

    private static zztt zzv(List<AppIndexingLink> list) {
        zzbyj com_google_android_gms_internal_zzaqn_zza = new com.google.android.gms.internal.zzaqn.zza();
        com.google.android.gms.internal.zzaqn.zza.zza[] com_google_android_gms_internal_zzaqn_zza_zzaArr = new com.google.android.gms.internal.zzaqn.zza.zza[list.size()];
        for (int i = 0; i < com_google_android_gms_internal_zzaqn_zza_zzaArr.length; i++) {
            com_google_android_gms_internal_zzaqn_zza_zzaArr[i] = new com.google.android.gms.internal.zzaqn.zza.zza();
            AppIndexingLink appIndexingLink = (AppIndexingLink) list.get(i);
            com_google_android_gms_internal_zzaqn_zza_zzaArr[i].zzbhi = appIndexingLink.appIndexingUrl.toString();
            com_google_android_gms_internal_zzaqn_zza_zzaArr[i].viewId = appIndexingLink.viewId;
            if (appIndexingLink.webUrl != null) {
                com_google_android_gms_internal_zzaqn_zza_zzaArr[i].zzbhj = appIndexingLink.webUrl.toString();
            }
        }
        com_google_android_gms_internal_zzaqn_zza.zzbhg = com_google_android_gms_internal_zzaqn_zza_zzaArr;
        return new zztt(zzbyj.zzf(com_google_android_gms_internal_zzaqn_zza), new com.google.android.gms.internal.zzub.zza("outlinks").zzY(true).zzco(".private:outLinks").zzcn("blob").zzqH());
    }

    public String toString() {
        return String.format(Locale.US, "UsageInfo[documentId=%s, timestamp=%d, usageType=%d, status=%d]", new Object[]{this.zzahP, Long.valueOf(this.zzahQ), Integer.valueOf(this.zzahR), Integer.valueOf(this.zzahV)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzue.zza(this, parcel, i);
    }
}
