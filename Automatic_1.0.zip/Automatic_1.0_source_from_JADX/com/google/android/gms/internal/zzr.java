package com.google.android.gms.internal;

public class zzr extends zzs {
}
