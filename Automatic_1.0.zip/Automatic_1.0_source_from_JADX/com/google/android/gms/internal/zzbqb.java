package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqe.zza;

public class zzbqb extends zzbqe {
    private final boolean zzcgH;
    private final zzbqq<Boolean> zzcgI;

    public zzbqb(zzbph com_google_android_gms_internal_zzbph, zzbqq<Boolean> com_google_android_gms_internal_zzbqq_java_lang_Boolean, boolean z) {
        super(zza.AckUserWrite, zzbqf.zzcgR, com_google_android_gms_internal_zzbph);
        this.zzcgI = com_google_android_gms_internal_zzbqq_java_lang_Boolean;
        this.zzcgH = z;
    }

    public String toString() {
        return String.format("AckUserWrite { path=%s, revert=%s, affectedTree=%s }", new Object[]{zzWO(), Boolean.valueOf(this.zzcgH), this.zzcgI});
    }

    public zzbqq<Boolean> zzZx() {
        return this.zzcgI;
    }

    public boolean zzZy() {
        return this.zzcgH;
    }

    public zzbqe zzc(zzbrq com_google_android_gms_internal_zzbrq) {
        if (!this.zzcai.isEmpty()) {
            zzbte.zzb(this.zzcai.zzYU().equals(com_google_android_gms_internal_zzbrq), "operationForChild called for unrelated child.");
            return new zzbqb(this.zzcai.zzYV(), this.zzcgI, this.zzcgH);
        } else if (this.zzcgI.getValue() != null) {
            zzbte.zzb(this.zzcgI.zzZQ().isEmpty(), "affectedTree should not have overlapping affected paths.");
            return this;
        } else {
            return new zzbqb(zzbph.zzYR(), this.zzcgI.zzI(new zzbph(com_google_android_gms_internal_zzbrq)), this.zzcgH);
        }
    }
}
